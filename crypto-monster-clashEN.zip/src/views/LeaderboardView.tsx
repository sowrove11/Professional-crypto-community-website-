import React, { useState } from 'react';
import { Trophy, Users, Award, Flame, Star, ChevronUp, ChevronDown } from 'lucide-react';
import { LeaderboardEntry } from '../types';

interface LeaderboardViewProps {
  leaderboard: LeaderboardEntry[];
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({ leaderboard }) => {
  const [activeCategory, setActiveCategory] = useState<'users' | 'communities' | 'referrals' | 'campaigns'>('users');
  const [timeframe, setTimeframe] = useState<'weekly' | 'monthly' | 'alltime'>('weekly');

  return (
    <div className="space-y-8 pb-12 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/30 p-8 rounded-3xl text-center space-y-2">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
          Hall of Fame
        </span>
        <h1 className="text-3xl font-black text-white">Crypto Monster Leaderboard</h1>
        <p className="text-xs text-slate-400">Rankings based on Quest XP, AMA engagements & community referrals</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex space-x-2 overflow-x-auto w-full sm:w-auto">
          {[
            { id: 'users', label: 'Top Users' },
            { id: 'communities', label: 'Top Communities' },
            { id: 'referrals', label: 'Top Referrals' },
            { id: 'campaigns', label: 'Top Campaigns' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id as any)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeCategory === cat.id 
                  ? 'bg-amber-500 text-slate-950' 
                  : 'bg-slate-900 border border-slate-800 text-slate-300'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold">
          {(['weekly', 'monthly', 'alltime'] as const).map((tf) => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 rounded-lg uppercase ${
                timeframe === tf ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'text-slate-400'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* Leaderboard Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl">
        <div className="p-4 bg-slate-950 border-b border-slate-800 grid grid-cols-12 text-slate-400 text-xs font-bold uppercase tracking-wider">
          <div className="col-span-2">Rank</div>
          <div className="col-span-6">User / Community</div>
          <div className="col-span-2 text-right">Badges</div>
          <div className="col-span-2 text-right">Score / XP</div>
        </div>

        <div className="divide-y divide-slate-800/80">
          {leaderboard.map((entry) => (
            <div key={entry.rank} className="p-4 grid grid-cols-12 items-center hover:bg-slate-800/40 transition-colors text-xs">
              <div className="col-span-2 flex items-center space-x-2">
                <span className={`w-7 h-7 rounded-full flex items-center justify-center font-black text-xs ${
                  entry.rank === 1 ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20' : entry.rank === 2 ? 'bg-slate-300 text-slate-950' : 'bg-amber-700 text-white'
                }`}>
                  #{entry.rank}
                </span>
                {entry.change === 'up' && <ChevronUp className="w-3.5 h-3.5 text-emerald-400" />}
                {entry.change === 'down' && <ChevronDown className="w-3.5 h-3.5 text-red-400" />}
              </div>

              <div className="col-span-6 flex items-center space-x-3">
                <img src={entry.avatar} alt={entry.name} className="w-9 h-9 rounded-full object-cover border border-slate-700" />
                <span className="font-bold text-slate-100">{entry.name}</span>
              </div>

              <div className="col-span-2 text-right flex justify-end space-x-1">
                {entry.badges.map((badge, idx) => (
                  <span key={idx} className="bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[9px] px-1.5 py-0.5 rounded font-bold">
                    {badge}
                  </span>
                ))}
              </div>

              <div className="col-span-2 text-right font-black text-amber-400 text-sm">
                {entry.scoreOrXp.toLocaleString()} <span className="text-[10px] text-slate-500">XP</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
