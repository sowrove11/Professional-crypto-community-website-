import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Flame, 
  Calendar, 
  Sparkles, 
  Mic, 
  Gift, 
  Users, 
  Trophy, 
  ArrowRight, 
  CheckCircle, 
  Star, 
  ShieldCheck, 
  Send, 
  Twitter, 
  Globe, 
  PlayCircle,
  Coins,
  ChevronRight,
  TrendingUp,
  Clock
} from 'lucide-react';
import { AMAItem, ServiceItem, ProjectItem, CommunityItem, GiveawayItem, LeaderboardEntry, NewsArticle, SiteConfig } from '../types';
import { LiveAmaPlayer } from '../components/LiveAmaPlayer';

interface HomeViewProps {
  siteConfig: SiteConfig;
  amas: AMAItem[];
  services: ServiceItem[];
  projects: ProjectItem[];
  communities: CommunityItem[];
  giveaways: GiveawayItem[];
  leaderboard: LeaderboardEntry[];
  news: NewsArticle[];
  setActiveTab: (tab: string) => void;
  onOpenBookModal: () => void;
  onOpenAiTools: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  siteConfig,
  amas,
  services,
  projects,
  communities,
  giveaways,
  leaderboard,
  news,
  setActiveTab,
  onOpenBookModal,
  onOpenAiTools,
}) => {
  // Live Countdown Timer initialized from siteConfig
  const [timeLeft, setTimeLeft] = useState({ 
    hours: siteConfig.nextAmaCountdownHours || 14, 
    minutes: siteConfig.nextAmaCountdownMinutes || 28, 
    seconds: 45 
  });

  useEffect(() => {
    setTimeLeft({
      hours: siteConfig.nextAmaCountdownHours || 14,
      minutes: siteConfig.nextAmaCountdownMinutes || 28,
      seconds: 45
    });
  }, [siteConfig]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const liveAma = amas.find(a => a.status === 'live') || amas[0];
  const upcomingAmas = amas.filter(a => a.status === 'upcoming').slice(0, 3);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="space-y-10 pb-12 text-slate-100"
    >
      {/* Hero Bento Section */}
      <section className="relative pt-2">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
          
          {/* Main Bento Hero Card (Col 7) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.05 }}
            whileHover={{ scale: 1.01, transition: { duration: 0.2 } }}
            className="lg:col-span-7 bg-[#141416] border border-white/10 rounded-3xl p-8 relative overflow-hidden flex flex-col justify-between hover:border-[#00FF94]/30 transition-all group"
          >
            {/* Subtle glow background */}
            <div className="absolute top-0 right-0 w-96 h-96 bg-[#00FF94]/5 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
            
            <div className="space-y-6 relative z-10">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#00FF94]/10 border border-[#00FF94]/30 text-[#00FF94] text-xs font-mono font-bold tracking-wider uppercase">
                <Flame className="w-3.5 h-3.5 text-[#00FF94] animate-pulse" />
                <span>#1 Web3 AMA & Marketing Accelerator</span>
              </div>

              <h1 className="text-3xl sm:text-4xl xl:text-5xl font-black tracking-tight leading-tight text-white">
                {siteConfig.heroHeadline} <span className="text-[#00FF94]">{siteConfig.heroHighlight}</span>
              </h1>

              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed max-w-xl">
                {siteConfig.heroDescription}
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3 pt-2">
                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={onOpenBookModal}
                  className="px-6 py-3 rounded-xl bg-[#00FF94] text-black font-black text-xs shadow-lg shadow-[#00FF94]/20 hover:bg-[#00e082] transition-all flex items-center space-x-2 cursor-pointer"
                >
                  <Calendar className="w-4 h-4 text-black" />
                  <span>Book AMA ($499+)</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setActiveTab('amas')}
                  className="px-5 py-3 rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 font-bold text-xs flex items-center space-x-2 transition-all cursor-pointer"
                >
                  <Mic className="w-4 h-4 text-[#00FF94]" />
                  <span>Explore AMAs</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={onOpenAiTools}
                  className="px-5 py-3 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-200 hover:bg-purple-900/60 text-xs font-bold flex items-center space-x-2 transition-all cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-purple-400" />
                  <span>AI Question Generator</span>
                </motion.button>
              </div>
            </div>

            {/* Official Channels Bar */}
            <div className="mt-8 pt-4 flex flex-wrap items-center gap-4 text-xs text-gray-400 border-t border-white/10 relative z-10 font-mono">
              <span className="font-bold text-gray-300">Official Channels:</span>
              <a href="https://t.me/CryptoMonsterClashGlobal" target="_blank" rel="noreferrer" className="flex items-center space-x-1 text-[#00FF94] hover:underline">
                <Send className="w-3.5 h-3.5" />
                <span>Telegram (150K+)</span>
              </a>
              <a href="https://x.com/MonsterClashX" target="_blank" rel="noreferrer" className="flex items-center space-x-1 text-[#00FF94] hover:underline">
                <Twitter className="w-3.5 h-3.5" />
                <span>@MonsterClashX (210K+)</span>
              </a>
            </div>
          </motion.div>

          {/* Next Big Event Bento Card (Col 5) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            whileHover={{ scale: 1.015, transition: { duration: 0.2 } }}
            className="lg:col-span-5 bg-[#141416] border border-[#00FF94]/30 rounded-3xl p-6 relative overflow-hidden flex flex-col justify-between shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <span className="text-xs font-mono font-bold text-[#00FF94] flex items-center space-x-1.5 uppercase tracking-wider">
                <Clock className="w-4 h-4 text-[#00FF94]" />
                <span>NEXT BIG AMA EVENT</span>
              </span>
              <span className="bg-red-500/10 text-red-400 border border-red-500/30 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full uppercase">
                Live Broadcast
              </span>
            </div>

            <div className="my-4 space-y-3">
              <div className="flex items-center space-x-3">
                <img src={liveAma.projectLogo} alt={liveAma.projectName} className="w-12 h-12 rounded-xl object-cover border border-white/10" />
                <div>
                  <h4 className="font-black text-white text-base leading-snug">{liveAma.projectName}</h4>
                  <p className="text-xs text-gray-400 font-mono">{liveAma.platform}</p>
                </div>
              </div>

              <p className="text-xs text-gray-300 line-clamp-2">{liveAma.description}</p>
            </div>

            {/* Countdown Grid in Bento Box */}
            <div className="bg-[#0A0A0B] p-4 rounded-2xl border border-white/10 text-center">
              <p className="text-[10px] text-gray-400 uppercase font-mono font-bold mb-2 tracking-widest">Event Countdown</p>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="bg-[#141416] p-2.5 rounded-xl border border-white/5">
                  <span className="text-2xl font-black text-[#00FF94]">{String(timeLeft.hours).padStart(2, '0')}</span>
                  <span className="block text-[9px] text-gray-500 uppercase font-mono font-bold">Hours</span>
                </div>
                <div className="bg-[#141416] p-2.5 rounded-xl border border-white/5">
                  <span className="text-2xl font-black text-[#00FF94]">{String(timeLeft.minutes).padStart(2, '0')}</span>
                  <span className="block text-[9px] text-gray-500 uppercase font-mono font-bold">Minutes</span>
                </div>
                <div className="bg-[#141416] p-2.5 rounded-xl border border-white/5">
                  <span className="text-2xl font-black text-[#00FF94]">{String(timeLeft.seconds).padStart(2, '0')}</span>
                  <span className="block text-[9px] text-gray-500 uppercase font-mono font-bold">Seconds</span>
                </div>
              </div>
            </div>

            <div className="mt-4 flex justify-between items-center bg-[#00FF94]/10 p-3 rounded-xl border border-[#00FF94]/20 text-xs">
              <span className="text-gray-300 font-bold">Giveaway Prize Pool:</span>
              <span className="font-extrabold text-[#00FF94] font-mono">{liveAma.rewardPool}</span>
            </div>
          </motion.div>

        </div>
      </section>

      {/* Custom HTML Block */}
      {siteConfig.sectionVisibility?.customBlocks !== false && siteConfig.customHtmlBlock && (
        <section className="overflow-x-auto">
          <div dangerouslySetInnerHTML={{ __html: siteConfig.customHtmlBlock }} />
        </section>
      )}

      {/* Bento Statistics Grid */}
      {siteConfig.sectionVisibility?.statistics !== false && (
        <section>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { value: "350+", label: "AMAs Hosted" },
              { value: "500K+", label: "Global Reach" },
              { value: "$650K+", label: "Giveaways Claimed" },
              { value: "120+", label: "Projects Launched" }
            ].map((stat, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 0.15 + idx * 0.05 }}
                whileHover={{ scale: 1.04, y: -2, transition: { duration: 0.2 } }}
                className="bg-[#141416] border border-white/10 p-6 rounded-3xl text-center hover:border-[#00FF94]/30 transition-all shadow-lg"
              >
                <span className="text-3xl font-black text-[#00FF94]">{stat.value}</span>
                <p className="text-xs text-gray-400 font-bold uppercase tracking-wider mt-1 font-mono">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Live AMA Player Bento Section */}
      {siteConfig.sectionVisibility?.liveAma !== false && (
        <motion.section 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          whileHover={{ scale: 1.005, transition: { duration: 0.2 } }}
          className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 hover:border-[#00FF94]/30 transition-all shadow-2xl"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              <h2 className="text-xl font-black text-white uppercase tracking-tight">Interactive Live AMA Broadcast</h2>
            </div>
            <button
              onClick={() => setActiveTab('amas')}
              className="text-xs text-[#00FF94] font-bold hover:underline flex items-center space-x-1 font-mono cursor-pointer"
            >
              <span>View All AMAs</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <LiveAmaPlayer 
            ama={liveAma} 
            onAskQuestion={(q) => alert(`Question submitted: "${q}"`)} 
          />
        </motion.section>
      )}

      {/* Featured Services Grid */}
      <section className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-mono font-bold text-[#00FF94] uppercase tracking-widest">Growth Packages</span>
            <h2 className="text-2xl font-black text-white mt-1">Crypto Marketing & AMA Solutions</h2>
          </div>
          <button
            onClick={() => setActiveTab('services')}
            className="text-xs text-[#00FF94] font-mono font-bold hover:underline flex items-center space-x-1 cursor-pointer"
          >
            <span>Browse All Packages</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {services.slice(0, 3).map((srv, idx) => (
            <motion.div 
              key={srv.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.25 + idx * 0.08 }}
              whileHover={{ scale: 1.02, y: -4, transition: { duration: 0.2 } }}
              className="bg-[#141416] border border-white/10 rounded-3xl p-6 hover:border-[#00FF94]/30 transition-all flex flex-col justify-between group shadow-xl"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="bg-[#00FF94]/10 border border-[#00FF94]/30 text-[#00FF94] text-[10px] font-mono font-bold px-2.5 py-1 rounded-full uppercase">
                    {srv.category}
                  </span>
                  {srv.popular && (
                    <span className="bg-red-500/10 text-red-400 text-[10px] font-mono font-bold px-2.5 py-1 rounded-full border border-red-500/30">
                      🔥 Most Popular
                    </span>
                  )}
                </div>

                <h3 className="text-lg font-bold text-white mb-2">{srv.title}</h3>
                <p className="text-xs text-gray-400 leading-relaxed mb-4">{srv.description}</p>

                <ul className="space-y-2 mb-6">
                  {srv.features.map((feat, fidx) => (
                    <li key={fidx} className="flex items-center space-x-2 text-xs text-gray-300">
                      <CheckCircle className="w-3.5 h-3.5 text-[#00FF94] shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-gray-500 font-mono uppercase font-bold">Starting At</span>
                  <p className="text-xl font-black text-[#00FF94] font-mono">${srv.priceUsdt} <span className="text-xs font-normal text-gray-400">USDT</span></p>
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={onOpenBookModal}
                  className="px-4 py-2 bg-[#00FF94] text-black font-bold text-xs rounded-xl hover:bg-[#00e082] transition-colors cursor-pointer"
                >
                  Book Package
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Giveaways & Rewards Bento Card */}
      {siteConfig.sectionVisibility?.giveaways !== false && (
        <section>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.3 }}
            whileHover={{ scale: 1.008, transition: { duration: 0.2 } }}
            className="bg-[#141416] border border-white/10 p-8 rounded-3xl shadow-2xl space-y-6 hover:border-[#00FF94]/30 transition-all"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-mono font-bold text-[#00FF94] uppercase tracking-wider">Rewards Hub</span>
                <h2 className="text-2xl font-black text-white mt-1">Active Giveaways & Crypto Airdrops</h2>
                <p className="text-xs text-gray-400">Complete social quests to claim USDT & native token pools</p>
              </div>
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setActiveTab('giveaways')}
                className="px-5 py-2.5 bg-[#00FF94] text-black font-bold text-xs rounded-xl hover:bg-[#00e082] transition-colors shrink-0 cursor-pointer"
              >
                View All Giveaways
              </motion.button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {giveaways.map((gw) => (
                <motion.div 
                  key={gw.id}
                  whileHover={{ scale: 1.02, x: 2, transition: { duration: 0.15 } }}
                  className="bg-[#0A0A0B] p-4 rounded-2xl border border-white/10 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3">
                    <img src={gw.projectLogo} alt={gw.projectName} className="w-11 h-11 rounded-xl object-cover border border-white/10" />
                    <div>
                      <h4 className="font-bold text-white text-xs">{gw.title}</h4>
                      <p className="text-xs text-[#00FF94] font-mono font-extrabold mt-0.5">Prize: {gw.prizePool}</p>
                      <p className="text-[10px] text-gray-500 font-mono">{gw.participantsCount.toLocaleString()} Participants</p>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setActiveTab('giveaways')}
                    className="px-3.5 py-2 bg-[#141416] hover:bg-[#00FF94] hover:text-black text-[#00FF94] border border-[#00FF94]/30 font-bold text-xs rounded-xl transition-all cursor-pointer"
                  >
                    Enter Quest
                  </motion.button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>
      )}

      {/* Featured Projects & Verified Communities Bento Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* Featured Projects */}
        {siteConfig.sectionVisibility?.featuredProjects !== false && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.35 }}
            whileHover={{ scale: 1.01, transition: { duration: 0.2 } }}
            className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 hover:border-[#00FF94]/30 transition-all shadow-xl"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                <span>🚀 Featured Web3 Projects</span>
              </h3>
              <button onClick={() => setActiveTab('projects')} className="text-xs text-[#00FF94] font-mono font-bold hover:underline cursor-pointer">
                Directory
              </button>
            </div>

            <div className="space-y-3">
              {projects.slice(0, 3).map((proj) => (
                <motion.div 
                  key={proj.id}
                  whileHover={{ scale: 1.015, x: 2, transition: { duration: 0.15 } }}
                  className="p-3 bg-[#0A0A0B] rounded-2xl border border-white/10 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3">
                    <img src={proj.logo} alt={proj.name} className="w-10 h-10 rounded-xl object-cover" />
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-white text-xs">{proj.name}</span>
                        <span className="text-[10px] text-gray-500 font-mono">(${proj.ticker})</span>
                        {proj.isVerified && <ShieldCheck className="w-3.5 h-3.5 text-[#00FF94]" />}
                      </div>
                      <p className="text-[11px] text-gray-400 line-clamp-1">{proj.description}</p>
                    </div>
                  </div>
                  <span className="text-xs font-bold font-mono text-[#00FF94] bg-[#00FF94]/10 border border-[#00FF94]/20 px-2.5 py-1 rounded-lg">
                    {proj.marketCap}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Verified Communities */}
        {siteConfig.sectionVisibility?.featuredCommunities !== false && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.4 }}
            whileHover={{ scale: 1.01, transition: { duration: 0.2 } }}
            className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 hover:border-[#00FF94]/30 transition-all shadow-xl"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-base text-white flex items-center gap-2">
                <span>👥 Verified Communities</span>
              </h3>
              <button onClick={() => setActiveTab('communities')} className="text-xs text-[#00FF94] font-mono font-bold hover:underline cursor-pointer">
                View All
              </button>
            </div>

            <div className="space-y-3">
              {communities.map((comm) => (
                <motion.div 
                  key={comm.id}
                  whileHover={{ scale: 1.015, x: 2, transition: { duration: 0.15 } }}
                  className="p-3 bg-[#0A0A0B] rounded-2xl border border-white/10 flex items-center justify-between"
                >
                  <div className="flex items-center space-x-3">
                    <img src={comm.logo} alt={comm.name} className="w-10 h-10 rounded-xl object-cover" />
                    <div>
                      <div className="flex items-center space-x-1.5">
                        <span className="font-bold text-white text-xs">{comm.name}</span>
                        {comm.isVerified && <ShieldCheck className="w-3.5 h-3.5 text-[#00FF94]" />}
                      </div>
                      <p className="text-[11px] text-gray-400 font-mono">{comm.membersCount.toLocaleString()} Members • {comm.platform}</p>
                    </div>
                  </div>
                  <a
                    href={comm.link}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 bg-[#141416] border border-white/10 hover:border-[#00FF94] text-[#00FF94] text-xs font-bold rounded-xl transition-colors"
                  >
                    Join
                  </a>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

      </section>

      {/* Leaderboard Teaser Bento Box */}
      {siteConfig.sectionVisibility?.leaderboard !== false && (
        <section>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.45 }}
            whileHover={{ scale: 1.008, transition: { duration: 0.2 } }}
            className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 hover:border-[#00FF94]/30 transition-all shadow-xl"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-extrabold text-base text-white flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-[#00FF94]" />
                  <span>Global Quest Leaderboard</span>
                </h3>
                <p className="text-xs text-gray-400">Top active Web3 questers earning weekly USDT & XP rewards</p>
              </div>
              <button onClick={() => setActiveTab('leaderboard')} className="text-xs text-[#00FF94] font-mono font-bold hover:underline cursor-pointer">
                Full Standings
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {leaderboard.slice(0, 3).map((entry) => (
                <motion.div 
                  key={entry.rank}
                  whileHover={{ scale: 1.03, transition: { duration: 0.15 } }}
                  className="bg-[#0A0A0B] p-4 rounded-2xl border border-white/10 flex items-center space-x-3"
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs font-mono ${
                    entry.rank === 1 ? 'bg-[#00FF94] text-black' : entry.rank === 2 ? 'bg-slate-300 text-black' : 'bg-amber-600 text-white'
                  }`}>
                    #{entry.rank}
                  </div>
                  <img src={entry.avatar} alt={entry.name} className="w-10 h-10 rounded-full object-cover" />
                  <div>
                    <h4 className="font-bold text-white text-xs">{entry.name}</h4>
                    <p className="text-xs font-mono font-extrabold text-[#00FF94]">{entry.scoreOrXp.toLocaleString()} XP</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>
      )}

    </motion.div>
  );
};
