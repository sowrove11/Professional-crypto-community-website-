import React, { useState } from 'react';
import { User, Wallet, Gift, Calendar, Share2, Bell, Settings, Copy, Check, ShieldCheck, Flame, Coins, Award } from 'lucide-react';
import { UserProfile, AMABooking } from '../types';

interface UserDashboardViewProps {
  currentUser: UserProfile;
  onLogout: () => void;
  onOpenBookModal: () => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  currentUser,
  onLogout,
  onOpenBookModal
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'wallet' | 'rewards' | 'bookings' | 'referrals' | 'settings'>('profile');
  const [copiedLink, setCopiedLink] = useState(false);
  const [walletAddress, setWalletAddress] = useState(currentUser.walletAddress || '0x71C8A9b23C41DE89004123');

  const refLink = `${window.location.origin}?ref=${currentUser.referralCode}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(refLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Sample Bookings for demo
  const sampleBookings: AMABooking[] = [
    {
      id: "booking-991",
      userId: currentUser.uid,
      userEmail: currentUser.email,
      projectName: "Monster AI Chain",
      projectCategory: "AI",
      serviceType: "AMA Services",
      packageName: "Telegram Voice AMA",
      priceUsdt: 899,
      paymentChain: "TRC20",
      paymentStatus: "verified",
      bookingStatus: "Approved",
      txHash: "0x892a11b99cf02",
      scheduledDate: "2026-08-12",
      createdAt: "2026-08-07"
    }
  ];

  return (
    <div className="space-y-8 pb-12 text-slate-100">
      {/* Profile Overview Card */}
      <div className="bg-slate-900 border border-amber-500/30 p-6 sm:p-8 rounded-3xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-500 text-slate-950 font-black text-2xl flex items-center justify-center shadow-lg shadow-amber-500/20">
              {currentUser.displayName ? currentUser.displayName[0].toUpperCase() : 'U'}
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-black text-white">{currentUser.displayName}</h1>
                <span className="bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                  Level {currentUser.level}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{currentUser.email}</p>
              <div className="flex items-center space-x-3 mt-2 text-xs font-bold text-amber-400">
                <span>🔥 {currentUser.xp} XP</span>
                <span>•</span>
                <span>💰 Earned: ${currentUser.earnedUsdt} USDT</span>
              </div>
            </div>
          </div>

          <button
            onClick={onOpenBookModal}
            className="px-5 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110"
          >
            + Book New Campaign
          </button>
        </div>
      </div>

      {/* Sub-Tabs */}
      <div className="flex space-x-2 border-b border-slate-800 pb-2 text-xs font-bold overflow-x-auto">
        {[
          { id: 'profile', label: 'My Profile', icon: User },
          { id: 'wallet', label: 'My Wallet', icon: Wallet },
          { id: 'rewards', label: 'My Rewards', icon: Gift },
          { id: 'bookings', label: 'My AMA Bookings', icon: Calendar },
          { id: 'referrals', label: 'Referral Program', icon: Share2 },
          { id: 'settings', label: 'Settings', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                isActive 
                  ? 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/20' 
                  : 'bg-slate-900 border border-slate-800 text-slate-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Profile / Overview Tab */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4">
            <h3 className="font-extrabold text-white text-base">Account Information</h3>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-500">User ID</span>
                <span className="font-mono text-slate-200">{currentUser.uid}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-500">Account Role</span>
                <span className="font-bold text-amber-400 capitalize">{currentUser.role}</span>
              </div>
              <div className="flex justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-500">Referral Code</span>
                <span className="font-mono font-bold text-slate-200">{currentUser.referralCode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Total Referrals</span>
                <span className="font-bold text-emerald-400">{currentUser.referralCount} Users</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4">
            <h3 className="font-extrabold text-white text-base">Connected EVM Wallet</h3>
            <p className="text-xs text-slate-400">Used for automated USDT airdrop payout distributions</p>
            <input
              type="text"
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
            />
            <button
              onClick={() => alert("Wallet address updated!")}
              className="w-full py-2.5 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl"
            >
              Update Wallet
            </button>
          </div>
        </div>
      )}

      {/* Bookings Tab */}
      {activeTab === 'bookings' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
          <h3 className="font-extrabold text-white text-base">My AMA & Marketing Bookings</h3>
          <div className="space-y-3">
            {sampleBookings.map((b) => (
              <div key={b.id} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-black text-white text-sm">{b.projectName}</span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/40">
                      Status: {b.bookingStatus}
                    </span>
                  </div>
                  <p className="text-slate-400 mt-0.5">{b.packageName} • ${b.priceUsdt} USDT ({b.paymentChain})</p>
                  <p className="text-[10px] text-slate-500 font-mono">TX: {b.txHash}</p>
                </div>

                <div className="text-left md:text-right">
                  <span className="text-[10px] text-slate-500 font-bold">Scheduled Date</span>
                  <p className="font-bold text-amber-400">{b.scheduledDate}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Referrals Tab */}
      {activeTab === 'referrals' && (
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4">
          <h3 className="font-extrabold text-white text-base">Affiliate & Referral Link</h3>
          <p className="text-xs text-slate-400">Earn 10% commission on every AMA booking & quest signup generated through your referral link!</p>
          
          <div className="flex space-x-2">
            <input
              type="text"
              readOnly
              value={refLink}
              className="flex-1 p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 font-mono"
            />
            <button
              onClick={handleCopyLink}
              className="px-5 py-3 bg-amber-500 text-slate-950 font-black text-xs rounded-xl flex items-center space-x-1"
            >
              {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? 'Copied' : 'Copy Link'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
