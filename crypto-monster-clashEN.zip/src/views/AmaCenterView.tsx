import React, { useState } from 'react';
import { 
  Mic, 
  Radio, 
  Calendar, 
  CheckCircle, 
  FileText, 
  Archive, 
  Users, 
  Gift, 
  BarChart3, 
  Search, 
  Filter, 
  Play, 
  ExternalLink, 
  Clock, 
  MessageSquare, 
  Sparkles,
  ChevronRight,
  Share2
} from 'lucide-react';
import { AMAItem } from '../types';

interface AmaCenterViewProps {
  amas: AMAItem[];
  onOpenBookModal: () => void;
  onOpenAiTools: () => void;
}

export const AmaCenterView: React.FC<AmaCenterViewProps> = ({
  amas,
  onOpenBookModal,
  onOpenAiTools
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'live' | 'upcoming' | 'ended' | 'recaps' | 'archive' | 'speakers' | 'giveaways' | 'stats'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedAma, setSelectedAma] = useState<AMAItem | null>(null);

  // Dynamic category list from live dataset
  const dynamicCats = Array.from(new Set(amas.map(a => a.category).filter(Boolean)));
  const categories = ['All', ...Array.from(new Set(['AI', 'Gaming', 'Meme', 'DeFi', 'RWA', 'Infrastructure', ...dynamicCats]))];

  const filteredAmas = amas.filter(ama => {
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch = !q || 
                          ama.title.toLowerCase().includes(q) || 
                          ama.projectName.toLowerCase().includes(q) ||
                          (ama.description && ama.description.toLowerCase().includes(q)) ||
                          (ama.category && ama.category.toLowerCase().includes(q));

    const matchesCat = selectedCategory === 'All' || 
                       (ama.category && ama.category.toLowerCase().includes(selectedCategory.toLowerCase())) ||
                       (ama.category && selectedCategory.toLowerCase().includes(ama.category.toLowerCase()));

    const matchesTab = activeTab === 'all' || 
                       (activeTab === 'live' && ama.status === 'live') ||
                       (activeTab === 'upcoming' && ama.status === 'upcoming') ||
                       (activeTab === 'ended' && ama.status === 'ended') ||
                       (activeTab === 'recaps' && Boolean(ama.recapText || ama.status === 'ended')) ||
                       (activeTab === 'archive' && Boolean(ama.status === 'archived' || ama.status === 'ended')) ||
                       (activeTab === 'speakers' && Boolean((ama.speakers && ama.speakers.length > 0) || (ama.guestSpeakers && ama.guestSpeakers.length > 0))) ||
                       (activeTab === 'giveaways' && Boolean(ama.rewardPool)) ||
                       (activeTab === 'stats');

    return matchesSearch && matchesCat && matchesTab;
  });

  return (
    <div className="space-y-8 pb-12 text-slate-100">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/30 p-8 rounded-3xl relative overflow-hidden">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold">
            <Mic className="w-4 h-4 text-amber-400" />
            <span>Official Crypto Monster Clash AMA Center</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white">
            Discover & Listen To Top Tier Web3 AMAs
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Tune into live voice sessions, upcoming schedule, full recordings, AI-generated recap reports, and submit questions for active USDT giveaways.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <button
              onClick={onOpenBookModal}
              className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg hover:brightness-110"
            >
              Book an AMA Slot
            </button>
            <button
              onClick={onOpenAiTools}
              className="px-5 py-2.5 bg-purple-950/80 border border-purple-500/40 text-purple-200 font-bold text-xs rounded-xl hover:bg-purple-900 flex items-center space-x-1.5"
            >
              <Sparkles className="w-4 h-4 text-purple-400" />
              <span>AI Question & Recap Generator</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-2 border-b border-slate-800 text-xs font-bold scrollbar-none">
        {[
          { id: 'all', label: 'All AMAs', icon: Mic },
          { id: 'live', label: '🔴 Live AMA', icon: Radio },
          { id: 'upcoming', label: '📅 Upcoming', icon: Calendar },
          { id: 'ended', label: '✅ Ended', icon: CheckCircle },
          { id: 'recaps', label: '📰 Recaps', icon: FileText },
          { id: 'archive', label: '📂 Archive', icon: Archive },
          { id: 'speakers', label: '🎤 Speakers', icon: Users },
          { id: 'giveaways', label: '🎁 Giveaways', icon: Gift },
          { id: 'stats', label: '📊 Statistics', icon: BarChart3 }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl whitespace-nowrap flex items-center space-x-1.5 transition-all ${
                isActive 
                  ? 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/20' 
                  : 'bg-slate-900 border border-slate-800 text-slate-300 hover:border-amber-500/40'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search AMAs by project or topic..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Category Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedCategory === cat 
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' 
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Active Listings Counter Header */}
      <div className="flex items-center justify-between text-xs font-mono font-bold text-slate-400">
        <span>Showing <strong className="text-amber-400 font-extrabold">{filteredAmas.length}</strong> AMA Event Listings</span>
        {(selectedCategory !== 'All' || activeTab !== 'all' || searchQuery) && (
          <button
            onClick={() => {
              setSelectedCategory('All');
              setActiveTab('all');
              setSearchQuery('');
            }}
            className="text-amber-400 hover:underline cursor-pointer"
          >
            Clear Filters
          </button>
        )}
      </div>

      {/* AMAs Grid or Empty State */}
      {filteredAmas.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-4 max-w-lg mx-auto my-6">
          <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-2xl flex items-center justify-center mx-auto">
            <Mic className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-white">No AMAs Found in This Filter</h3>
          <p className="text-xs text-slate-400 font-mono">No AMA listings match your selected category or filter tab.</p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setActiveTab('all');
              setSearchQuery('');
            }}
            className="px-5 py-2.5 bg-amber-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 cursor-pointer"
          >
            Show All {amas.length} AMA Listings
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {filteredAmas.map((ama) => (
          <div 
            key={ama.id}
            className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden hover:border-amber-500/40 transition-all flex flex-col justify-between group"
          >
            {ama.bannerUrl && (
              <div className="relative h-32 w-full overflow-hidden border-b border-slate-800">
                <img src={ama.bannerUrl} alt={ama.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-black/40" />
              </div>
            )}

            <div className="p-6 space-y-4">
              {/* Header Badge */}
              <div className="flex items-center justify-between">
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase flex items-center space-x-1 border ${
                  ama.status === 'live' 
                    ? 'bg-red-950 text-red-300 border-red-500/40 animate-pulse' 
                    : ama.status === 'upcoming' 
                      ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' 
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}>
                  <Radio className="w-3 h-3" />
                  <span>{ama.status === 'live' ? '🔴 LIVE NOW' : ama.status === 'upcoming' ? '📅 UPCOMING' : '✅ ENDED'}</span>
                </span>

                <span className="text-xs font-bold text-amber-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                  {ama.category}
                </span>
              </div>

              {/* Title & Logo */}
              <div className="flex space-x-4">
                <img src={ama.projectLogo} alt={ama.projectName} className="w-12 h-12 rounded-xl object-cover border border-amber-500/30 shrink-0" />
                <div>
                  <h3 className="font-extrabold text-white text-base leading-snug group-hover:text-amber-400 transition-colors">
                    {ama.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Platform: <span className="text-slate-200 font-semibold">{ama.platform}</span>
                  </p>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed line-clamp-2 mb-3">
                {ama.description}
              </p>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Reward Pool:</span>
                  <span className="font-bold text-amber-400">{ama.rewardPool}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Speakers:</span>
                  <span className="text-slate-300 truncate max-w-[200px]">{ama.guestSpeakers.join(', ')}</span>
                </div>
              </div>
            </div>

            {/* Card Footer Actions */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-500 flex items-center space-x-1">
                <Users className="w-3.5 h-3.5 text-amber-400" />
                <span>{ama.viewsCount.toLocaleString()} Listeners</span>
              </span>

              <button
                onClick={() => setSelectedAma(ama)}
                className="px-4 py-2 bg-amber-500/10 hover:bg-amber-500 hover:text-slate-950 text-amber-400 border border-amber-500/30 font-bold text-xs rounded-xl transition-all flex items-center space-x-1"
              >
                <span>View Event Details</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
      )}

      {/* Modal Detail for Selected AMA */}
      {selectedAma && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 overflow-y-auto">
          <div className="w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-3xl p-6 shadow-2xl relative text-slate-100 my-8">
            <button
              onClick={() => setSelectedAma(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              ✕
            </button>

            <div className="flex items-center space-x-4 mb-4">
              <img src={selectedAma.projectLogo} alt={selectedAma.projectName} className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-500/40" />
              <div>
                <span className="text-xs font-bold text-amber-400">{selectedAma.category} • {selectedAma.platform}</span>
                <h3 className="text-xl font-black text-white">{selectedAma.title}</h3>
                <p className="text-xs text-slate-400">Scheduled: {new Date(selectedAma.scheduledAt).toLocaleString()}</p>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                <h4 className="font-bold text-amber-400 uppercase">Event Overview</h4>
                <p className="text-slate-300 leading-relaxed">{selectedAma.description}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 uppercase font-bold">Reward Pool</span>
                  <p className="font-black text-amber-400 text-sm">{selectedAma.rewardPool}</p>
                </div>
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-slate-500 uppercase font-bold">Guest Speakers</span>
                  <p className="font-bold text-slate-200">{selectedAma.guestSpeakers.join(', ')}</p>
                </div>
              </div>

              {selectedAma.recapText && (
                <div className="bg-purple-950/40 p-4 rounded-2xl border border-purple-500/30 space-y-2">
                  <h4 className="font-bold text-purple-300 flex items-center space-x-1.5">
                    <Sparkles className="w-4 h-4" />
                    <span>AI-Generated Recap & Key Takeaways</span>
                  </h4>
                  <p className="text-slate-300 leading-relaxed">{selectedAma.recapText}</p>
                </div>
              )}

              <div className="flex space-x-2 pt-2">
                <a
                  href={selectedAma.recordingUrl || selectedAma.liveStreamUrl || "https://t.me/CryptoMonsterClashGlobal"}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-black text-center text-xs rounded-xl shadow-lg hover:brightness-110"
                >
                  Join / Listen Stream on {selectedAma.platform.split(' ')[0]}
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
