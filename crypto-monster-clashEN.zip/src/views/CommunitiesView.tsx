import React, { useState } from 'react';
import { Users, ShieldCheck, ExternalLink, Search, Send, Twitter, MessageSquare } from 'lucide-react';
import { CommunityItem } from '../types';

interface CommunitiesViewProps {
  communities: CommunityItem[];
}

export const CommunitiesView: React.FC<CommunitiesViewProps> = ({ communities }) => {
  const [selectedPlatform, setSelectedPlatform] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = communities.filter(c => {
    const matchesPlatform = selectedPlatform === 'All' || c.platform === selectedPlatform;
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesPlatform && matchesSearch;
  });

  return (
    <div className="space-y-8 pb-12 text-slate-100">
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl text-center space-y-2">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
          Partner Hubs
        </span>
        <h1 className="text-3xl font-black text-white">Featured & Verified Communities</h1>
        <p className="text-xs text-slate-400">Join active Web3 Telegram groups, Discord servers & X Space hubs</p>
      </div>

      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search communities..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div className="flex items-center space-x-2">
          {['All', 'Telegram', 'X', 'Discord'].map((p) => (
            <button
              key={p}
              onClick={() => setSelectedPlatform(p)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                selectedPlatform === p 
                  ? 'bg-amber-500 text-slate-950' 
                  : 'bg-slate-900 border border-slate-800 text-slate-300'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {filtered.map((comm) => (
          <div key={comm.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex items-center justify-between hover:border-amber-500/40 transition-all">
            <div className="flex items-center space-x-4">
              <img src={comm.logo} alt={comm.name} className="w-12 h-12 rounded-2xl object-cover border border-amber-500/30" />
              <div>
                <div className="flex items-center space-x-1.5">
                  <h3 className="font-extrabold text-white text-base">{comm.name}</h3>
                  {comm.isVerified && <ShieldCheck className="w-4 h-4 text-amber-400" />}
                </div>
                <p className="text-xs text-amber-400 font-bold mt-0.5">{comm.membersCount.toLocaleString()} Members</p>
                <p className="text-[11px] text-slate-400">{comm.category} • {comm.platform}</p>
              </div>
            </div>

            <a
              href={comm.link}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs rounded-xl shadow-md hover:brightness-110 flex items-center space-x-1 shrink-0"
            >
              <span>Join Community</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};
