import React, { useState } from 'react';
import { Gift, CheckCircle, Clock, Wallet, Trophy, Sparkles, Send, Twitter, ArrowRight } from 'lucide-react';
import { GiveawayItem, UserProfile } from '../types';

interface GiveawaysViewProps {
  giveaways: GiveawayItem[];
  currentUser: UserProfile | null;
  onOpenAuth: () => void;
}

export const GiveawaysView: React.FC<GiveawaysViewProps> = ({
  giveaways,
  currentUser,
  onOpenAuth
}) => {
  const [completedTaskIds, setCompletedTaskIds] = useState<string[]>([]);
  const [userXp, setUserXp] = useState(currentUser?.xp || 200);
  const [walletInput, setWalletInput] = useState(currentUser?.walletAddress || '');
  const [claimedDaily, setClaimedDaily] = useState(false);

  const toggleTask = (taskId: string) => {
    if (completedTaskIds.includes(taskId)) {
      setCompletedTaskIds(completedTaskIds.filter(id => id !== taskId));
    } else {
      setCompletedTaskIds([...completedTaskIds, taskId]);
      setUserXp(prev => prev + 50);
    }
  };

  const handleDailySpin = () => {
    if (claimedDaily) return;
    const bonusXp = 100;
    setUserXp(prev => prev + bonusXp);
    setClaimedDaily(true);
  };

  return (
    <div className="space-y-8 pb-12 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/30 p-8 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
            Quest & Task Engine
          </span>
          <h1 className="text-3xl font-black text-white mt-2">Crypto Giveaways & Airdrop Quests</h1>
          <p className="text-xs text-slate-400 mt-1">Complete Web3 social quests, accumulate XP, and win USDT prize pools</p>
        </div>

        {/* User XP Badge & Daily Claim */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl flex items-center space-x-4">
          <div>
            <span className="text-[10px] text-slate-500 font-bold uppercase">Your Quest XP</span>
            <p className="text-xl font-black text-amber-400">{userXp} XP</p>
          </div>
          <button
            onClick={handleDailySpin}
            disabled={claimedDaily}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              claimedDaily 
                ? 'bg-slate-900 text-slate-500 border border-slate-800' 
                : 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-lg hover:brightness-110'
            }`}
          >
            {claimedDaily ? '✅ Daily Claimed' : '🎁 Claim +100 XP Daily'}
          </button>
        </div>
      </div>

      {/* Giveaways List */}
      <div className="space-y-6">
        {giveaways.map((gw) => (
          <div key={gw.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-4">
                <img src={gw.projectLogo} alt={gw.projectName} className="w-14 h-14 rounded-2xl object-cover border border-amber-500/30" />
                <div>
                  <h3 className="font-extrabold text-white text-lg">{gw.title}</h3>
                  <p className="text-xs text-amber-400 font-black mt-0.5">
                    Prize Pool: {gw.prizePool} ({gw.winnersCount} Winners)
                  </p>
                </div>
              </div>

              <div className="text-left sm:text-right">
                <span className="text-xs font-bold text-slate-400 flex items-center space-x-1 sm:justify-end">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Ends in 7 Days</span>
                </span>
                <p className="text-[10px] text-slate-500 mt-0.5">{gw.participantsCount.toLocaleString()} Participants Joined</p>
              </div>
            </div>

            {/* Task Checklist */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">Required Social Quests</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {gw.tasks.map((task) => {
                  const isDone = completedTaskIds.includes(task.id);
                  return (
                    <div 
                      key={task.id} 
                      onClick={() => toggleTask(task.id)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                        isDone 
                          ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200' 
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-amber-500/40'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                          isDone ? 'bg-emerald-500 border-emerald-400 text-slate-950' : 'border-slate-700'
                        }`}>
                          {isDone && <CheckCircle className="w-3.5 h-3.5" />}
                        </div>
                        <span className="text-xs font-semibold">{task.title}</span>
                      </div>
                      <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                        +50 XP
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Wallet Address Entry */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-slate-300 mb-1">Enter Your BEP20 / TRC20 Wallet Address for Reward Payout</label>
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="0x..."
                  value={walletInput}
                  onChange={(e) => setWalletInput(e.target.value)}
                  className="flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400 font-mono"
                />
                <button
                  onClick={() => alert(`Wallet address ${walletInput} submitted for giveaway entry!`)}
                  className="px-5 py-2.5 bg-amber-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-md hover:bg-amber-400"
                >
                  Submit Entry
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
