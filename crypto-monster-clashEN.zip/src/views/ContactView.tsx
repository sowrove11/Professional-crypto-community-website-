import React, { useState } from 'react';
import { Mail, Send, Twitter, Globe, MessageSquare, ExternalLink, ShieldCheck, Check, Calendar } from 'lucide-react';

interface ContactViewProps {
  onOpenBookModal: () => void;
}

export const ContactView: React.FC<ContactViewProps> = ({ onOpenBookModal }) => {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [telegram, setTelegram] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="space-y-10 pb-12 text-slate-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/30 p-8 rounded-3xl text-center space-y-2">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
          Direct Inquiries
        </span>
        <h1 className="text-3xl font-black text-white">Contact Crypto Monster Clash Team</h1>
        <p className="text-xs text-slate-400">Get in touch with our Booking Managers & Web3 Marketing Directors</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Contact Info Cards */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4">
            <h3 className="font-extrabold text-white text-base border-b border-slate-800 pb-2">
              Official Contact Handles
            </h3>

            <div className="space-y-3 text-xs">
              <div className="p-4 bg-slate-950 rounded-2xl border border-amber-500/30 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Booking Manager</span>
                  <p className="text-base font-black text-amber-400">@CalvinHarrison</p>
                </div>
                <a
                  href="https://t.me/CalvinHarrison"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 bg-amber-500 text-slate-950 font-bold rounded-xl"
                >
                  Direct Chat
                </a>
              </div>

              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center space-x-3">
                <Mail className="w-5 h-5 text-amber-400" />
                <div>
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Email Support</span>
                  <p className="font-bold text-slate-200">cryptomonster231@gmail.com</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl space-y-4">
            <h3 className="font-extrabold text-white text-base border-b border-slate-800 pb-2">
              Official Community Channels
            </h3>

            <div className="space-y-2 text-xs">
              <a 
                href="https://t.me/CryptoMonsterClashGlobal" 
                target="_blank" 
                rel="noreferrer"
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between hover:border-amber-400 transition-all"
              >
                <div className="flex items-center space-x-2">
                  <Send className="w-4 h-4 text-amber-400" />
                  <span className="font-bold text-slate-200">Telegram Community (150K+)</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
              </a>

              <a 
                href="https://t.me/CryptoMonsterClashAnn" 
                target="_blank" 
                rel="noreferrer"
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between hover:border-amber-400 transition-all"
              >
                <div className="flex items-center space-x-2">
                  <Send className="w-4 h-4 text-amber-400" />
                  <span className="font-bold text-slate-200">Telegram Announcements</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
              </a>

              <a 
                href="https://x.com/MonsterClashX" 
                target="_blank" 
                rel="noreferrer"
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between hover:border-amber-400 transition-all"
              >
                <div className="flex items-center space-x-2">
                  <Twitter className="w-4 h-4 text-amber-400" />
                  <span className="font-bold text-slate-200">X (Twitter) Official (@MonsterClashX)</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
              </a>

              <a 
                href="https://www.binance.com/en/square/profile/zakariahabib" 
                target="_blank" 
                rel="noreferrer"
                className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between hover:border-amber-400 transition-all"
              >
                <div className="flex items-center space-x-2">
                  <Globe className="w-4 h-4 text-amber-400" />
                  <span className="font-bold text-slate-200">Binance Square Profile (@zakariahabib)</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
              </a>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl space-y-4">
          <h3 className="font-extrabold text-white text-lg">Send Us a Direct Message</h3>
          
          {submitted ? (
            <div className="p-6 bg-emerald-950/60 border border-emerald-500/40 rounded-2xl text-center space-y-2 text-xs">
              <Check className="w-8 h-8 text-emerald-400 mx-auto" />
              <h4 className="font-bold text-white text-base">Message Sent!</h4>
              <p className="text-slate-300">Booking Manager @CalvinHarrison will reach out to you within 2 hours.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Your Name / Handle *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Satoshi"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Telegram Handle</label>
                <input
                  type="text"
                  placeholder="@yourhandle"
                  value={telegram}
                  onChange={(e) => setTelegram(e.target.value)}
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Message / Inquiry *</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Tell us about your project, preferred AMA dates, custom marketing needs..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full p-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-200"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-extrabold rounded-xl shadow-lg hover:brightness-110"
              >
                Send Message
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
