import React, { useState } from 'react';
import { Rocket, ShieldCheck, ExternalLink, ThumbsUp, Search, PlusCircle, Flame, Globe, Send, Twitter } from 'lucide-react';
import { ProjectItem } from '../types';

interface ProjectsViewProps {
  projects: ProjectItem[];
}

export const ProjectsView: React.FC<ProjectsViewProps> = ({ projects: initialProjects }) => {
  const [projectsList, setProjectsList] = useState<ProjectItem[]>(initialProjects);
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [votedIds, setVotedIds] = useState<string[]>([]);
  const [isSubmitOpen, setIsSubmitOpen] = useState(false);

  // New Project Form
  const [newProjectName, setNewProjectName] = useState('');
  const [newTicker, setNewTicker] = useState('');
  const [newCategory, setNewCategory] = useState<'AI' | 'Gaming' | 'Meme' | 'DeFi' | 'NFT' | 'RWA' | 'Infrastructure' | 'Exchange'>('AI');
  const [newDesc, setNewDesc] = useState('');
  const [newWebsite, setNewWebsite] = useState('');

  const categories = ['All', 'AI', 'Gaming', 'Meme', 'DeFi', 'NFT', 'RWA', 'Infrastructure', 'Exchange'];

  const handleVote = (id: string) => {
    if (votedIds.includes(id)) return;
    setProjectsList(prev => prev.map(p => p.id === id ? { ...p, votesCount: p.votesCount + 1 } : p));
    setVotedIds(prev => [...prev, id]);
  };

  const handleAddProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProjectName) return;
    const created: ProjectItem = {
      id: `proj-${Date.now()}`,
      name: newProjectName,
      ticker: newTicker || newProjectName.slice(0, 4).toUpperCase(),
      logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
      category: newCategory,
      description: newDesc,
      websiteUrl: newWebsite || "https://monsterclash.io",
      telegramUrl: "https://t.me/CryptoMonsterClashGlobal",
      twitterUrl: "https://x.com/MonsterClashX",
      marketCap: "$1.0M",
      isFeatured: false,
      isTrending: true,
      isVerified: false,
      votesCount: 1
    };
    setProjectsList(prev => [created, ...prev]);
    setIsSubmitOpen(false);
    setNewProjectName('');
    setNewDesc('');
  };

  const filtered = projectsList.filter(p => {
    const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.ticker.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-8 pb-12 text-slate-100">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
            Web3 Ecosystem Directory
          </span>
          <h1 className="text-3xl font-black text-white mt-2">Projects Accelerating on Monster Clash</h1>
          <p className="text-xs text-slate-400 mt-1">Discover verified AI, Gaming, Meme, DeFi & RWA protocols</p>
        </div>
        <button
          onClick={() => setIsSubmitOpen(true)}
          className="px-5 py-3 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 flex items-center space-x-2 shrink-0"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Submit Your Project</span>
        </button>
      </div>

      {/* Filter & Search */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div className="flex items-center space-x-1.5 overflow-x-auto w-full md:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                activeCategory === cat
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                  : 'bg-slate-900 text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.map((proj) => (
          <div key={proj.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between space-y-4 hover:border-amber-500/30 transition-all">
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3">
                <img src={proj.logo} alt={proj.name} className="w-12 h-12 rounded-xl object-cover border border-amber-500/30" />
                <div>
                  <div className="flex items-center space-x-1.5">
                    <h3 className="font-extrabold text-white text-base">{proj.name}</h3>
                    <span className="text-xs text-slate-400 font-mono">(${proj.ticker})</span>
                    {proj.isVerified && <ShieldCheck className="w-4 h-4 text-amber-400" title="Verified Project" />}
                  </div>
                  <span className="text-[10px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                    {proj.category}
                  </span>
                </div>
              </div>

              <button
                onClick={() => handleVote(proj.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all ${
                  votedIds.includes(proj.id)
                    ? 'bg-emerald-500 text-slate-950'
                    : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-amber-400'
                }`}
              >
                <ThumbsUp className="w-3.5 h-3.5" />
                <span>{proj.votesCount}</span>
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">{proj.description}</p>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2">
                <a href={proj.websiteUrl} target="_blank" rel="noreferrer" className="p-2 rounded-lg bg-slate-950 text-amber-400 hover:bg-amber-500 hover:text-slate-950">
                  <Globe className="w-3.5 h-3.5" />
                </a>
                <a href={proj.telegramUrl} target="_blank" rel="noreferrer" className="p-2 rounded-lg bg-slate-950 text-amber-400 hover:bg-amber-500 hover:text-slate-950">
                  <Send className="w-3.5 h-3.5" />
                </a>
                <a href={proj.twitterUrl} target="_blank" rel="noreferrer" className="p-2 rounded-lg bg-slate-950 text-amber-400 hover:bg-amber-500 hover:text-slate-950">
                  <Twitter className="w-3.5 h-3.5" />
                </a>
              </div>
              <span className="text-xs font-black text-amber-400">Cap: {proj.marketCap}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Submit Project Modal */}
      {isSubmitOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl relative text-slate-100 space-y-4">
            <h3 className="text-xl font-black text-white">Submit Web3 Project</h3>
            <form onSubmit={handleAddProject} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Project Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monster AI Chain"
                  value={newProjectName}
                  onChange={(e) => setNewProjectName(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200"
                >
                  {categories.filter(c => c !== 'All').map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Project overview..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full p-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-200"
                />
              </div>

              <div className="flex space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSubmitOpen(false)}
                  className="w-1/2 py-2.5 bg-slate-950 border border-slate-800 rounded-xl font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 bg-amber-500 text-slate-950 font-black rounded-xl"
                >
                  Add Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
