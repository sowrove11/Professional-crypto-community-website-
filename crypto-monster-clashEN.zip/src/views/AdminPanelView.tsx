import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  BarChart3, 
  DollarSign, 
  Users, 
  Mic, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Settings, 
  Plus, 
  FileText, 
  Lock, 
  Flame, 
  CreditCard,
  Edit,
  Trash2,
  Eye,
  Send,
  AlertTriangle,
  RefreshCw,
  Gift,
  Globe,
  Layout,
  Save,
  Radio,
  Tag,
  Upload,
  Image as ImageIcon,
  Sparkles,
  TrendingUp,
  Rocket,
  Layers,
  Wallet
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { 
  AMAItem, 
  AMABooking, 
  ServiceItem, 
  SiteConfig, 
  GiveawayItem, 
  ProjectItem, 
  CommunityItem 
} from '../types';
import { HeroPaymentAdmin } from '../components/admin/HeroPaymentAdmin';
import { SectionVisibilityAdmin } from '../components/admin/SectionVisibilityAdmin';
import { AmaManagerAdmin } from '../components/admin/AmaManagerAdmin';
import { LiveStudioAdmin } from '../components/admin/LiveStudioAdmin';

interface AdminPanelViewProps {
  siteConfig: SiteConfig;
  onUpdateSiteConfig: (config: SiteConfig) => void;
  amas: AMAItem[];
  onAddAma: (ama: AMAItem) => void;
  onUpdateAma: (ama: AMAItem) => void;
  onDeleteAma: (id: string) => void;
  services: ServiceItem[];
  onAddService: (service: ServiceItem) => void;
  onUpdateService: (service: ServiceItem) => void;
  onDeleteService: (id: string) => void;
  giveaways: GiveawayItem[];
  onAddGiveaway: (gw: GiveawayItem) => void;
  onDeleteGiveaway: (id: string) => void;
  projects: ProjectItem[];
  onAddProject: (proj: ProjectItem) => void;
  onDeleteProject: (id: string) => void;
  communities: CommunityItem[];
  onAddCommunity: (comm: CommunityItem) => void;
  onDeleteCommunity: (id: string) => void;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({
  siteConfig,
  onUpdateSiteConfig,
  amas,
  onAddAma,
  onUpdateAma,
  onDeleteAma,
  services,
  onAddService,
  onUpdateService,
  onDeleteService,
  giveaways,
  onAddGiveaway,
  onDeleteGiveaway,
  projects,
  onAddProject,
  onDeleteProject,
  communities,
  onAddCommunity,
  onDeleteCommunity
}) => {
  const [activeAdminTab, setActiveAdminTab] = useState<
    'banners' | 'sections' | 'amas' | 'livestudio' | 'services' | 'giveaways' | 'projects' | 'bookings' | 'analytics' | 'settings'
  >('banners');

  // Service Edit / Add State
  const [editingService, setEditingService] = useState<ServiceItem | null>(null);
  const [srvTitle, setSrvTitle] = useState('');
  const [srvCategory, setSrvCategory] = useState<any>('AMA Services');
  const [srvPrice, setSrvPrice] = useState(499);
  const [srvDesc, setSrvDesc] = useState('');
  const [srvFeatures, setSrvFeatures] = useState('');
  const [srvIcon, setSrvIcon] = useState('Flame');
  const [srvPopular, setSrvPopular] = useState(false);

  // Giveaway Add State
  const [gwTitle, setGwTitle] = useState('');
  const [gwProject, setGwProject] = useState('');
  const [gwPrize, setGwPrize] = useState('$1,000 USDT');

  // Project Add State
  const [projName, setProjName] = useState('');
  const [projTicker, setProjTicker] = useState('');
  const [projCategory, setProjCategory] = useState<any>('AI');
  const [projMarketCap, setProjMarketCap] = useState('$10M');

  // Maintenance mode
  const [maintenanceMode, setMaintenanceMode] = useState(false);

  // Revenue Analytics derived strictly from actual live dataset
  const [bookingsList, setBookingsList] = useState<AMABooking[]>(() => {
    const saved = localStorage.getItem('cmc_bookings');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('cmc_bookings', JSON.stringify(bookingsList));
  }, [bookingsList]);

  // Real analytics calculations
  const realApprovedRevenue = bookingsList
    .filter(b => b.bookingStatus === 'Approved' || b.paymentStatus === 'verified')
    .reduce((sum, b) => sum + (b.priceUsdt || 0), 0);

  const realPendingOrders = bookingsList.filter(b => b.bookingStatus === 'Pending').length;

  const handleApproveBooking = (id: string) => {
    setBookingsList(prev => prev.map(b => b.id === id ? { ...b, bookingStatus: 'Approved', paymentStatus: 'verified' } : b));
  };

  const handleRejectBooking = (id: string) => {
    setBookingsList(prev => prev.map(b => b.id === id ? { ...b, bookingStatus: 'Rejected' } : b));
  };

  const handleSaveService = (e: React.FormEvent) => {
    e.preventDefault();
    if (!srvTitle) return;

    const featureArr = srvFeatures ? srvFeatures.split(',').map(f => f.trim()) : ["Custom Web3 Promotion"];

    if (editingService) {
      const updated: ServiceItem = {
        ...editingService,
        title: srvTitle,
        category: srvCategory,
        priceUsdt: srvPrice,
        description: srvDesc,
        features: featureArr,
        iconName: srvIcon,
        popular: srvPopular
      };
      onUpdateService(updated);
      setEditingService(null);
      alert("Service Package Updated!");
    } else {
      const newSrv: ServiceItem = {
        id: `srv-${Date.now()}`,
        title: srvTitle,
        category: srvCategory,
        priceUsdt: srvPrice,
        description: srvDesc || "Web3 growth service package",
        features: featureArr,
        iconName: srvIcon || "Flame",
        popular: srvPopular
      };
      onAddService(newSrv);
      alert("New Service Package Created!");
    }

    setSrvTitle('');
    setSrvDesc('');
    setSrvFeatures('');
    setSrvPopular(false);
  };

  const startEditService = (s: ServiceItem) => {
    setEditingService(s);
    setSrvTitle(s.title);
    setSrvCategory(s.category);
    setSrvPrice(s.priceUsdt);
    setSrvDesc(s.description);
    setSrvFeatures(s.features.join(', '));
    setSrvIcon(s.iconName || 'Flame');
    setSrvPopular(!!s.popular);
  };

  const handleAddGiveawayForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gwTitle || !gwProject) return;
    const newGw: GiveawayItem = {
      id: `gw-${Date.now()}`,
      title: gwTitle,
      projectName: gwProject,
      projectLogo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
      prizePool: gwPrize,
      winnersCount: 20,
      status: "live",
      endsAt: "2026-08-30T23:59:59Z",
      participantsCount: 100,
      tasks: [
        { id: "t1", title: "Join Telegram Global", type: "telegram", link: siteConfig.telegramLink },
        { id: "t2", title: "Follow Twitter", type: "twitter", link: siteConfig.twitterLink }
      ]
    };
    onAddGiveaway(newGw);
    setGwTitle('');
    setGwProject('');
    alert("New Giveaway Published Live!");
  };

  const handleAddProjectForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projName || !projTicker) return;
    const newProj: ProjectItem = {
      id: `proj-${Date.now()}`,
      name: projName,
      ticker: projTicker,
      logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
      category: projCategory,
      description: "Verified Web3 project directory listing.",
      websiteUrl: "https://monsterclash.io",
      telegramUrl: siteConfig.telegramLink,
      twitterUrl: siteConfig.twitterLink,
      marketCap: projMarketCap,
      isVerified: true,
      isTrending: true,
      votesCount: 150
    };
    onAddProject(newProj);
    setProjName('');
    setProjTicker('');
    alert("Project Added to Directory!");
  };

  return (
    <div className="space-y-6 pb-12 text-slate-100">
      {/* Admin Header Card */}
      <div className="bg-[#141416] border border-[#00FF94]/30 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-2xl">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-[#00FF94]/10 border border-[#00FF94]/30 text-[#00FF94] flex items-center justify-center font-black">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-2xl font-black text-white">Master Site Admin & Content Control</h1>
              <span className="bg-[#00FF94]/20 text-[#00FF94] text-[10px] font-mono font-bold px-2 py-0.5 rounded border border-[#00FF94]/40">
                MASTER ROOT
              </span>
            </div>
            <p className="text-xs text-gray-400 font-mono">Full site editability: Hero, Payment Gateway, AMAs, Live Studio, Section Visibility, Packages, Quests, Orders & Analytics</p>
          </div>
        </div>

        {/* Maintenance Toggle */}
        <div className="flex items-center space-x-3 bg-[#0A0A0B] p-2.5 rounded-2xl border border-white/10">
          <span className="text-xs font-mono font-bold text-gray-300">Maintenance Mode:</span>
          <button
            onClick={() => setMaintenanceMode(!maintenanceMode)}
            className={`px-3 py-1 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
              maintenanceMode ? 'bg-red-500 text-white' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}
          >
            {maintenanceMode ? '🚨 ENABLED' : '🟢 NORMAL (ONLINE)'}
          </button>
        </div>
      </div>

      {/* Admin Nav Tabs */}
      <div className="flex space-x-2 border-b border-white/10 pb-2 text-xs font-mono font-bold overflow-x-auto">
        {[
          { id: 'banners', label: '🎨 Hero & Payment Config', icon: Wallet },
          { id: 'sections', label: '🎛 Homepage Sections Toggle', icon: Layers },
          { id: 'amas', label: '🎙 AMA Manager', icon: Mic },
          { id: 'livestudio', label: '🔴 Live Broadcast Studio', icon: Radio },
          { id: 'services', label: '💼 Services & Pricing', icon: DollarSign },
          { id: 'giveaways', label: '🎁 Quests & Giveaways', icon: Gift },
          { id: 'projects', label: '🚀 Projects Directory', icon: Globe },
          { id: 'bookings', label: '📋 Client Orders', icon: Calendar },
          { id: 'analytics', label: '📊 Revenue & Analytics', icon: BarChart3 },
          { id: 'settings', label: '⚙️ System Settings', icon: Settings },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeAdminTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveAdminTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl whitespace-nowrap flex items-center space-x-1.5 transition-all cursor-pointer ${
                isActive 
                  ? 'bg-[#00FF94] text-black font-black shadow-lg shadow-[#00FF94]/20' 
                  : 'bg-[#141416] border border-white/10 text-gray-300 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. HERO & PAYMENT CONFIG TAB */}
      {activeAdminTab === 'banners' && (
        <HeroPaymentAdmin siteConfig={siteConfig} onSave={onUpdateSiteConfig} />
      )}

      {/* 2. HOMEPAGE SECTION VISIBILITY TOGGLES TAB */}
      {activeAdminTab === 'sections' && (
        <SectionVisibilityAdmin siteConfig={siteConfig} onSave={onUpdateSiteConfig} />
      )}

      {/* 3. AMA MANAGER TAB */}
      {activeAdminTab === 'amas' && (
        <AmaManagerAdmin
          amas={amas}
          onAddAma={onAddAma}
          onUpdateAma={onUpdateAma}
          onDeleteAma={onDeleteAma}
        />
      )}

      {/* 4. LIVE BROADCAST STUDIO CONTROL ROOM */}
      {activeAdminTab === 'livestudio' && (
        <LiveStudioAdmin amas={amas} onUpdateAma={onUpdateAma} />
      )}

      {/* 5. SERVICES & PRICING PACKAGES TAB */}
      {activeAdminTab === 'services' && (
        <div className="space-y-6">
          {/* Quick Add Crypto Package Presets */}
          <div className="bg-[#141416] border border-[#00FF94]/30 p-5 rounded-3xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-[#00FF94]" />
                <h3 className="font-extrabold text-white text-sm">⚡ 1-Click Preset Crypto Marketing Packages</h3>
              </div>
              <span className="text-[10px] bg-[#00FF94]/20 text-[#00FF94] px-2 py-0.5 rounded font-mono font-bold">UNLIMITED CREATION</span>
            </div>
            <p className="text-xs text-gray-400">Click any high-value crypto service below to instantly add it to your live platform menu:</p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono">
              {[
                { title: "DexScreener Trending #1", cat: "Marketing Services", price: 950, icon: "TrendingUp", popular: true, desc: "DexScreener frontpage trending + 24h search boost", features: ["12 Hours Top 3 Trending", "Banner graphic ad placement", "Direct buy link integration"] },
                { title: "CoinMarketCap Top 3 Fast-Track", cat: "Marketing Services", price: 1850, icon: "Flame", popular: true, desc: "CoinMarketCap search bar trending & most visited list", features: ["Guaranteed CMC Top 3", "24 Hours duration", "Fast listing support"] },
                { title: "Twitter KOL Raid (50+ Influencers)", cat: "Promotions", price: 2400, icon: "Rocket", popular: false, desc: "50+ Verified Crypto KOLs quote-retweet & raid thread", features: ["50+ Tier-1 KOLs", "250K+ combined reach", "Trending hashtag push"] },
                { title: "Telegram Voice AMA + 150K Push", cat: "AMA Services", price: 899, icon: "Mic", popular: true, desc: "Hosted live voice AMA with 150,000+ active crypto investors", features: ["1 Hour Voice AMA", "$500 USDT Giveaway Pool", "AI Audio Recording & Summary"] },
                { title: "Press Release on Yahoo Finance", cat: "Marketing Services", price: 2150, icon: "Globe", popular: false, desc: "Guaranteed press release publication on Yahoo Finance & Bloomberg", features: ["Yahoo Finance & MarketWatch", "SEO backlinks", "Permanent article URL"] },
                { title: "Guaranteed Tier-2 CEX Listing", cat: "Community Growth", price: 8500, icon: "Award", popular: false, desc: "Direct listing application & market maker introduction for CEX", features: ["BitMart / MEXC fast track", "Market maker intro", "Co-marketing campaign"] },
                { title: "Binance Square Article & Banner", cat: "AMA Services", price: 1290, icon: "Radio", popular: false, desc: "Binance Square official verified announcement post and live chat", features: ["Binance Square Featured", "100K Impressions guarantee", "Post-event article recap"] },
                { title: "Coingecko Top 5 Trending", cat: "Marketing Services", price: 1400, icon: "TrendingUp", popular: false, desc: "Coingecko front page search & trending list", features: ["Coingecko Top 5", "Fast-track 24h approval", "Mobile app banner placement"] }
              ].map((preset, i) => (
                <button
                  key={i}
                  onClick={() => {
                    const newSrv: ServiceItem = {
                      id: `srv-preset-${Date.now()}-${i}`,
                      title: preset.title,
                      category: preset.cat as any,
                      priceUsdt: preset.price,
                      description: preset.desc,
                      features: preset.features,
                      iconName: preset.icon,
                      popular: true
                    };
                    onAddService(newSrv);
                    alert(`Added "${preset.title}" live!`);
                  }}
                  className="p-3 bg-[#0A0A0B] border border-white/10 hover:border-[#00FF94] rounded-2xl text-left space-y-1 transition-all group cursor-pointer"
                >
                  <div className="flex justify-between items-center">
                    <span className="font-extrabold text-white text-xs group-hover:text-[#00FF94] truncate">{preset.title}</span>
                    <span className="font-black text-[#00FF94] text-xs">${preset.price}</span>
                  </div>
                  <p className="text-[10px] text-gray-400 truncate">{preset.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Add / Edit Service Form */}
          <form onSubmit={handleSaveService} className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 text-xs font-mono">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-extrabold text-white text-base">
                {editingService ? '✏️ Edit Marketing Package' : '➕ Add Custom Service Package'}
              </h3>
              {editingService && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingService(null);
                    setSrvTitle('');
                    setSrvDesc('');
                    setSrvFeatures('');
                    setSrvPopular(false);
                  }}
                  className="text-xs text-gray-400 hover:text-white underline cursor-pointer"
                >
                  Cancel Editing
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-gray-300 font-bold mb-1">Package Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. DexScreener Trending #1"
                  value={srvTitle}
                  onChange={(e) => setSrvTitle(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">Category</label>
                <select
                  value={srvCategory}
                  onChange={(e) => setSrvCategory(e.target.value as any)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                >
                  <option value="AMA Services">AMA Services</option>
                  <option value="Marketing Services">Marketing Services</option>
                  <option value="Community Growth">Community Growth</option>
                  <option value="Promotions">Promotions</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">Price in USDT ($) *</label>
                <input
                  type="number"
                  required
                  value={srvPrice}
                  onChange={(e) => setSrvPrice(parseInt(e.target.value) || 0)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">Icon Style</label>
                <select
                  value={srvIcon}
                  onChange={(e) => setSrvIcon(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                >
                  <option value="Flame">Flame 🔥</option>
                  <option value="Mic">Microphone 🎙</option>
                  <option value="TrendingUp">Trending Up 📈</option>
                  <option value="Rocket">Rocket 🚀</option>
                  <option value="Globe">Globe 🌐</option>
                  <option value="Award">Award Badge 🏆</option>
                </select>
              </div>

              <div className="flex items-center space-x-2 pt-6">
                <input
                  type="checkbox"
                  id="srvPopular"
                  checked={srvPopular}
                  onChange={(e) => setSrvPopular(e.target.checked)}
                  className="w-4 h-4 accent-[#00FF94] rounded"
                />
                <label htmlFor="srvPopular" className="text-gray-200 font-bold cursor-pointer">
                  Tag as "🔥 POPULAR CHOICE" Badge
                </label>
              </div>

              <div className="md:col-span-3">
                <label className="block text-gray-300 font-bold mb-1">Short Description</label>
                <input
                  type="text"
                  value={srvDesc}
                  onChange={(e) => setSrvDesc(e.target.value)}
                  placeholder="Package summary..."
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div className="md:col-span-3">
                <label className="block text-gray-300 font-bold mb-1">Features Bullet Points (Comma separated)</label>
                <input
                  type="text"
                  value={srvFeatures}
                  onChange={(e) => setSrvFeatures(e.target.value)}
                  placeholder="e.g. 12h Duration, Graphic Banner, Targeted Crypto Audience"
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div className="md:col-span-3 pt-2">
                <button type="submit" className="px-6 py-3 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl hover:bg-[#00e082] transition-colors flex items-center space-x-2 shadow-lg shadow-[#00FF94]/20 cursor-pointer">
                  <Plus className="w-4 h-4 text-black" />
                  <span>{editingService ? 'Save Package Changes' : '+ Add Service Package'}</span>
                </button>
              </div>
            </div>
          </form>

          {/* Active Service Packages Grid */}
          <div className="bg-[#141416] border border-white/10 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-white text-base">Active Service Packages ({services.length})</h3>
              <span className="text-xs text-gray-400 font-mono">Real-time sync to /services & checkout modal</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
              {services.map((s) => (
                <div key={s.id} className="p-4 bg-[#0A0A0B] rounded-2xl border border-white/10 flex flex-col justify-between space-y-3 relative">
                  {s.popular && (
                    <span className="absolute top-3 right-3 bg-[#00FF94] text-black font-extrabold text-[9px] px-2 py-0.5 rounded-full">
                      POPULAR
                    </span>
                  )}

                  <div>
                    <div className="flex justify-between items-center pr-12">
                      <span className="font-bold text-white text-sm">{s.title}</span>
                    </div>
                    <span className="text-[10px] text-[#00FF94] bg-[#00FF94]/10 border border-[#00FF94]/20 px-2 py-0.5 rounded font-bold uppercase inline-block mt-1">
                      {s.category}
                    </span>
                    <p className="text-gray-300 text-xs mt-2">{s.description}</p>
                    
                    {s.features && s.features.length > 0 && (
                      <ul className="mt-2 space-y-1 text-[11px] text-gray-400">
                        {s.features.map((feat, fi) => (
                          <li key={fi} className="flex items-center space-x-1.5">
                            <span className="text-[#00FF94]">✓</span>
                            <span>{feat}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="font-black text-[#00FF94] text-base">${s.priceUsdt} USDT</span>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => startEditService(s)}
                        className="px-3 py-1 bg-[#00FF94]/10 text-[#00FF94] border border-[#00FF94]/30 rounded-lg text-xs font-bold hover:bg-[#00FF94] hover:text-black transition-colors cursor-pointer"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Delete service "${s.title}"?`)) onDeleteService(s.id);
                        }}
                        className="px-3 py-1 bg-red-950 text-red-400 border border-red-500/30 rounded-lg text-xs font-bold hover:bg-red-600 hover:text-white transition-colors cursor-pointer"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 6. QUESTS & GIVEAWAYS TAB */}
      {activeAdminTab === 'giveaways' && (
        <div className="space-y-6">
          <form onSubmit={handleAddGiveawayForm} className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 text-xs font-mono">
            <h3 className="font-extrabold text-white text-base">➕ Publish New Giveaway Quest</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-gray-300 font-bold mb-1">Giveaway Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. $2,500 USDT Airdrop Quest"
                  value={gwTitle}
                  onChange={(e) => setGwTitle(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">Project Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monster AI Chain"
                  value={gwProject}
                  onChange={(e) => setGwProject(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">Prize Pool *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. $5,000 USDT"
                  value={gwPrize}
                  onChange={(e) => setGwPrize(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div className="md:col-span-3">
                <button type="submit" className="px-6 py-2.5 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl cursor-pointer">
                  + Publish Quest
                </button>
              </div>
            </div>
          </form>

          <div className="bg-[#141416] border border-white/10 rounded-3xl p-6 space-y-4">
            <h3 className="font-extrabold text-white text-base">Live Giveaways ({giveaways.length})</h3>
            <div className="space-y-3 font-mono text-xs">
              {giveaways.map((gw) => (
                <div key={gw.id} className="p-4 bg-[#0A0A0B] rounded-2xl border border-white/10 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white">{gw.title}</h4>
                    <p className="text-[#00FF94] font-bold mt-0.5">Prize: {gw.prizePool} ({gw.participantsCount} entries)</p>
                  </div>
                  <button
                    onClick={() => onDeleteGiveaway(gw.id)}
                    className="px-3 py-1.5 bg-red-950 text-red-400 border border-red-500/30 rounded-xl font-bold cursor-pointer"
                  >
                    Delete
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 7. PROJECTS DIRECTORY TAB */}
      {activeAdminTab === 'projects' && (
        <div className="space-y-6">
          <form onSubmit={handleAddProjectForm} className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 text-xs font-mono">
            <h3 className="font-extrabold text-white text-base">➕ Add Project to Directory</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-gray-300 font-bold mb-1">Project Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monster AI Chain"
                  value={projName}
                  onChange={(e) => setProjName(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">Ticker *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. MAIC"
                  value={projTicker}
                  onChange={(e) => setProjTicker(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div>
                <label className="block text-gray-300 font-bold mb-1">Market Cap</label>
                <input
                  type="text"
                  value={projMarketCap}
                  onChange={(e) => setProjMarketCap(e.target.value)}
                  className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
                />
              </div>

              <div className="pt-5">
                <button type="submit" className="w-full py-2.5 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl cursor-pointer">
                  + Add Project
                </button>
              </div>
            </div>
          </form>

          <div className="bg-[#141416] border border-white/10 rounded-3xl p-6 space-y-3 font-mono text-xs">
            <h3 className="font-extrabold text-white text-base">Directory Projects ({projects.length})</h3>
            {projects.map((p) => (
              <div key={p.id} className="p-3 bg-[#0A0A0B] rounded-xl border border-white/10 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white">{p.name} (${p.ticker})</span>
                  <span className="text-gray-400 ml-2">Market Cap: {p.marketCap}</span>
                </div>
                <button
                  onClick={() => onDeleteProject(p.id)}
                  className="px-2.5 py-1 bg-red-950 text-red-400 rounded font-bold cursor-pointer"
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 8. CLIENT BOOKING ORDERS TAB */}
      {activeAdminTab === 'bookings' && (
        <div className="bg-[#141416] border border-white/10 rounded-3xl p-6 space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-extrabold text-white text-base">Client Service Booking Orders ({bookingsList.length})</h3>
            <span className="text-xs text-gray-400 font-mono">Real-time sync with user payment submissions</span>
          </div>

          {bookingsList.length === 0 ? (
            <div className="bg-[#0A0A0B] p-8 rounded-2xl border border-white/10 text-center text-xs font-mono text-gray-400 space-y-2">
              <Calendar className="w-8 h-8 text-gray-500 mx-auto" />
              <p className="font-bold text-white">No Client Orders Found Yet</p>
              <p>When users book services or AMAs via the platform checkout, their order details and payment TX hashes will appear here in real-time.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {bookingsList.map((b) => (
                <div key={b.id} className="bg-[#0A0A0B] p-4 rounded-2xl border border-white/10 text-xs font-mono flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-[#00FF94]">{b.id}</span>
                      <span className="font-bold text-white">{b.projectName}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        b.bookingStatus === 'Approved' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}>
                        {b.bookingStatus}
                      </span>
                    </div>
                    <p className="text-gray-300 mt-0.5">{b.packageName} • ${b.priceUsdt} USDT ({b.paymentChain})</p>
                    <p className="text-[10px] text-gray-500">TX Hash: {b.txHash} • Submitted: {b.createdAt ? new Date(b.createdAt).toLocaleDateString() : 'Recent'}</p>
                  </div>

                  <div className="flex items-center space-x-2">
                    {b.bookingStatus !== 'Approved' && (
                      <button
                        onClick={() => handleApproveBooking(b.id)}
                        className="px-3 py-1.5 bg-emerald-500 text-black font-extrabold rounded-xl flex items-center space-x-1 cursor-pointer"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Approve Order</span>
                      </button>
                    )}
                    {b.bookingStatus !== 'Rejected' && (
                      <button
                        onClick={() => handleRejectBooking(b.id)}
                        className="px-3 py-1.5 bg-red-950 text-red-300 font-bold border border-red-500/30 rounded-xl flex items-center space-x-1 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 9. REVENUE ANALYTICS TAB */}
      {activeAdminTab === 'analytics' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#141416] border border-white/10 p-5 rounded-2xl font-mono">
              <span className="text-[10px] text-gray-400 font-bold uppercase">Total Verified Revenue (USDT)</span>
              <p className="text-2xl font-black text-[#00FF94] mt-1">${realApprovedRevenue.toLocaleString()} USDT</p>
              <span className="text-[10px] text-gray-400">Based on approved client orders</span>
            </div>
            <div className="bg-[#141416] border border-white/10 p-5 rounded-2xl font-mono">
              <span className="text-[10px] text-gray-400 font-bold uppercase">Total AMAs Directory</span>
              <p className="text-2xl font-black text-white mt-1">{amas.length} Events</p>
              <span className="text-[10px] text-emerald-400">{amas.filter(a => a.status === 'live').length} live now</span>
            </div>
            <div className="bg-[#141416] border border-white/10 p-5 rounded-2xl font-mono">
              <span className="text-[10px] text-gray-400 font-bold uppercase">Client Booking Orders</span>
              <p className="text-2xl font-black text-white mt-1">{bookingsList.length} Total</p>
              <span className="text-[10px] text-amber-400">{realPendingOrders} pending verification</span>
            </div>
            <div className="bg-[#141416] border border-white/10 p-5 rounded-2xl font-mono">
              <span className="text-[10px] text-gray-400 font-bold uppercase">Active Marketing Packages</span>
              <p className="text-2xl font-black text-white mt-1">{services.length} Packages</p>
              <span className="text-[10px] text-emerald-400">Available on platform</span>
            </div>
          </div>

          <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
            <h3 className="font-extrabold text-white text-base font-mono">Real-Time Verified Orders Revenue Trend</h3>
            {bookingsList.length === 0 ? (
              <div className="p-8 text-center text-xs font-mono text-gray-400 bg-[#0A0A0B] rounded-2xl border border-white/5">
                No verified orders logged yet. Verified client transactions will plot revenue trends here automatically.
              </div>
            ) : (
              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={bookingsList.map((b, idx) => ({
                    order: `Order #${idx + 1}`,
                    revenue: b.bookingStatus === 'Approved' || b.paymentStatus === 'verified' ? b.priceUsdt : 0
                  }))}>
                    <defs>
                      <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#00FF94" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#00FF94" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#27272A" />
                    <XAxis dataKey="order" stroke="#71717A" />
                    <YAxis stroke="#71717A" />
                    <Tooltip contentStyle={{ backgroundColor: '#0A0A0B', borderColor: '#00FF94', borderRadius: '12px' }} />
                    <Area type="monotone" dataKey="revenue" stroke="#00FF94" fillOpacity={1} fill="url(#colorRev)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 10. SYSTEM SETTINGS TAB */}
      {activeAdminTab === 'settings' && (
        <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4 text-xs font-mono">
          <h3 className="font-extrabold text-white text-base">System Contacts & Security Options</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-bold mb-1">Telegram Booking Manager Handle</label>
              <input type="text" defaultValue={siteConfig.bookingTelegram} className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white" />
            </div>
            <div>
              <label className="block text-gray-300 font-bold mb-1">Official Support Email</label>
              <input type="text" defaultValue={siteConfig.supportEmail} className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white" />
            </div>
          </div>
          <button onClick={() => alert("Admin System Settings saved!")} className="px-6 py-2.5 bg-[#00FF94] text-black font-extrabold rounded-xl cursor-pointer">
            Save System Settings
          </button>
        </div>
      )}
    </div>
  );
};
