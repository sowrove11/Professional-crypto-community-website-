import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Briefcase, 
  Mic, 
  Share2, 
  Users, 
  TrendingUp, 
  CheckCircle, 
  ArrowRight, 
  Flame, 
  Star, 
  Radio, 
  MessageSquare, 
  Globe, 
  ShieldCheck, 
  Gift 
} from 'lucide-react';
import { ServiceItem } from '../types';

interface ServicesViewProps {
  services: ServiceItem[];
  onOpenBookModal: () => void;
}

export const ServicesView: React.FC<ServicesViewProps> = ({ services, onOpenBookModal }) => {
  const [activeCategory, setActiveCategory] = useState<'All' | 'AMA Services' | 'Marketing Services' | 'Community Growth' | 'Promotions'>('All');

  const filteredServices = services.filter(s => activeCategory === 'All' || s.category === activeCategory);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="space-y-10 pb-12 text-slate-100"
    >
      {/* Hero Header */}
      <motion.div 
        whileHover={{ scale: 1.005 }}
        className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-950 border border-amber-500/30 p-8 rounded-3xl text-center relative overflow-hidden shadow-2xl"
      >
        <div className="max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
            Official Services Catalog
          </span>
          <h1 className="text-3xl sm:text-4xl font-black text-white">
            Web3 AMA Hosting & Growth Accelerator
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            Guaranteed exposure to 500,000+ active crypto investors across Telegram, X Spaces, Binance Square, and top tier media outlets.
          </p>
        </div>
      </motion.div>

      {/* Category Tabs */}
      <div className="flex justify-center space-x-2 overflow-x-auto pb-2 text-xs font-bold">
        {['All', 'AMA Services', 'Marketing Services', 'Community Growth', 'Promotions'].map((cat) => (
          <motion.button
            key={cat}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveCategory(cat as any)}
            className={`px-5 py-2.5 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
              activeCategory === cat
                ? 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/20'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:border-amber-500/40'
            }`}
          >
            {cat}
          </motion.button>
        ))}
      </div>

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredServices.map((srv, idx) => (
          <motion.div 
            key={srv.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: idx * 0.05 }}
            whileHover={{ scale: 1.02, y: -4, transition: { duration: 0.2 } }}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-6 hover:border-amber-500/40 transition-all flex flex-col justify-between space-y-6 group shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase">
                  {srv.category}
                </span>
                {srv.popular && (
                  <span className="bg-red-500/20 text-red-300 text-[10px] font-bold px-2.5 py-1 rounded-full border border-red-500/30 flex items-center space-x-1">
                    <Flame className="w-3 h-3 text-red-400" />
                    <span>Popular</span>
                  </span>
                )}
              </div>

              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
                {srv.title}
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                {srv.description}
              </p>

              <ul className="space-y-2 mb-4">
                {srv.features.map((feat, fidx) => (
                  <li key={fidx} className="flex items-center space-x-2 text-xs text-slate-300">
                    <CheckCircle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-bold">Price</span>
                <p className="text-2xl font-black text-amber-400">${srv.priceUsdt} <span className="text-xs font-normal text-slate-400">USDT</span></p>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={onOpenBookModal}
                className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs rounded-xl shadow-md hover:brightness-110 flex items-center space-x-1 cursor-pointer"
              >
                <span>Book Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </motion.button>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};
