import React, { useState } from 'react';
import { 
  Flame, 
  Mic, 
  Briefcase, 
  Gift, 
  Grid, 
  Calendar, 
  Bot, 
  User, 
  ShieldAlert, 
  Lock, 
  X, 
  Rocket, 
  Trophy, 
  Newspaper, 
  Phone,
  Sparkles
} from 'lucide-react';
import { UserProfile } from '../types';

interface MobileBottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: UserProfile | null;
  isAdminUnlocked: boolean;
  onOpenAdminAuth: () => void;
  onOpenAuth: () => void;
  onOpenAiTools: () => void;
  onOpenBookModal: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  isAdminUnlocked,
  onOpenAdminAuth,
  onOpenAuth,
  onOpenAiTools,
  onOpenBookModal,
}) => {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const mainTabs = [
    { id: 'home', label: 'Home', icon: Flame },
    { id: 'amas', label: 'AMA', icon: Mic, badge: 'LIVE' },
    { id: 'services', label: 'Services', icon: Briefcase },
    { id: 'giveaways', label: 'Quests', icon: Gift },
  ];

  const secondaryNav = [
    { id: 'projects', label: 'Projects Directory', icon: Rocket },
    { id: 'leaderboard', label: 'Global Leaderboard', icon: Trophy },
    { id: 'news', label: 'Crypto News', icon: Newspaper },
    { id: 'contact', label: 'Contact Us', icon: Phone },
  ];

  const handleAdminClick = () => {
    setDrawerOpen(false);
    if (isAdminUnlocked || currentUser?.role === 'admin') {
      setActiveTab('admin');
    } else {
      onOpenAdminAuth();
    }
  };

  return (
    <>
      {/* Mobile Bottom Dock (App Shell Navigation) */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0A0A0B]/95 backdrop-blur-xl border-t border-white/10 px-2 py-1.5 flex items-center justify-around shadow-2xl">
        {mainTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                setDrawerOpen(false);
              }}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all relative ${
                isActive ? 'text-[#00FF94]' : 'text-gray-400 hover:text-gray-200'
              }`}
            >
              <div className="relative">
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110 text-[#00FF94]' : ''}`} />
                {tab.badge && (
                  <span className="absolute -top-1 -right-2 w-2 h-2 bg-red-500 rounded-full animate-ping" />
                )}
              </div>
              <span className={`text-[10px] font-mono mt-0.5 font-bold ${isActive ? 'text-[#00FF94]' : 'text-gray-400'}`}>
                {tab.label}
              </span>
              {isActive && (
                <span className="w-1 h-1 bg-[#00FF94] rounded-full absolute bottom-0 shadow-sm shadow-[#00FF94]" />
              )}
            </button>
          );
        })}

        {/* Floating Center Book AMA Button */}
        <button
          onClick={onOpenBookModal}
          className="flex flex-col items-center justify-center -mt-4 bg-[#00FF94] text-black w-11 h-11 rounded-2xl shadow-lg shadow-[#00FF94]/30 active:scale-95 transition-transform border-2 border-[#0A0A0B]"
          title="Book AMA"
        >
          <Calendar className="w-5 h-5 text-black" />
        </button>

        {/* More App Switcher Drawer Trigger */}
        <button
          onClick={() => setDrawerOpen(!drawerOpen)}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all ${
            drawerOpen ? 'text-[#00FF94]' : 'text-gray-400'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] font-mono mt-0.5 font-bold">Apps</span>
        </button>
      </nav>

      {/* Mobile Native Sheet Drawer */}
      {drawerOpen && (
        <div className="sm:hidden fixed inset-0 z-40 bg-black/80 backdrop-blur-md flex flex-col justify-end animate-in fade-in duration-200">
          {/* Backdrop dismissal */}
          <div className="flex-1" onClick={() => setDrawerOpen(false)} />

          <div className="bg-[#141416] border-t border-white/10 rounded-t-3xl p-5 space-y-5 shadow-2xl max-h-[80vh] overflow-y-auto animate-in slide-in-from-bottom duration-200">
            {/* Handle Bar & Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-[#00FF94] flex items-center justify-center text-black font-black text-base">
                  M
                </div>
                <div>
                  <span className="text-sm font-black text-white uppercase tracking-tight">MONSTER <span className="text-[#00FF94]">MOBILE</span></span>
                  <p className="text-[10px] text-gray-400 font-mono">Web3 Marketing & AMA Hub</p>
                </div>
              </div>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-1.5 bg-white/5 rounded-full text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Actions Row */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  onOpenAiTools();
                  setDrawerOpen(false);
                }}
                className="p-3 bg-purple-950/40 border border-purple-500/30 rounded-2xl text-left space-y-1 hover:border-purple-400 transition-all"
              >
                <div className="flex items-center justify-between">
                  <Bot className="w-5 h-5 text-purple-400" />
                  <span className="text-[9px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded font-bold">AI PRO</span>
                </div>
                <h4 className="text-xs font-bold text-purple-200">AI AMA Generators</h4>
                <p className="text-[10px] text-gray-400">Generate Questions & Recaps</p>
              </button>

              <button
                onClick={() => {
                  onOpenBookModal();
                  setDrawerOpen(false);
                }}
                className="p-3 bg-[#00FF94]/10 border border-[#00FF94]/30 rounded-2xl text-left space-y-1 hover:bg-[#00FF94]/20 transition-all"
              >
                <div className="flex items-center justify-between">
                  <Calendar className="w-5 h-5 text-[#00FF94]" />
                  <span className="text-[9px] bg-[#00FF94] text-black px-1.5 py-0.5 rounded font-black">FAST</span>
                </div>
                <h4 className="text-xs font-bold text-[#00FF94]">Book AMA Slot</h4>
                <p className="text-[10px] text-gray-400">Instant USDT Checkout</p>
              </button>
            </div>

            {/* Secondary Views List */}
            <div className="space-y-2">
              <h4 className="text-[10px] font-mono uppercase font-bold text-gray-400 tracking-wider">Explore Platform</h4>
              <div className="grid grid-cols-2 gap-2 font-mono text-xs">
                {secondaryNav.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setDrawerOpen(false);
                      }}
                      className={`p-3 rounded-xl border flex items-center space-x-2 text-left transition-all ${
                        isActive
                          ? 'bg-[#00FF94]/10 border-[#00FF94]/40 text-[#00FF94]'
                          : 'bg-[#0A0A0B] border-white/5 text-gray-300 hover:text-white'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#00FF94]' : 'text-gray-400'}`} />
                      <span className="truncate">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Account & Admin Controls */}
            <div className="pt-2 border-t border-white/10 space-y-2 font-mono text-xs">
              {currentUser ? (
                <button
                  onClick={() => {
                    setActiveTab('dashboard');
                    setDrawerOpen(false);
                  }}
                  className="w-full p-3 rounded-2xl bg-[#0A0A0B] border border-white/10 text-[#00FF94] flex items-center justify-between"
                >
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-[#00FF94]" />
                    <span className="font-bold">{currentUser.displayName}</span>
                  </div>
                  <span className="text-[10px] bg-[#00FF94]/20 text-[#00FF94] px-2 py-0.5 rounded">
                    Lvl {currentUser.level}
                  </span>
                </button>
              ) : (
                <button
                  onClick={() => {
                    onOpenAuth();
                    setDrawerOpen(false);
                  }}
                  className="w-full p-3 rounded-2xl bg-[#0A0A0B] border border-white/10 text-white font-bold flex items-center justify-center space-x-2"
                >
                  <User className="w-4 h-4 text-[#00FF94]" />
                  <span>Sign In / Create Account</span>
                </button>
              )}

              <button
                onClick={handleAdminClick}
                className="w-full p-3 rounded-2xl bg-[#0A0A0B] border border-white/10 text-gray-400 hover:text-[#00FF94] font-bold flex items-center justify-between"
              >
                <div className="flex items-center space-x-2">
                  {isAdminUnlocked ? <ShieldAlert className="w-4 h-4 text-[#00FF94]" /> : <Lock className="w-4 h-4 text-gray-400" />}
                  <span>Admin Panel</span>
                </div>
                <span className="text-[10px] text-gray-500">{isAdminUnlocked ? 'Unlocked' : 'PIN Protected'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
