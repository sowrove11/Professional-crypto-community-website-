import React, { useState } from 'react';
import { Lock, Key, ShieldCheck, X, AlertCircle, ShieldX } from 'lucide-react';

interface AdminAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminAuthModal: React.FC<AdminAuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);
  const maxAttempts = 3;

  if (!isOpen) return null;

  const isBlocked = attempts >= maxAttempts;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isBlocked) return;

    const cleanPin = pin.trim().toLowerCase();
    // Authorized passkeys checked securely without displaying in UI
    if (cleanPin === '01771270' || cleanPin === 'sowrove' || cleanPin === 'admin') {
      setError('');
      setPin('');
      setAttempts(0);
      onSuccess();
    } else {
      const nextAttempts = attempts + 1;
      setAttempts(nextAttempts);
      setPin('');
      if (nextAttempts >= maxAttempts) {
        setError('Access Blocked: Maximum login attempts (3) exceeded. Admin access is locked.');
      } else {
        const remaining = maxAttempts - nextAttempts;
        setError(`Invalid Security Passcode. ${remaining} ${remaining === 1 ? 'attempt' : 'attempts'} remaining.`);
      }
    }
  };

  const handleClose = () => {
    setError('');
    setPin('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="bg-[#141416] border border-[#00FF94]/30 w-full max-w-md rounded-3xl p-6 shadow-2xl relative space-y-5 animate-in fade-in zoom-in-95">
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white rounded-xl bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-2">
          <div className={`w-14 h-14 ${isBlocked ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-[#00FF94]/10 border-[#00FF94]/30 text-[#00FF94]'} border rounded-2xl flex items-center justify-center mx-auto shadow-lg`}>
            {isBlocked ? <ShieldX className="w-7 h-7" /> : <Lock className="w-7 h-7" />}
          </div>
          <h2 className="text-xl font-black text-white uppercase tracking-tight">Admin Protected Access</h2>
          <p className="text-xs text-gray-400">Enter master security passcode to access the Monster Admin Control Center</p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 p-3 rounded-xl flex items-center space-x-2 text-xs text-red-400 font-mono">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-gray-300 font-bold mb-1">Admin Security Passcode</label>
            <div className="relative">
              <input
                type="password"
                required
                disabled={isBlocked}
                autoFocus
                placeholder="Enter Passcode"
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white font-mono text-center tracking-widest text-lg focus:outline-none focus:border-[#00FF94] disabled:opacity-50 disabled:cursor-not-allowed"
              />
              <Key className="w-5 h-5 text-gray-500 absolute left-3 top-3.5" />
            </div>
          </div>

          <button
            type="submit"
            disabled={isBlocked}
            className="w-full py-3 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl shadow-lg shadow-[#00FF94]/20 hover:bg-[#00e082] transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-[#00FF94]"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isBlocked ? 'Access Blocked' : 'Unlock Master Control'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};

