import React, { useState } from 'react';
import { 
  Flame, 
  Sparkles, 
  Calendar, 
  Mic, 
  Rocket, 
  Users, 
  Gift, 
  Trophy, 
  Newspaper, 
  Phone, 
  Briefcase, 
  Bot, 
  User, 
  ShieldAlert, 
  Menu, 
  X, 
  Moon, 
  Sun,
  ChevronDown,
  LogOut,
  Lock,
  Send,
  Twitter
} from 'lucide-react';
import { UserProfile, SiteConfig } from '../types';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: UserProfile | null;
  siteConfig: SiteConfig;
  isAdminUnlocked: boolean;
  onOpenAdminAuth: () => void;
  onOpenAuth: () => void;
  onOpenAiTools: () => void;
  onOpenBookModal: () => void;
  onLogout: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  siteConfig,
  isAdminUnlocked,
  onOpenAdminAuth,
  onOpenAuth,
  onOpenAiTools,
  onOpenBookModal,
  onLogout,
  darkMode,
  setDarkMode
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home', icon: Flame },
    { id: 'amas', label: 'AMA Center', icon: Mic, badge: 'LIVE' },
    { id: 'services', label: 'Services', icon: Briefcase },
    { id: 'projects', label: 'Projects', icon: Rocket },
    { id: 'communities', label: 'Communities', icon: Users },
    { id: 'giveaways', label: 'Giveaways', icon: Gift },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'news', label: 'News', icon: Newspaper },
    { id: 'contact', label: 'Contact', icon: Phone },
  ];

  const handleAdminClick = () => {
    if (isAdminUnlocked || currentUser?.role === 'admin') {
      setActiveTab('admin');
    } else {
      onOpenAdminAuth();
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#0A0A0B]/90 backdrop-blur-md text-slate-100 shadow-2xl transition-colors">
      {/* Top Banner Ticker */}
      <div className="bg-gradient-to-r from-[#141416] via-[#1a1b20] to-[#141416] border-b border-white/5 px-4 py-1.5 text-xs text-white font-medium flex items-center justify-between">
        <div className="container mx-auto flex items-center justify-between overflow-hidden whitespace-nowrap">
          <div className="flex items-center space-x-3">
            <span className="bg-red-500/10 text-red-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-red-500/30 flex items-center gap-1.5 animate-pulse">
              <span className="w-1.5 h-1.5 bg-red-500 rounded-full"></span>
              LIVE NOW
            </span>
            <span className="text-gray-300 text-xs sm:text-sm font-mono truncate">{siteConfig.announcementText}</span>
          </div>
          <div className="hidden md:flex items-center space-x-6 text-gray-400 text-xs font-mono">
            <span>🔥 <span className="text-white">350+</span> AMAs Hosted</span>
            <span>👥 <span className="text-white">500K+</span> Community Reach</span>
            <span>💼 Booking: <span className="text-[#00FF94]">{siteConfig.bookingTelegram}</span></span>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={() => setActiveTab('home')}
          className="flex items-center space-x-2.5 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl overflow-hidden bg-[#00FF94] flex items-center justify-center p-0.5 shadow-lg shadow-[#00FF94]/20 group-hover:scale-105 transition-transform border border-[#00FF94]/50">
            <img 
              src="https://i.ibb.co.com/HfHGJ4s3/IMG-1578.jpg" 
              alt="Crypto Monster Logo" 
              className="w-full h-full object-cover rounded-lg"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="flex items-center space-x-1">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight uppercase text-white">
                MONSTER <span className="text-[#00FF94]">CLASH</span>
              </span>
            </div>
            <p className="text-[10px] text-gray-400 font-medium tracking-wide hidden sm:block">Web3 AMA & Growth Accelerator</p>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center space-x-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`relative px-3 py-2 rounded-xl text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                  isActive 
                    ? 'text-[#00FF94] bg-[#00FF94]/10 border border-[#00FF94]/30 shadow-sm' 
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#00FF94]' : 'text-gray-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className="ml-1 px-1.5 py-0.2 bg-red-500 text-white text-[9px] font-black rounded-full animate-pulse">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="hidden sm:flex items-center space-x-2.5">
          {/* AI Tools Generator Button */}
          <button
            onClick={onOpenAiTools}
            className="px-3.5 py-2 rounded-xl bg-[#141416] border border-purple-500/30 text-purple-300 hover:text-purple-100 hover:border-purple-400 hover:bg-purple-950/40 text-xs font-semibold flex items-center space-x-1.5 transition-all group"
          >
            <Bot className="w-4 h-4 text-purple-400 group-hover:rotate-12 transition-transform" />
            <span>AI Tools</span>
            <span className="bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[9px] px-1.5 py-0.5 rounded font-bold">
              PRO
            </span>
          </button>

          {/* Book AMA Button */}
          <button
            onClick={onOpenBookModal}
            className="px-4 py-2 rounded-xl bg-[#00FF94] text-black font-extrabold text-xs flex items-center space-x-1.5 shadow-lg shadow-[#00FF94]/20 hover:bg-[#00e082] transition-all"
          >
            <Calendar className="w-4 h-4 text-black" />
            <span>Book AMA</span>
          </button>

          {/* User Profile / Login */}
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center space-x-2 p-1.5 rounded-xl bg-[#141416] border border-white/10 text-slate-200 hover:border-[#00FF94]/40 transition-all"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#00FF94] to-[#00A3FF] text-black font-black flex items-center justify-center text-xs">
                  {currentUser.displayName ? currentUser.displayName[0].toUpperCase() : 'U'}
                </div>
                <div className="text-left hidden md:block pr-1">
                  <div className="text-xs font-bold truncate max-w-[100px]">
                    {currentUser.displayName || 'Monster User'}
                  </div>
                  <div className="text-[10px] text-[#00FF94] font-semibold flex items-center space-x-1">
                    <span>Lvl {currentUser.level}</span>
                    <span>•</span>
                    <span>{currentUser.xp} XP</span>
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-[#141416] border border-white/10 rounded-2xl shadow-2xl py-2 z-50 text-xs">
                  <div className="px-4 py-2 border-b border-white/10">
                    <p className="font-bold text-slate-200 truncate">{currentUser.displayName}</p>
                    <p className="text-[10px] text-gray-400 truncate">{currentUser.email}</p>
                  </div>
                  <button
                    onClick={() => {
                      setActiveTab('dashboard');
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-white/5 text-slate-300 flex items-center space-x-2"
                  >
                    <User className="w-4 h-4 text-[#00FF94]" />
                    <span>My Dashboard & Rewards</span>
                  </button>
                  <button
                    onClick={() => {
                      handleAdminClick();
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-white/5 text-[#00FF94] flex items-center space-x-2 font-semibold"
                  >
                    <ShieldAlert className="w-4 h-4 text-[#00FF94]" />
                    <span>Admin Panel {isAdminUnlocked ? '(Unlocked)' : '(PIN Required)'}</span>
                  </button>
                  <button
                    onClick={() => {
                      onLogout();
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-red-950/40 text-red-400 flex items-center space-x-2 border-t border-white/10 mt-1"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3.5 py-2 rounded-xl bg-[#141416] border border-white/10 text-slate-200 hover:text-white hover:border-[#00FF94] text-xs font-semibold flex items-center space-x-1.5 transition-all"
            >
              <User className="w-4 h-4 text-[#00FF94]" />
              <span>Sign In</span>
            </button>
          )}

          {/* Admin Control Button (Shows Lock icon if locked, Shield icon if unlocked) */}
          <button
            onClick={handleAdminClick}
            className={`p-2 rounded-xl border transition-all ${
              activeTab === 'admin'
                ? 'bg-[#00FF94] text-black border-[#00FF94] font-bold'
                : isAdminUnlocked 
                  ? 'bg-[#00FF94]/10 border-[#00FF94]/40 text-[#00FF94]' 
                  : 'bg-[#141416] border-white/10 text-gray-400 hover:text-[#00FF94] hover:border-[#00FF94]/30'
            }`}
            title={isAdminUnlocked ? "Admin Control Panel (Unlocked)" : "Protected Admin Access (Enter PIN)"}
          >
            {isAdminUnlocked ? <ShieldAlert className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
          </button>
        </div>

        {/* Mobile Controls Toggle */}
        <div className="flex sm:hidden items-center space-x-2">
          <button
            onClick={onOpenBookModal}
            className="px-3 py-1.5 rounded-xl bg-[#00FF94] text-black font-extrabold text-xs shadow-md"
          >
            Book AMA
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-[#141416] border border-white/10 text-gray-300 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="sm:hidden border-t border-white/10 bg-[#0A0A0B] px-4 py-4 space-y-4 animate-in slide-in-from-top-2">
          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive 
                      ? 'bg-[#00FF94]/10 text-[#00FF94] border border-[#00FF94]/30' 
                      : 'bg-[#141416] border border-white/5 text-gray-300'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#00FF94]' : 'text-gray-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-white/10 space-y-2 font-mono text-xs">
            <button
              onClick={() => {
                onOpenAiTools();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-200 text-xs font-bold flex items-center justify-center space-x-2"
            >
              <Bot className="w-4 h-4 text-purple-400" />
              <span>AI Tools & Generators</span>
            </button>

            {currentUser ? (
              <button
                onClick={() => {
                  setActiveTab('dashboard');
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-[#141416] border border-white/10 text-[#00FF94] text-xs font-bold flex items-center justify-center space-x-2"
              >
                <User className="w-4 h-4" />
                <span>My Dashboard ({currentUser.displayName})</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  onOpenAuth();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-xl bg-[#141416] border border-white/10 text-gray-200 text-xs font-bold flex items-center justify-center space-x-2"
              >
                <User className="w-4 h-4 text-[#00FF94]" />
                <span>Sign In / Register</span>
              </button>
            )}

            {/* Admin Panel Protected Button in Mobile Drawer */}
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                handleAdminClick();
              }}
              className="w-full py-2.5 rounded-xl bg-[#141416] border border-white/10 text-gray-400 hover:text-[#00FF94] text-xs font-mono font-bold flex items-center justify-center space-x-2"
            >
              {isAdminUnlocked ? <ShieldAlert className="w-4 h-4 text-[#00FF94]" /> : <Lock className="w-4 h-4 text-gray-400" />}
              <span>Admin Panel {isAdminUnlocked ? '(Unlocked)' : '(Protected)'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
