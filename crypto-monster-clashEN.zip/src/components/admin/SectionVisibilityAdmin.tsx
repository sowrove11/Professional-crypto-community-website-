import React, { useState } from 'react';
import { Save, Layout, Eye, EyeOff, Code, CheckCircle2, Sparkles, Layers } from 'lucide-react';
import { SiteConfig, SectionVisibilityConfig } from '../../types';

interface SectionVisibilityAdminProps {
  siteConfig: SiteConfig;
  onSave: (config: SiteConfig) => void;
}

export const SectionVisibilityAdmin: React.FC<SectionVisibilityAdminProps> = ({ siteConfig, onSave }) => {
  const [vis, setVis] = useState<SectionVisibilityConfig>(siteConfig.sectionVisibility || {});
  const [customHtml, setCustomHtml] = useState<string>(siteConfig.customHtmlBlock || '');

  const sectionsList: { key: keyof SectionVisibilityConfig; label: string; desc: string }[] = [
    { key: 'liveAma', label: '🔴 Live AMA Broadcast Player', desc: 'Interactive live audio/video player and chat' },
    { key: 'upcomingAmas', label: '⏳ Upcoming AMAs Carousel', desc: 'Cards showing scheduled upcoming sessions' },
    { key: 'featuredAmas', label: '⭐ Featured AMAs Grid', desc: 'Promoted premier AMA events' },
    { key: 'amaRecaps', label: '📼 AMA Video & Audio Recaps', desc: 'Past recorded AMA archives and transcripts' },
    { key: 'featuredProjects', label: '🚀 Featured Web3 Projects', desc: 'Promoted partner tokens and dApps' },
    { key: 'trendingProjects', label: '🔥 Trending Projects List', desc: 'Most voted projects in directory' },
    { key: 'liveCampaigns', label: '📢 Live Campaigns & Ads', desc: 'Promotional banners and sponsor pushes' },
    { key: 'giveaways', label: '🎁 Quests & Giveaways Hub', desc: 'Social reward tasks and USDT prize pools' },
    { key: 'airdrops', label: '🪂 Token Airdrops Directory', desc: 'Featured free claimable airdrop events' },
    { key: 'featuredCommunities', label: '👥 Verified Communities', desc: 'Official Telegram and Discord partner channels' },
    { key: 'leaderboard', label: '🏆 Global Quest Leaderboard', desc: 'Top quester standings and XP scores' },
    { key: 'partners', label: '🤝 Strategic Industry Partners', desc: 'Logos of CEXs, launchpads, and media' },
    { key: 'testimonials', label: '💬 Client Reviews & Testimonials', desc: 'Ratings from founders who hosted AMAs' },
    { key: 'latestNews', label: '📰 Crypto News & Press Releases', desc: 'Latest articles and press features' },
    { key: 'announcements', label: '📢 Platform Announcements', desc: 'Official updates from clash team' },
    { key: 'statistics', label: '📊 Live Platform Statistics', desc: 'Bento box stats (350+ AMAs, 500K Reach)' },
    { key: 'sponsors', label: '💎 Platinum Sponsors Grid', desc: 'Featured top sponsor banners' },
    { key: 'customBlocks', label: '💻 Custom HTML / Promotional Block', desc: 'Renders custom embedded HTML content' },
  ];

  const handleToggle = (key: keyof SectionVisibilityConfig) => {
    setVis(prev => ({ ...prev, [key]: prev[key] === false ? true : false }));
  };

  const handleToggleAll = (status: boolean) => {
    const updated: SectionVisibilityConfig = {};
    sectionsList.forEach(s => {
      updated[s.key] = status;
    });
    setVis(updated);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...siteConfig,
      sectionVisibility: vis,
      customHtmlBlock: customHtml
    });
    alert('Homepage Section Toggles Saved Live!');
  };

  return (
    <form onSubmit={handleSave} className="space-y-6 text-xs font-mono">
      {/* Header Bar */}
      <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-white flex items-center gap-2">
            <Layout className="w-5 h-5 text-[#00FF94]" />
            <span>Homepage Section Visibility & Custom Content Controls</span>
          </h2>
          <p className="text-gray-400 text-xs">Toggle homepage sections on or off in real-time, or insert custom HTML promotional widgets.</p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button
            type="button"
            onClick={() => handleToggleAll(true)}
            className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-[11px] rounded-xl transition-colors cursor-pointer"
          >
            Show All
          </button>
          <button
            type="button"
            onClick={() => handleToggleAll(false)}
            className="px-3 py-2 bg-white/10 hover:bg-white/20 text-gray-300 font-bold text-[11px] rounded-xl transition-colors cursor-pointer"
          >
            Hide All
          </button>
          <button
            type="submit"
            className="px-5 py-2.5 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl hover:bg-[#00e082] transition-colors flex items-center space-x-1.5 shadow-lg shadow-[#00FF94]/20 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Toggles</span>
          </button>
        </div>
      </div>

      {/* Grid of Section Switches */}
      <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
        <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#00FF94]" />
          <span>Toggle Homepage Sections (Admin Live Control)</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {sectionsList.map((sec) => {
            const isVisible = vis[sec.key] !== false;
            return (
              <div
                key={sec.key}
                onClick={() => handleToggle(sec.key)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  isVisible
                    ? 'bg-[#0A0A0B] border-[#00FF94]/40 hover:border-[#00FF94]'
                    : 'bg-black/40 border-white/5 opacity-60 hover:opacity-100'
                }`}
              >
                <div className="space-y-0.5">
                  <span className="font-bold text-white text-xs block">{sec.label}</span>
                  <span className="text-[10px] text-gray-400 block line-clamp-1">{sec.desc}</span>
                </div>

                <div className={`px-2.5 py-1 rounded-xl font-bold text-[10px] shrink-0 flex items-center gap-1 ${
                  isVisible ? 'bg-[#00FF94]/20 text-[#00FF94] border border-[#00FF94]/40' : 'bg-red-500/20 text-red-400 border border-red-500/30'
                }`}>
                  {isVisible ? (
                    <>
                      <Eye className="w-3 h-3 text-[#00FF94]" />
                      <span>VISIBLE</span>
                    </>
                  ) : (
                    <>
                      <EyeOff className="w-3 h-3 text-red-400" />
                      <span>HIDDEN</span>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom HTML Block Editor */}
      <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
            <Code className="w-4 h-4 text-[#00FF94]" />
            <span>Custom HTML & Embed Widget Editor</span>
          </h3>
          <span className="text-[10px] text-gray-400">Renders on homepage when "Custom HTML" is toggled Visible</span>
        </div>

        <textarea
          rows={6}
          value={customHtml}
          onChange={(e) => setCustomHtml(e.target.value)}
          placeholder={`<div className="p-6 bg-gradient-to-r from-emerald-950 to-black rounded-3xl border border-[#00FF94]/30 text-center">\n  <h2 className="text-xl font-black text-[#00FF94]">SPECIAL PROMOTIONAL BANNER</h2>\n  <p className="text-xs text-gray-300">Book any Voice AMA today and get DexScreener Trending FREE!</p>\n</div>`}
          className="w-full p-4 bg-[#0A0A0B] border border-white/10 rounded-2xl text-emerald-300 font-mono text-xs focus:border-[#00FF94] leading-relaxed"
        />

        {/* Live Preview Box */}
        {customHtml && (
          <div className="space-y-2">
            <span className="text-[10px] text-gray-400 uppercase font-bold block">Live HTML Preview:</span>
            <div
              className="p-4 bg-[#0A0A0B] border border-white/10 rounded-2xl overflow-x-auto"
              dangerouslySetInnerHTML={{ __html: customHtml }}
            />
          </div>
        )}
      </div>
    </form>
  );
};
