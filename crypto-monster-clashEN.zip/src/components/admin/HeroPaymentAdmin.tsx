import React, { useState } from 'react';
import { Save, Wallet, Image as ImageIcon, Video, Link2, Sparkles, DollarSign, HelpCircle, Check, Copy } from 'lucide-react';
import { SiteConfig } from '../../types';

interface HeroPaymentAdminProps {
  siteConfig: SiteConfig;
  onSave: (config: SiteConfig) => void;
}

export const HeroPaymentAdmin: React.FC<HeroPaymentAdminProps> = ({ siteConfig, onSave }) => {
  const [form, setForm] = useState<SiteConfig>(siteConfig);
  const [copied, setCopied] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(form);
    alert('Hero & Payment Configuration Saved Live!');
  };

  const handleCopyAddr = () => {
    navigator.clipboard.writeText(form.usdtWalletAddress || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 text-xs font-mono">
      {/* Header Bar */}
      <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-black text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#00FF94]" />
            <span>Hero Section & Payment Gateway Settings</span>
          </h2>
          <p className="text-gray-400 text-xs">Configure homepage headlines, CTA buttons, payment wallet addresses, and deposit network settings.</p>
        </div>
        <button
          type="submit"
          className="px-6 py-3 bg-[#00FF94] text-black font-extrabold text-xs rounded-2xl hover:bg-[#00e082] transition-colors flex items-center space-x-2 shadow-lg shadow-[#00FF94]/20 cursor-pointer shrink-0"
        >
          <Save className="w-4 h-4" />
          <span>Save Changes Live</span>
        </button>
      </div>

      {/* Hero Headline & Media Customization */}
      <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
        <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
          <span>🎨 Hero Banner & Content Customization</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label className="block text-gray-300 font-bold mb-1">Top Announcement Bar Ticker *</label>
            <input
              type="text"
              required
              value={form.announcementText || ''}
              onChange={(e) => setForm({ ...form, announcementText: e.target.value })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
              placeholder="e.g. 🎙 Live Binance Square AMA Today at 18:00 UTC | $5,000 USDT Reward Pool"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Hero Main Title Prefix *</label>
            <input
              type="text"
              required
              value={form.heroHeadline || ''}
              onChange={(e) => setForm({ ...form, heroHeadline: e.target.value })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
              placeholder="The #1 Premier Web3"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Hero Highlighted Green Text *</label>
            <input
              type="text"
              required
              value={form.heroHighlight || ''}
              onChange={(e) => setForm({ ...form, heroHighlight: e.target.value })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-[#00FF94] font-bold focus:border-[#00FF94]"
              placeholder="AMA & Growth Platform"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-gray-300 font-bold mb-1">Hero Subtitle / Description Paragraph *</label>
            <textarea
              rows={3}
              required
              value={form.heroDescription || ''}
              onChange={(e) => setForm({ ...form, heroDescription: e.target.value })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
              placeholder="Host live voice & video AMAs across Telegram, X Spaces & Binance Square..."
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">CTA Button 1 Label</label>
            <input
              type="text"
              value={form.ctaButtonPrimaryText || 'Book AMA Session'}
              onChange={(e) => setForm({ ...form, ctaButtonPrimaryText: e.target.value })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">CTA Button 2 Label</label>
            <input
              type="text"
              value={form.ctaButtonSecondaryText || 'Explore Services'}
              onChange={(e) => setForm({ ...form, ctaButtonSecondaryText: e.target.value })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-300 font-bold mb-1">Hero Background Image or Video URL</label>
              <input
                type="text"
                value={form.heroMediaUrl || ''}
                onChange={(e) => setForm({ ...form, heroMediaUrl: e.target.value })}
                placeholder="https://..."
                className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
              />
            </div>

            <div>
              <label className="block text-gray-300 font-bold mb-1">Promotional Banner Graphic URL</label>
              <input
                type="text"
                value={form.promoBannerUrl || ''}
                onChange={(e) => setForm({ ...form, promoBannerUrl: e.target.value })}
                placeholder="https://..."
                className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Live AMA Countdown (Hours)</label>
            <input
              type="number"
              value={form.nextAmaCountdownHours || 12}
              onChange={(e) => setForm({ ...form, nextAmaCountdownHours: parseInt(e.target.value) || 0 })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Live AMA Countdown (Minutes)</label>
            <input
              type="number"
              value={form.nextAmaCountdownMinutes || 30}
              onChange={(e) => setForm({ ...form, nextAmaCountdownMinutes: parseInt(e.target.value) || 0 })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>
        </div>
      </div>

      {/* Payment Gateway & USDT Wallet Config */}
      <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
        <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
          <Wallet className="w-5 h-5 text-[#00FF94]" />
          <span>💳 USDT Payment Gateway & Wallet Configuration</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-300 font-bold mb-1">Default Deposit Network</label>
            <select
              value={form.paymentNetwork || 'TRC20'}
              onChange={(e) => setForm({ ...form, paymentNetwork: e.target.value as any })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            >
              <option value="TRC20">USDT-TRC20 (Tron Network)</option>
              <option value="BEP20">USDT-BEP20 (BNB Smart Chain)</option>
              <option value="ERC20">USDT-ERC20 (Ethereum Network)</option>
              <option value="SOL">USDT-SOL (Solana Network)</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Admin USDT Wallet Address *</label>
            <div className="relative">
              <input
                type="text"
                required
                value={form.usdtWalletAddress || ''}
                onChange={(e) => setForm({ ...form, usdtWalletAddress: e.target.value })}
                className="w-full p-3 pr-20 bg-[#0A0A0B] border border-white/10 rounded-xl text-[#00FF94] font-bold font-mono focus:border-[#00FF94]"
                placeholder="TY7xK9sL2mP4nQ8vR1tW3zX6yA5bC9dE0f"
              />
              <button
                type="button"
                onClick={handleCopyAddr}
                className="absolute right-2 top-2 px-3 py-1 bg-white/10 hover:bg-white/20 text-xs font-bold text-gray-200 rounded-lg flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">QR Code Image URL (Optional)</label>
            <input
              type="text"
              value={form.qrCodeUrl || ''}
              onChange={(e) => setForm({ ...form, qrCodeUrl: e.target.value })}
              placeholder="https://api.qrserver.com/v1/create-qr-code/?..."
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Live AMA Booking Base Price Override ($ USDT)</label>
            <input
              type="number"
              value={form.basePriceUsdt || 899}
              onChange={(e) => setForm({ ...form, basePriceUsdt: parseInt(e.target.value) || 0 })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-gray-300 font-bold mb-1">Payment Instructions & Notes for Clients</label>
            <textarea
              rows={3}
              value={form.paymentNotes || ''}
              onChange={(e) => setForm({ ...form, paymentNotes: e.target.value })}
              className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
              placeholder="Send exact USDT amount to the address above. Paste your TX Hash after transfer for instant approval..."
            />
          </div>
        </div>
      </div>
    </form>
  );
};
