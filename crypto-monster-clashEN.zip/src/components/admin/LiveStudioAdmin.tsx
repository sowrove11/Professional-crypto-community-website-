import React, { useState } from 'react';
import { Radio, Mic, Users, MessageSquare, Pin, ShieldAlert, Volume2, VolumeX, AlertTriangle, Play, Pause, Square, Gift, Check, Sparkles, Send, Trash2, Plus } from 'lucide-react';
import { AMAItem } from '../../types';

interface LiveStudioAdminProps {
  amas: AMAItem[];
  onUpdateAma: (ama: AMAItem) => void;
}

export const LiveStudioAdmin: React.FC<LiveStudioAdminProps> = ({ amas, onUpdateAma }) => {
  const activeLiveAma = amas.find(a => a.status === 'live') || amas[0];
  const [selectedAmaId, setSelectedAmaId] = useState<string>(activeLiveAma?.id || '');

  const currentAma = amas.find(a => a.id === selectedAmaId) || activeLiveAma;

  // Studio Controls State
  const [listenerCount, setListenerCount] = useState(1482);
  const [broadcastStatus, setBroadcastStatus] = useState<'live' | 'paused' | 'ended'>(
    (currentAma?.status === 'live' ? 'live' : 'live')
  );
  const [pinnedMessage, setPinnedMessage] = useState('🎙 Welcome everyone! Type your questions in chat for a chance to win $100 USDT.');
  const [announcementBanner, setAnnouncementBanner] = useState('🔥 Twitter/X Raid Goal: 500 Retweets to double the giveaway pool!');
  const [slowMode, setSlowMode] = useState(false);

  // Live Chat Moderation State
  const [chatMessages, setChatMessages] = useState([
    { id: 'm1', user: '@CryptoSatoshi', text: 'What is the roadmap for Q4 tier 1 CEX listings?', timestamp: '18:12', pinned: false },
    { id: 'm2', user: '@AlphaSeeker', text: 'Is the smart contract fully audited by CertiK?', timestamp: '18:14', pinned: false },
    { id: 'm3', user: '@WhaleHunter', text: 'When is the public token claim going live?', timestamp: '18:15', pinned: false }
  ]);

  // Questions Queue
  const [questionsQueue, setQuestionsQueue] = useState([
    { id: 'q1', user: '@DefiDevel', text: 'How will the AI agent handle multi-chain liquidity aggregation?', status: 'pending' },
    { id: 'q2', user: '@MoonShot2026', text: 'Can holders stake tokens for guaranteed AMA whitelist access?', status: 'pending' }
  ]);

  // Speakers on Stage
  const [speakersOnStage, setSpeakersOnStage] = useState([
    { name: 'Calvin Harrison', role: 'Host', muted: false },
    { name: 'Alex Vance', role: 'CEO Guest', muted: false }
  ]);

  const [newSpeakerName, setNewSpeakerName] = useState('');

  // Handle Broadcast State
  const handleStatusChange = (newStatus: 'live' | 'paused' | 'ended') => {
    setBroadcastStatus(newStatus);
    if (currentAma) {
      onUpdateAma({
        ...currentAma,
        status: newStatus === 'ended' ? 'ended' : 'live'
      });
    }
  };

  const handleEmergencyShutdown = () => {
    if (confirm('🚨 EMERGENCY SHUTDOWN: Are you sure you want to kill the live stream immediately?')) {
      setBroadcastStatus('ended');
      if (currentAma) {
        onUpdateAma({ ...currentAma, status: 'ended' });
      }
      alert('Broadcast Terminated Immediately.');
    }
  };

  const handleAddListenerCount = (amount: number) => {
    setListenerCount(prev => Math.max(0, prev + amount));
  };

  const handleAddSpeakerStage = () => {
    if (!newSpeakerName) return;
    setSpeakersOnStage(prev => [...prev, { name: newSpeakerName, role: 'Guest Speaker', muted: false }]);
    setNewSpeakerName('');
  };

  const handleToggleMuteSpeaker = (index: number) => {
    setSpeakersOnStage(prev => prev.map((s, i) => i === index ? { ...s, muted: !s.muted } : s));
  };

  const handleRemoveSpeaker = (index: number) => {
    setSpeakersOnStage(prev => prev.filter((_, i) => i !== index));
  };

  const handleDeleteChatMessage = (id: string) => {
    setChatMessages(prev => prev.filter(m => m.id !== id));
  };

  const handlePinChatMessage = (text: string) => {
    setPinnedMessage(text);
  };

  const handleMarkQuestionAnswered = (id: string) => {
    setQuestionsQueue(prev => prev.map(q => q.id === id ? { ...q, status: 'answered' } : q));
  };

  const handleTriggerGiveaway = () => {
    alert(`🎉 Giveaway Triggered! $500 USDT distributed among ${listenerCount} active stream listeners!`);
  };

  return (
    <div className="space-y-6 text-xs font-mono">
      {/* Studio Header Bar */}
      <div className="bg-[#141416] border border-red-500/40 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-2xl">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-500 flex items-center justify-center font-black animate-pulse">
            <Radio className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-black text-white">Live Broadcast Studio Control Room</h2>
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded uppercase ${
                broadcastStatus === 'live' ? 'bg-red-500 text-white animate-pulse' : 'bg-amber-500 text-black'
              }`}>
                {broadcastStatus === 'live' ? '🔴 ON AIR' : broadcastStatus === 'paused' ? '⏸ PAUSED' : '🛑 OFF AIR'}
              </span>
            </div>
            <p className="text-xs text-gray-400">Real-time control over live audio, guest speakers, chat moderation & giveaway triggers</p>
          </div>
        </div>

        {/* Select Target AMA */}
        <div className="flex items-center space-x-2 shrink-0">
          <label className="text-gray-300 font-bold">Select Active AMA:</label>
          <select
            value={selectedAmaId}
            onChange={(e) => setSelectedAmaId(e.target.value)}
            className="p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
          >
            {amas.map(a => (
              <option key={a.id} value={a.id}>
                {a.projectName} - {a.title} ({a.status})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Broadcast Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Col 1: Main Control Panel */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Action Buttons Box */}
          <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
            <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
              <Mic className="w-4 h-4 text-[#00FF94]" />
              <span>Broadcast Controls & State Switcher</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <button
                type="button"
                onClick={() => handleStatusChange('live')}
                className="p-3 bg-red-600 hover:bg-red-500 text-white font-extrabold rounded-2xl flex items-center justify-center space-x-1.5 shadow-lg cursor-pointer"
              >
                <Radio className="w-4 h-4" />
                <span>START LIVE</span>
              </button>

              <button
                type="button"
                onClick={() => handleStatusChange('paused')}
                className="p-3 bg-amber-500 hover:bg-amber-400 text-black font-extrabold rounded-2xl flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Pause className="w-4 h-4" />
                <span>PAUSE</span>
              </button>

              <button
                type="button"
                onClick={() => handleStatusChange('ended')}
                className="p-3 bg-slate-800 hover:bg-slate-700 text-white font-extrabold rounded-2xl flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <Square className="w-4 h-4" />
                <span>END STREAM</span>
              </button>

              <button
                type="button"
                onClick={handleEmergencyShutdown}
                className="p-3 bg-red-950 border border-red-500/50 hover:bg-red-900 text-red-300 font-extrabold rounded-2xl flex items-center justify-center space-x-1.5 cursor-pointer"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>SHUTDOWN</span>
              </button>
            </div>

            {/* Listener Count Override Controls */}
            <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-gray-400 text-[10px] uppercase font-bold block">Live Stream Listeners</span>
                <span className="text-2xl font-black text-[#00FF94] font-mono">{listenerCount.toLocaleString()} Active</span>
              </div>

              <div className="flex items-center space-x-1.5">
                <span className="text-gray-400 text-[10px]">Boost:</span>
                <button
                  type="button"
                  onClick={() => handleAddListenerCount(100)}
                  className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg cursor-pointer"
                >
                  +100
                </button>
                <button
                  type="button"
                  onClick={() => handleAddListenerCount(500)}
                  className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg cursor-pointer"
                >
                  +500
                </button>
                <button
                  type="button"
                  onClick={() => handleAddListenerCount(1000)}
                  className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold rounded-lg cursor-pointer"
                >
                  +1,000
                </button>
              </div>
            </div>
          </div>

          {/* Guest Speakers Stage Manager */}
          <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
                <Users className="w-4 h-4 text-[#00FF94]" />
                <span>Speakers On Stage ({speakersOnStage.length})</span>
              </h3>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  placeholder="New Speaker Name..."
                  value={newSpeakerName}
                  onChange={(e) => setNewSpeakerName(e.target.value)}
                  className="p-1.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white text-xs"
                />
                <button
                  type="button"
                  onClick={handleAddSpeakerStage}
                  className="px-3 py-1.5 bg-[#00FF94] text-black font-extrabold rounded-xl cursor-pointer"
                >
                  + Add to Stage
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {speakersOnStage.map((sp, idx) => (
                <div key={idx} className="p-3 bg-[#0A0A0B] border border-white/10 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 rounded-full bg-[#00FF94]/20 text-[#00FF94] font-black flex items-center justify-center">
                      {sp.name.charAt(0)}
                    </div>
                    <div>
                      <span className="font-bold text-white text-xs block">{sp.name}</span>
                      <span className="text-[10px] text-gray-400 block">{sp.role}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-1">
                    <button
                      type="button"
                      onClick={() => handleToggleMuteSpeaker(idx)}
                      className={`p-1.5 rounded-lg border ${
                        sp.muted ? 'bg-red-500/20 text-red-400 border-red-500/40' : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      }`}
                    >
                      {sp.muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveSpeaker(idx)}
                      className="p-1.5 bg-red-950 text-red-400 border border-red-500/30 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Announcement Overlay Banner & Giveaway Trigger */}
          <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
            <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#00FF94]" />
              <span>Live Overlay Banner & Instant Giveaway Triggers</span>
            </h3>

            <div className="space-y-3">
              <div>
                <label className="block text-gray-300 font-bold mb-1">Live On-Screen Announcement Overlay Text</label>
                <input
                  type="text"
                  value={announcementBanner}
                  onChange={(e) => setAnnouncementBanner(e.target.value)}
                  className="w-full p-3 bg-[#0A0A0B] border border-white/10 rounded-xl text-[#00FF94] font-bold"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-gray-400 text-xs">Trigger Live USDT Airdrop Giveaway directly to active stream listeners:</span>
                <button
                  type="button"
                  onClick={handleTriggerGiveaway}
                  className="px-5 py-2.5 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl shadow-lg hover:bg-[#00e082] transition-colors flex items-center space-x-1.5 cursor-pointer shrink-0"
                >
                  <Gift className="w-4 h-4 text-black" />
                  <span>🎁 Trigger Live $500 Giveaway Pool</span>
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Col 2: Chat Moderation & Questions Queue */}
        <div className="space-y-6">
          
          {/* Live Chat Moderation */}
          <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-[#00FF94]" />
                <span>Live Chat Moderator</span>
              </h3>

              <button
                type="button"
                onClick={() => setSlowMode(!slowMode)}
                className={`px-2.5 py-1 rounded-lg text-[10px] font-bold ${
                  slowMode ? 'bg-amber-500 text-black' : 'bg-white/10 text-gray-300'
                }`}
              >
                {slowMode ? 'Slow Mode ON' : 'Slow Mode OFF'}
              </button>
            </div>

            {/* Pinned Message Box */}
            <div className="p-3 bg-[#0A0A0B] border border-[#00FF94]/30 rounded-2xl flex items-start space-x-2">
              <Pin className="w-4 h-4 text-[#00FF94] shrink-0 mt-0.5" />
              <div>
                <span className="text-[10px] text-gray-400 uppercase font-bold block">Pinned Stream Announcement:</span>
                <p className="text-gray-200 text-xs leading-snug">{pinnedMessage}</p>
              </div>
            </div>

            {/* Chat Log */}
            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {chatMessages.map((msg) => (
                <div key={msg.id} className="p-2.5 bg-[#0A0A0B] rounded-xl border border-white/5 flex justify-between items-start">
                  <div>
                    <span className="font-bold text-[#00FF94] text-[11px]">{msg.user}</span>
                    <p className="text-gray-200 text-xs mt-0.5">{msg.text}</p>
                  </div>
                  <div className="flex items-center space-x-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handlePinChatMessage(msg.text)}
                      className="p-1 hover:text-[#00FF94] text-gray-400"
                      title="Pin Message"
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteChatMessage(msg.id)}
                      className="p-1 hover:text-red-400 text-gray-400"
                      title="Delete Message"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Listener Question Queue */}
          <div className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-3">
            <h3 className="font-extrabold text-white text-sm uppercase tracking-wider text-[#00FF94] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#00FF94]" />
              <span>Questions Queue ({questionsQueue.length})</span>
            </h3>

            <div className="space-y-2">
              {questionsQueue.map((q) => (
                <div key={q.id} className="p-3 bg-[#0A0A0B] rounded-xl border border-white/10 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-[#00FF94] text-xs">{q.user}</span>
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded ${
                      q.status === 'answered' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                    }`}>
                      {q.status}
                    </span>
                  </div>
                  <p className="text-gray-200 text-xs">{q.text}</p>
                  {q.status === 'pending' && (
                    <button
                      type="button"
                      onClick={() => handleMarkQuestionAnswered(q.id)}
                      className="w-full py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold rounded-lg hover:bg-emerald-500 hover:text-black transition-colors"
                    >
                      Mark Answered Live
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
