import React, { useState } from 'react';
import { Plus, Edit, Trash2, Mic, Image as ImageIcon, Users, Link2, Calendar, Radio, CheckCircle2, Shield, X } from 'lucide-react';
import { AMAItem, AMASpeaker, ExternalLinkItem } from '../../types';

interface AmaManagerAdminProps {
  amas: AMAItem[];
  onAddAma: (ama: AMAItem) => void;
  onUpdateAma: (ama: AMAItem) => void;
  onDeleteAma: (id: string) => void;
}

export const AmaManagerAdmin: React.FC<AmaManagerAdminProps> = ({
  amas,
  onAddAma,
  onUpdateAma,
  onDeleteAma
}) => {
  const [editingAma, setEditingAma] = useState<AMAItem | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [projectName, setProjectName] = useState('');
  const [projectLogo, setProjectLogo] = useState('');
  const [bannerUrl, setBannerUrl] = useState('');
  const [category, setCategory] = useState('AI & Web3');
  const [platform, setPlatform] = useState<any>('Telegram Voice AMA');
  const [status, setStatus] = useState<any>('upcoming');
  const [rewardPool, setRewardPool] = useState('$3,000 USDT');
  const [tokenReward, setTokenReward] = useState('100,000 $TOKEN');
  const [usdtReward, setUsdtReward] = useState('$3,000 USDT');
  const [description, setDescription] = useState('');
  const [rules, setRules] = useState('1. Follow Twitter\n2. Join Telegram Group\n3. Ask a question during live voice session');
  const [maxParticipants, setMaxParticipants] = useState(5000);
  const [hostName, setHostName] = useState('Calvin Harrison');
  const [scheduledDate, setScheduledDate] = useState('2026-08-10');
  const [startTime, setStartTime] = useState('18:00');
  const [endTime, setEndTime] = useState('19:00');
  const [timezone, setTimezone] = useState('UTC');

  // Speakers Array
  const [speakers, setSpeakers] = useState<AMASpeaker[]>([
    { id: 'sp-1', name: 'Alex Vance', role: 'CEO & Founder', photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', socialUrl: 'https://twitter.com' }
  ]);

  // Links Array
  const [links, setLinks] = useState<ExternalLinkItem[]>([
    { id: 'l-1', label: 'Official Telegram', url: 'https://t.me/MonsterClashGlobal', type: 'telegram' },
    { id: 'l-2', label: 'Official Twitter/X', url: 'https://twitter.com/MonsterClashX', type: 'twitter' }
  ]);

  // Handle Image File Uploads
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, setter: (url: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setter(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAddSpeaker = () => {
    setSpeakers(prev => [
      ...prev,
      { id: `sp-${Date.now()}`, name: 'New Speaker', role: 'Core Contributor', photoUrl: '', socialUrl: '' }
    ]);
  };

  const handleRemoveSpeaker = (id: string) => {
    setSpeakers(prev => prev.filter(s => s.id !== id));
  };

  const handleSpeakerChange = (id: string, field: keyof AMASpeaker, val: string) => {
    setSpeakers(prev => prev.map(s => s.id === id ? { ...s, [field]: val } : s));
  };

  const handleAddLink = () => {
    setLinks(prev => [
      ...prev,
      { id: `l-${Date.now()}`, label: 'Website Link', url: 'https://', type: 'website' }
    ]);
  };

  const handleRemoveLink = (id: string) => {
    setLinks(prev => prev.filter(l => l.id !== id));
  };

  const handleLinkChange = (id: string, field: keyof ExternalLinkItem, val: string) => {
    setLinks(prev => prev.map(l => l.id === id ? { ...l, [field]: val } : l));
  };

  const resetForm = () => {
    setEditingAma(null);
    setTitle('');
    setProjectName('');
    setProjectLogo('');
    setBannerUrl('');
    setDescription('');
    setRewardPool('$3,000 USDT');
    setSpeakers([
      { id: 'sp-1', name: 'Alex Vance', role: 'CEO & Founder', photoUrl: '', socialUrl: '' }
    ]);
    setLinks([
      { id: 'l-1', label: 'Official Telegram', url: 'https://t.me/MonsterClashGlobal', type: 'telegram' }
    ]);
  };

  const handleStartEdit = (ama: AMAItem) => {
    setEditingAma(ama);
    setTitle(ama.title);
    setProjectName(ama.projectName);
    setProjectLogo(ama.projectLogo || '');
    setBannerUrl(ama.bannerUrl || '');
    setCategory(ama.category || 'AI');
    setPlatform(ama.platform);
    setStatus(ama.status);
    setRewardPool(ama.rewardPool);
    setDescription(ama.description);
    setRules(ama.rules || '');
    setMaxParticipants(ama.maxParticipants || 5000);
    setHostName(ama.hostName || 'Calvin Harrison');
    if (ama.speakers && ama.speakers.length > 0) {
      setSpeakers(ama.speakers);
    }
    if (ama.externalLinks && ama.externalLinks.length > 0) {
      setLinks(ama.externalLinks);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !projectName) return;

    const logoToUse = projectLogo || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80";
    const bannerToUse = bannerUrl || "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&auto=format&fit=crop&q=80";

    const speakerNameList = speakers.map(s => s.name).filter(Boolean);

    if (editingAma) {
      const updated: AMAItem = {
        ...editingAma,
        title,
        projectName,
        projectLogo: logoToUse,
        bannerUrl: bannerToUse,
        category,
        platform,
        status,
        rewardPool,
        tokenReward,
        usdtReward,
        description: description || editingAma.description,
        rules,
        maxParticipants,
        hostName,
        speakers,
        externalLinks: links,
        guestSpeakers: speakerNameList.length > 0 ? speakerNameList : ["Founder"]
      };
      onUpdateAma(updated);
      alert('AMA Event Updated Live!');
    } else {
      const created: AMAItem = {
        id: `ama-${Date.now()}`,
        title,
        projectName,
        projectLogo: logoToUse,
        bannerUrl: bannerToUse,
        category,
        platform,
        status,
        scheduledAt: `${scheduledDate}T${startTime}:00Z`,
        startTime,
        endTime,
        timezone,
        rewardPool,
        tokenReward,
        usdtReward,
        description: description || 'Live crypto AMA event.',
        rules,
        maxParticipants,
        hostName,
        speakers,
        externalLinks: links,
        guestSpeakers: speakerNameList.length > 0 ? speakerNameList : ["Founder"],
        viewsCount: 0,
        questionsCount: 0,
        featured: true
      };
      onAddAma(created);
      alert('New AMA Event Created & Published Live!');
    }

    resetForm();
  };

  return (
    <div className="space-y-6 text-xs font-mono">
      {/* Create / Edit Form */}
      <form onSubmit={handleSubmit} className="bg-[#141416] border border-white/10 p-6 rounded-3xl space-y-6">
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center space-x-2">
            <Mic className="w-5 h-5 text-[#00FF94]" />
            <h3 className="font-extrabold text-white text-base">
              {editingAma ? `✏️ Edit AMA: ${editingAma.title}` : '➕ Create & Schedule New AMA Event'}
            </h3>
          </div>
          {editingAma && (
            <button
              type="button"
              onClick={resetForm}
              className="text-xs text-gray-400 hover:text-white underline"
            >
              Cancel Editing
            </button>
          )}
        </div>

        {/* Primary Event Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-gray-300 font-bold mb-1">AMA Title *</label>
            <input
              type="text"
              required
              placeholder="e.g. Next-Gen Autonomous AI Agents"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Project Name *</label>
            <input
              type="text"
              required
              placeholder="e.g. Monster AI Chain"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Category</label>
            <input
              type="text"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">AMA Platform Format</label>
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            >
              <option value="Telegram Voice AMA">Telegram Voice AMA</option>
              <option value="Telegram Text AMA">Telegram Text AMA</option>
              <option value="Telegram Video AMA">Telegram Video AMA</option>
              <option value="X Spaces">X Spaces (Twitter)</option>
              <option value="Binance Square AMA">Binance Square AMA</option>
              <option value="Discord AMA">Discord Voice & Chat</option>
              <option value="YouTube Live AMA">YouTube Live Broadcast</option>
              <option value="Custom Live AMA">Custom Broadcast URL</option>
              <option value="Multi-platform AMA">Multi-Platform Simulcast</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">AMA Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            >
              <option value="draft">📝 Draft</option>
              <option value="pending_approval">⏳ Pending Approval</option>
              <option value="upcoming">🗓 Upcoming Scheduled</option>
              <option value="live">🔴 LIVE Broadcast NOW</option>
              <option value="paused">⏸ Paused Session</option>
              <option value="ended">✅ Ended / Recap Ready</option>
              <option value="cancelled">❌ Cancelled</option>
              <option value="archived">📦 Archived</option>
            </select>
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Reward Pool Text</label>
            <input
              type="text"
              value={rewardPool}
              onChange={(e) => setRewardPool(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-[#00FF94] font-bold focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Host Name</label>
            <input
              type="text"
              value={hostName}
              onChange={(e) => setHostName(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Scheduled Date & Time</label>
            <div className="flex gap-2">
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-1/2 p-2 bg-[#0A0A0B] border border-white/10 rounded-xl text-white"
              />
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-1/2 p-2 bg-[#0A0A0B] border border-white/10 rounded-xl text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">Max Participants Limit</label>
            <input
              type="number"
              value={maxParticipants}
              onChange={(e) => setMaxParticipants(parseInt(e.target.value) || 1000)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white focus:border-[#00FF94]"
            />
          </div>
        </div>

        {/* Media & Banners */}
        <div className="p-4 bg-[#0A0A0B] rounded-2xl border border-white/10 space-y-3">
          <span className="font-bold text-[#00FF94] text-xs block">🖼 Promotional Banner & Project Logo Upload</span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-gray-400 text-[10px] mb-1">Banner Image File or URL:</label>
              <div className="flex gap-2">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, setBannerUrl)}
                  className="w-1/2 p-1.5 bg-[#141416] border border-white/10 rounded-xl text-gray-300 text-xs file:mr-2 file:py-0.5 file:px-2 file:rounded-lg file:border-0 file:bg-[#00FF94] file:text-black file:font-bold"
                />
                <input
                  type="text"
                  placeholder="https://..."
                  value={bannerUrl}
                  onChange={(e) => setBannerUrl(e.target.value)}
                  className="w-1/2 p-2 bg-[#141416] border border-white/10 rounded-xl text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-gray-400 text-[10px] mb-1">Project Logo File or URL:</label>
              <div className="flex gap-2">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleFileUpload(e, setProjectLogo)}
                  className="w-1/2 p-1.5 bg-[#141416] border border-white/10 rounded-xl text-gray-300 text-xs file:mr-2 file:py-0.5 file:px-2 file:rounded-lg file:border-0 file:bg-[#00FF94] file:text-black file:font-bold"
                />
                <input
                  type="text"
                  placeholder="https://..."
                  value={projectLogo}
                  onChange={(e) => setProjectLogo(e.target.value)}
                  className="w-1/2 p-2 bg-[#141416] border border-white/10 rounded-xl text-white"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Guest Speakers Manager */}
        <div className="p-4 bg-[#0A0A0B] rounded-2xl border border-white/10 space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-bold text-white text-xs flex items-center gap-2">
              <Users className="w-4 h-4 text-[#00FF94]" />
              <span>Guest Speakers List ({speakers.length})</span>
            </span>
            <button
              type="button"
              onClick={handleAddSpeaker}
              className="px-3 py-1 bg-[#00FF94] text-black font-extrabold text-[11px] rounded-lg flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Speaker</span>
            </button>
          </div>

          <div className="space-y-2">
            {speakers.map((sp) => (
              <div key={sp.id} className="p-2.5 bg-[#141416] border border-white/10 rounded-xl grid grid-cols-1 sm:grid-cols-4 gap-2 items-center">
                <input
                  type="text"
                  placeholder="Speaker Name"
                  value={sp.name}
                  onChange={(e) => handleSpeakerChange(sp.id, 'name', e.target.value)}
                  className="p-2 bg-[#0A0A0B] border border-white/10 rounded-lg text-white font-bold"
                />
                <input
                  type="text"
                  placeholder="Role (e.g. CEO / Lead Dev)"
                  value={sp.role}
                  onChange={(e) => handleSpeakerChange(sp.id, 'role', e.target.value)}
                  className="p-2 bg-[#0A0A0B] border border-white/10 rounded-lg text-gray-300"
                />
                <input
                  type="text"
                  placeholder="Photo URL or Avatar"
                  value={sp.photoUrl || ''}
                  onChange={(e) => handleSpeakerChange(sp.id, 'photoUrl', e.target.value)}
                  className="p-2 bg-[#0A0A0B] border border-white/10 rounded-lg text-gray-300"
                />
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Social / X Handle"
                    value={sp.socialUrl || ''}
                    onChange={(e) => handleSpeakerChange(sp.id, 'socialUrl', e.target.value)}
                    className="w-full p-2 bg-[#0A0A0B] border border-white/10 rounded-lg text-gray-300"
                  />
                  <button
                    type="button"
                    onClick={() => handleRemoveSpeaker(sp.id)}
                    className="p-2 bg-red-950 text-red-400 rounded-lg hover:bg-red-600 hover:text-white cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Unlimited External Links Array */}
        <div className="p-4 bg-[#0A0A0B] rounded-2xl border border-white/10 space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-bold text-white text-xs flex items-center gap-2">
              <Link2 className="w-4 h-4 text-[#00FF94]" />
              <span>External Broadcast Links & Socials ({links.length})</span>
            </span>
            <button
              type="button"
              onClick={handleAddLink}
              className="px-3 py-1 bg-[#00FF94] text-black font-extrabold text-[11px] rounded-lg flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Link</span>
            </button>
          </div>

          <div className="space-y-2">
            {links.map((lnk) => (
              <div key={lnk.id} className="p-2.5 bg-[#141416] border border-white/10 rounded-xl grid grid-cols-1 sm:grid-cols-4 gap-2 items-center">
                <input
                  type="text"
                  placeholder="Link Label (e.g. Telegram Channel)"
                  value={lnk.label}
                  onChange={(e) => handleLinkChange(lnk.id, 'label', e.target.value)}
                  className="p-2 bg-[#0A0A0B] border border-white/10 rounded-lg text-white font-bold"
                />
                <select
                  value={lnk.type}
                  onChange={(e) => handleLinkChange(lnk.id, 'type', e.target.value)}
                  className="p-2 bg-[#0A0A0B] border border-white/10 rounded-lg text-white"
                >
                  <option value="telegram">Telegram</option>
                  <option value="twitter">X / Twitter</option>
                  <option value="youtube">YouTube</option>
                  <option value="binance">Binance Square</option>
                  <option value="discord">Discord</option>
                  <option value="website">Website</option>
                  <option value="coinmarketcap">CoinMarketCap</option>
                  <option value="coingecko">CoinGecko</option>
                  <option value="whitepaper">Whitepaper</option>
                  <option value="github">GitHub</option>
                  <option value="custom">Custom URL</option>
                </select>
                <input
                  type="text"
                  placeholder="URL (https://...)"
                  value={lnk.url}
                  onChange={(e) => handleLinkChange(lnk.id, 'url', e.target.value)}
                  className="sm:col-span-1 p-2 bg-[#0A0A0B] border border-white/10 rounded-lg text-gray-300"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveLink(lnk.id)}
                  className="p-2 bg-red-950 text-red-400 rounded-lg hover:bg-red-600 hover:text-white cursor-pointer justify-self-end"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Description & Rules */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-300 font-bold mb-1">AMA Overview / Description</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white"
              placeholder="Join us live with the core founding team to discuss..."
            />
          </div>

          <div>
            <label className="block text-gray-300 font-bold mb-1">AMA Rules & Participation Guidelines</label>
            <textarea
              rows={3}
              value={rules}
              onChange={(e) => setRules(e.target.value)}
              className="w-full p-2.5 bg-[#0A0A0B] border border-white/10 rounded-xl text-white"
              placeholder="Rules for question submission and giveaway eligibility..."
            />
          </div>
        </div>

        <button
          type="submit"
          className="px-6 py-3 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl hover:bg-[#00e082] transition-colors flex items-center space-x-2 shadow-lg shadow-[#00FF94]/20 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{editingAma ? 'Save AMA Changes' : '+ Publish New AMA Event'}</span>
        </button>
      </form>

      {/* AMAs Directory Table */}
      <div className="bg-[#141416] border border-white/10 rounded-3xl p-6 space-y-4">
        <h3 className="font-extrabold text-white text-base">Published AMA Sessions Directory ({amas.length})</h3>
        <div className="space-y-3">
          {amas.map((a) => (
            <div key={a.id} className="p-4 bg-[#0A0A0B] rounded-2xl border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4 relative overflow-hidden">
              <div className="flex items-center space-x-3">
                <img src={a.projectLogo} alt={a.projectName} className="w-12 h-12 rounded-xl object-cover border border-[#00FF94]/30 shrink-0" />
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white text-sm">{a.projectName}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                      a.status === 'live' ? 'bg-red-500/20 text-red-400 border border-red-500/30' : 'bg-[#00FF94]/10 text-[#00FF94]'
                    }`}>
                      {a.status}
                    </span>
                  </div>
                  <p className="text-gray-300 text-xs font-semibold mt-0.5">{a.title}</p>
                  <p className="text-[10px] text-gray-500 mt-1">{a.platform} • Reward: {a.rewardPool}</p>
                </div>
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                <button
                  onClick={() => handleStartEdit(a)}
                  className="px-3 py-1.5 bg-[#00FF94]/10 text-[#00FF94] border border-[#00FF94]/30 rounded-xl font-bold flex items-center space-x-1 hover:bg-[#00FF94] hover:text-black transition-colors cursor-pointer"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>Edit AMA</span>
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete AMA "${a.title}"?`)) onDeleteAma(a.id);
                  }}
                  className="px-3 py-1.5 bg-red-950 text-red-400 border border-red-500/30 rounded-xl font-bold flex items-center space-x-1 hover:bg-red-600 hover:text-white transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
