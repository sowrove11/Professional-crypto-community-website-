import React, { useState } from 'react';
import { X, Bot, Sparkles, Copy, Check, HelpCircle, FileText, ArrowRight, RefreshCw, Zap } from 'lucide-react';

interface AiToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiToolsModal: React.FC<AiToolsModalProps> = ({ isOpen, onClose }) => {
  const [activeTool, setActiveTool] = useState<'questions' | 'recap'>('questions');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Question Generator State
  const [projectName, setProjectName] = useState('');
  const [category, setCategory] = useState('AI & Web3');
  const [description, setDescription] = useState('');
  const [tokenomics, setTokenomics] = useState('');
  const [generatedQuestions, setGeneratedQuestions] = useState<any[]>([]);

  // Recap Generator State
  const [recapProjectName, setRecapProjectName] = useState('');
  const [guestSpeakers, setGuestSpeakers] = useState('');
  const [rawNotes, setRawNotes] = useState('');
  const [generatedRecap, setGeneratedRecap] = useState<any | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const generateQuestions = async () => {
    if (!projectName) return;
    setLoading(true);
    try {
      const res = await fetch('/api/ai/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectName, category, description, tokenomics })
      });
      const data = await res.json();
      if (data.questions) {
        setGeneratedQuestions(data.questions);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const generateRecap = async () => {
    if (!recapProjectName || !rawNotes) return;
    setLoading(true);
    try {
      const res = await fetch('/api/ai/generate-recap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectName: recapProjectName, guestSpeakers, rawNotes })
      });
      const data = await res.json();
      if (data.recap) {
        setGeneratedRecap(data.recap);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-3xl bg-slate-900 border border-purple-500/40 rounded-3xl p-6 shadow-2xl relative text-slate-100 my-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
            <Bot className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white flex items-center space-x-2">
              <span>Crypto Monster AI Studio</span>
              <span className="bg-purple-500/30 text-purple-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-purple-500/40">
                Powered by Gemini 2.5
              </span>
            </h3>
            <p className="text-xs text-slate-400">Generate high-converting AMA questions & automated executive summaries</p>
          </div>
        </div>

        {/* Tool Navigation Tabs */}
        <div className="flex space-x-2 mb-6 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveTool('questions')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-2 transition-all ${
              activeTool === 'questions'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>🤖 AI AMA Question Generator</span>
          </button>
          <button
            onClick={() => setActiveTool('recap')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-2 transition-all ${
              activeTool === 'recap'
                ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                : 'bg-slate-950 text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>🤖 AI AMA Recap Generator</span>
          </button>
        </div>

        {/* QUESTION GENERATOR CONTENT */}
        {activeTool === 'questions' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Project Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Monster AI Chain"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Category / Sector
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-400"
                >
                  <option value="AI & Autonomous Agents">AI & Autonomous Agents</option>
                  <option value="Gaming & Metaverse">Gaming & Metaverse</option>
                  <option value="Meme Utility">Meme Utility</option>
                  <option value="DeFi & Yield">DeFi & Yield</option>
                  <option value="Real World Assets (RWA)">Real World Assets (RWA)</option>
                  <option value="Layer 1 / Layer 2 Infrastructure">Layer 1 / Layer 2 Infrastructure</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                Project Overview / Whitepaper Brief
              </label>
              <textarea
                rows={2}
                placeholder="Brief description of what the project builds, core innovation..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-400"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                Tokenomics & Utility Details
              </label>
              <input
                type="text"
                placeholder="e.g. $MAIC total supply 1 Billion, 40% ecosystem, staking yield, burn on transaction fee"
                value={tokenomics}
                onChange={(e) => setTokenomics(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-400"
              />
            </div>

            <button
              onClick={generateQuestions}
              disabled={loading || !projectName}
              className="w-full py-3 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 text-white font-bold text-xs rounded-xl shadow-lg hover:brightness-110 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              {loading ? (
                <span className="flex items-center space-x-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Gemini AI is crafting questions...</span>
                </span>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate 5 Killer AMA Questions</span>
                </>
              )}
            </button>

            {/* Generated Questions List */}
            {generatedQuestions.length > 0 && (
              <div className="mt-6 space-y-3 pt-4 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                    Generated AMA Questions ({generatedQuestions.length})
                  </h4>
                  <button
                    onClick={() => handleCopy(generatedQuestions.map(q => `${q.id}. [${q.category}] ${q.question}`).join('\n\n'), 'all')}
                    className="text-[11px] text-purple-400 hover:text-purple-200 flex items-center space-x-1 font-semibold"
                  >
                    {copiedId === 'all' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy All Questions</span>
                  </button>
                </div>

                {generatedQuestions.map((q: any) => (
                  <div key={q.id} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5 relative group">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        {q.category}
                      </span>
                      <button
                        onClick={() => handleCopy(q.question, `q-${q.id}`)}
                        className="p-1 rounded bg-slate-900 text-slate-400 hover:text-white"
                        title="Copy Question"
                      >
                        {copiedId === `q-${q.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <p className="text-xs font-bold text-slate-100">{q.question}</p>
                    {q.context && (
                      <p className="text-[11px] text-slate-400 italic">💡 Context: {q.context}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* RECAP GENERATOR CONTENT */}
        {activeTool === 'recap' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Project Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Apex Yield RWA"
                  value={recapProjectName}
                  onChange={(e) => setRecapProjectName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Guest Speakers
                </label>
                <input
                  type="text"
                  placeholder="e.g. Marcus Sterling (CEO), Sarah Lin (CRO)"
                  value={guestSpeakers}
                  onChange={(e) => setGuestSpeakers(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-400"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                Raw AMA Notes / Chat Transcript *
              </label>
              <textarea
                rows={4}
                placeholder="Paste key points discussed during the AMA or raw audio transcript..."
                value={rawNotes}
                onChange={(e) => setRawNotes(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-purple-400"
              />
            </div>

            <button
              onClick={generateRecap}
              disabled={loading || !recapProjectName || !rawNotes}
              className="w-full py-3 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 text-white font-bold text-xs rounded-xl shadow-lg hover:brightness-110 flex items-center justify-center space-x-2 transition-all disabled:opacity-50"
            >
              {loading ? (
                <span className="flex items-center space-x-2">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Gemini AI is analyzing AMA notes...</span>
                </span>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  <span>Generate Executive AMA Recap Report</span>
                </>
              )}
            </button>

            {/* Generated Recap Output */}
            {generatedRecap && (
              <div className="mt-6 p-4 rounded-2xl bg-slate-950 border border-purple-500/30 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h4 className="font-extrabold text-sm text-purple-300">{generatedRecap.title}</h4>
                    <p className="text-[10px] text-emerald-400 font-bold">Bullish Sentiment Index: {generatedRecap.bullishScore || 92}/100 🔥</p>
                  </div>
                  <button
                    onClick={() => handleCopy(JSON.stringify(generatedRecap, null, 2), 'recap-json')}
                    className="text-xs text-purple-400 hover:text-purple-200 flex items-center space-x-1"
                  >
                    {copiedId === 'recap-json' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>Copy Recap</span>
                  </button>
                </div>

                <div>
                  <h5 className="text-[11px] font-bold text-slate-400 uppercase">Executive Summary</h5>
                  <p className="text-xs text-slate-200 mt-1 leading-relaxed">{generatedRecap.executiveSummary}</p>
                </div>

                <div>
                  <h5 className="text-[11px] font-bold text-slate-400 uppercase mb-1">Key Takeaways</h5>
                  <ul className="list-disc list-inside text-xs text-slate-300 space-y-1">
                    {generatedRecap.keyTakeaways?.map((kt: string, idx: number) => (
                      <li key={idx}>{kt}</li>
                    ))}
                  </ul>
                </div>

                {generatedRecap.tweetThread && (
                  <div>
                    <h5 className="text-[11px] font-bold text-slate-400 uppercase mb-1">X / Twitter Thread Summary</h5>
                    <div className="bg-slate-900 p-3 rounded-xl space-y-1 text-xs text-slate-300">
                      {generatedRecap.tweetThread.map((tweet: string, idx: number) => (
                        <p key={idx} className="font-mono text-[11px]">{tweet}</p>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
