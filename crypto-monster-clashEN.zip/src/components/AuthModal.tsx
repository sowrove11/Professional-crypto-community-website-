import React, { useState } from 'react';
import { X, Mail, Lock, User, ShieldCheck, Flame, ArrowRight, Wallet } from 'lucide-react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  sendPasswordResetEmail,
  updateProfile 
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, googleProvider, db } from '../lib/firebase';
import { UserProfile } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  if (!isOpen) return null;

  const saveOrFetchUserDoc = async (uid: string, userEmail: string, name: string, wallet?: string) => {
    const userRef = doc(db, "users", uid);
    const snap = await getDoc(userRef);

    if (snap.exists()) {
      const data = snap.data();
      return {
        uid,
        email: userEmail,
        displayName: data.displayName || name || "Monster User",
        photoURL: data.photoURL || "",
        walletAddress: data.walletAddress || wallet || "",
        role: data.role || "user",
        xp: data.xp || 150,
        level: data.level || 1,
        referralCode: data.referralCode || `CMC-${uid.slice(0, 6).toUpperCase()}`,
        referralCount: data.referralCount || 0,
        earnedUsdt: data.earnedUsdt || 0,
        completedTasks: data.completedTasks || [],
      } as UserProfile;
    } else {
      const newUserDoc: UserProfile = {
        uid,
        email: userEmail,
        displayName: name || userEmail.split('@')[0] || "Monster User",
        photoURL: "",
        walletAddress: wallet || "0x71C...3A",
        role: userEmail.includes('admin') ? 'admin' : 'user',
        xp: 200, // Welcome XP
        level: 1,
        referralCode: `CMC-${uid.slice(0, 6).toUpperCase()}`,
        referralCount: 0,
        earnedUsdt: 0,
        completedTasks: [],
      };
      await setDoc(userRef, newUserDoc);
      return newUserDoc;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isForgotPassword) {
        await sendPasswordResetEmail(auth, email);
        setResetSent(true);
        setLoading(false);
        return;
      }

      if (isRegister) {
        if (!email || !password || !displayName) {
          throw new Error("Please fill in all required fields.");
        }
        const res = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(res.user, { displayName });
        const profile = await saveOrFetchUserDoc(res.user.uid, res.user.email!, displayName, walletAddress);
        onSuccess(profile);
        onClose();
      } else {
        const res = await signInWithEmailAndPassword(auth, email, password);
        const profile = await saveOrFetchUserDoc(res.user.uid, res.user.email!, res.user.displayName || displayName);
        onSuccess(profile);
        onClose();
      }
    } catch (err: any) {
      console.error("Auth error:", err);
      setError(err.message || "Authentication failed. Please check credentials.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError('');
    setLoading(true);
    try {
      const res = await signInWithPopup(auth, googleProvider);
      const profile = await saveOrFetchUserDoc(
        res.user.uid, 
        res.user.email!, 
        res.user.displayName || "Google User"
      );
      onSuccess(profile);
      onClose();
    } catch (err: any) {
      console.error("Google Auth Error:", err);
      setError("Google Sign In failed or popup closed.");
    } finally {
      setLoading(false);
    }
  };

  const handleDemoSignIn = async (role: 'user' | 'admin') => {
    setLoading(true);
    const demoEmail = role === 'admin' ? 'admin@cryptomonsterclash.com' : 'user@cryptomonsterclash.com';
    const demoName = role === 'admin' ? 'Monster Admin' : 'Crypto Master';
    const demoUid = role === 'admin' ? 'demo-admin-123' : 'demo-user-456';
    
    const profile: UserProfile = {
      uid: demoUid,
      email: demoEmail,
      displayName: demoName,
      photoURL: "",
      walletAddress: "0x71C8A9b23C41DE89004123",
      role: role,
      xp: role === 'admin' ? 9999 : 500,
      level: role === 'admin' ? 50 : 3,
      referralCode: `CMC-${role.toUpperCase()}`,
      referralCount: 12,
      earnedUsdt: 250,
      completedTasks: ["t1", "t2"],
    };
    onSuccess(profile);
    onClose();
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
      <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl relative text-slate-100 overflow-hidden">
        {/* Top Glow Accent */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-orange-500 to-red-600" />
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6 pt-2">
          <div className="inline-flex p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 mb-2">
            <Flame className="w-8 h-8 text-amber-400" />
          </div>
          <h3 className="text-2xl font-black tracking-tight text-white">
            {isForgotPassword 
              ? "Reset Password" 
              : isRegister 
                ? "Join Crypto Monster Clash" 
                : "Welcome Back!"}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {isRegister 
              ? "Sign up to track rewards, submit AMA questions & book services" 
              : "Sign in with your Firebase authenticated account"}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-950/80 border border-red-500/40 text-red-300 text-xs">
            {error}
          </div>
        )}

        {resetSent && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs">
            Password reset link sent to your email address.
          </div>
        )}

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="space-y-3">
          {isRegister && (
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1 uppercase tracking-wider">
                Display Name
              </label>
              <div className="relative">
                <User className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  required
                  placeholder="e.g. SatoshiNakamoto"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-[11px] font-bold text-slate-300 mb-1 uppercase tracking-wider">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
              <input
                type="email"
                required
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {!isForgotPassword && (
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                  Password
                </label>
                {!isRegister && (
                  <button
                    type="button"
                    onClick={() => setIsForgotPassword(true)}
                    className="text-[11px] text-amber-400 hover:underline"
                  >
                    Forgot Password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          {isRegister && (
            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1 uppercase tracking-wider">
                EVM Wallet Address (Optional for Airdrops)
              </label>
              <div className="relative">
                <Wallet className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                <input
                  type="text"
                  placeholder="0x..."
                  value={walletAddress}
                  onChange={(e) => setWalletAddress(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-extrabold text-sm rounded-xl shadow-lg hover:brightness-110 transition-all flex items-center justify-center space-x-2 mt-2"
          >
            {loading ? (
              <span>Authenticating...</span>
            ) : (
              <>
                <span>{isForgotPassword ? "Send Reset Email" : isRegister ? "Create Account" : "Sign In"}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-800" />
          </div>
          <div className="relative flex justify-center text-[10px] uppercase">
            <span className="bg-slate-900 px-2 text-slate-500 font-bold">Or continue with</span>
          </div>
        </div>

        {/* Google & Demo Sign In */}
        <div className="space-y-2">
          <button
            type="button"
            onClick={handleGoogleSignIn}
            className="w-full py-2.5 bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center space-x-2 transition-all"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.7 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.2 9 5 12 5z"/>
              <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.8z"/>
              <path fill="#FBBC05" d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3s.2-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.4 0 15.3s.7 5.6 1.9 8l3.7-2.9c-.6-.7-1-1.6-1-2.6z"/>
              <path fill="#34A853" d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.2-6.4-5.2L1.9 16c1.8 3.7 5.6 7 10.1 7z"/>
            </svg>
            <span>Google Authentication</span>
          </button>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleDemoSignIn('user')}
              className="py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] font-bold rounded-xl"
            >
              ⚡ Quick User Demo
            </button>
            <button
              type="button"
              onClick={() => handleDemoSignIn('admin')}
              className="py-2 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-[11px] font-bold rounded-xl"
            >
              🛡️ Admin Demo
            </button>
          </div>
        </div>

        {/* Footer Toggle */}
        <div className="mt-4 text-center text-xs text-slate-400">
          {isForgotPassword ? (
            <button
              onClick={() => setIsForgotPassword(false)}
              className="text-amber-400 font-bold hover:underline"
            >
              Back to Sign In
            </button>
          ) : (
            <p>
              {isRegister ? "Already have an account?" : "Don't have an account?"}{' '}
              <button
                onClick={() => {
                  setIsRegister(!isRegister);
                  setError('');
                }}
                className="text-amber-400 font-bold hover:underline"
              >
                {isRegister ? "Sign In" : "Register Now"}
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
