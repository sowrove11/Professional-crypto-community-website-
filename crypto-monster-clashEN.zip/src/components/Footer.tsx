import React from 'react';
import { Flame, Mail, Send, Twitter, Globe, MessageCircle, ExternalLink, ShieldCheck } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
  onOpenBookModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab, onOpenBookModal }) => {
  return (
    <footer className="bg-[#0A0A0B] border-t border-white/10 text-gray-400 pt-12 pb-8 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl overflow-hidden bg-[#00FF94] flex items-center justify-center p-0.5 shadow-lg shadow-[#00FF94]/20 border border-[#00FF94]/50">
                <img 
                  src="https://i.ibb.co.com/HfHGJ4s3/IMG-1578.jpg" 
                  alt="Crypto Monster Logo" 
                  className="w-full h-full object-cover rounded-lg"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <span className="font-black text-xl text-white tracking-tight uppercase">MONSTER <span className="text-[#00FF94]">CLASH</span></span>
              </div>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed max-w-sm">
              The ultimate Web3 AMA hub, marketing accelerator, and community platform. Connecting top tier crypto protocols with active investors, KOLs, and global communities.
            </p>
            <div className="flex items-center space-x-3 pt-2">
              <a 
                href="https://t.me/CryptoMonsterClashGlobal" 
                target="_blank" 
                rel="noreferrer"
                className="w-9 h-9 rounded-xl bg-[#141416] border border-white/10 text-[#00FF94] hover:bg-[#00FF94] hover:text-black flex items-center justify-center transition-all"
                title="Telegram Community"
              >
                <Send className="w-4 h-4" />
              </a>
              <a 
                href="https://x.com/MonsterClashX" 
                target="_blank" 
                rel="noreferrer"
                className="w-9 h-9 rounded-xl bg-[#141416] border border-white/10 text-[#00FF94] hover:bg-[#00FF94] hover:text-black flex items-center justify-center transition-all"
                title="X Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a 
                href="https://www.binance.com/en/square/profile/zakariahabib" 
                target="_blank" 
                rel="noreferrer"
                className="w-9 h-9 rounded-xl bg-[#141416] border border-white/10 text-[#00FF94] hover:bg-[#00FF94] hover:text-black flex items-center justify-center transition-all"
                title="Binance Square"
              >
                <Globe className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#00FF94] pl-2">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => setActiveTab('home')} className="hover:text-[#00FF94] transition-colors">
                  🏠 Home
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('amas')} className="hover:text-[#00FF94] transition-colors">
                  🎙 AMA Center
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('services')} className="hover:text-[#00FF94] transition-colors">
                  💼 Our Services
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('projects')} className="hover:text-[#00FF94] transition-colors">
                  🚀 Projects Directory
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('giveaways')} className="hover:text-[#00FF94] transition-colors">
                  🎁 Giveaways & Airdrops
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('leaderboard')} className="hover:text-[#00FF94] transition-colors">
                  🏆 Global Leaderboard
                </button>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#00FF94] pl-2">
              AMA & Marketing
            </h4>
            <ul className="space-y-2 text-xs font-mono">
              <li>Telegram Voice AMA</li>
              <li>X Spaces & Binance Square</li>
              <li>CMC & CoinGecko Trending</li>
              <li>Influencer / KOL Campaigns</li>
              <li>Press Release Distribution</li>
              <li>Community Growth & Quests</li>
            </ul>
          </div>

          {/* Direct Contacts */}
          <div>
            <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#00FF94] pl-2">
              Official Contact
            </h4>
            <div className="space-y-3 text-xs">
              <div className="bg-[#141416] border border-white/10 p-3 rounded-xl">
                <p className="text-[10px] text-gray-400 font-mono uppercase font-bold">Booking Manager</p>
                <p className="font-bold text-[#00FF94] text-sm font-mono">@CalvinHarrison</p>
              </div>
              <div className="flex items-center space-x-2 text-gray-300 truncate">
                <Mail className="w-4 h-4 text-[#00FF94] shrink-0" />
                <span className="truncate font-mono">cryptomonster231@gmail.com</span>
              </div>
              <div className="pt-2">
                <button
                  onClick={onOpenBookModal}
                  className="w-full py-2 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl shadow-lg hover:bg-[#00e082] transition-all"
                >
                  Book an AMA Now
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-6 flex flex-col md:flex-row items-center justify-between text-xs text-gray-500 font-mono space-y-3 md:space-y-0">
          <p>© 2026 Crypto Monster Clash. All rights reserved.</p>
          <div className="flex items-center space-x-4 text-gray-400">
            <span className="flex items-center space-x-1">
              <ShieldCheck className="w-4 h-4 text-[#00FF94]" />
              <span>Verified Web3 Partner</span>
            </span>
            <span>•</span>
            <span>Terms</span>
            <span>•</span>
            <span>Privacy</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
