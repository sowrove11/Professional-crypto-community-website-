import React, { useState } from 'react';
import { X, Calendar, Check, Copy, ArrowRight, ShieldCheck, QrCode, FileText, Coins } from 'lucide-react';
import { addDoc, collection } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { UserProfile, AMABooking, SiteConfig } from '../types';

interface BookAmaModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  siteConfig?: SiteConfig;
  selectedServiceTitle?: string;
  selectedPriceUsdt?: number;
}

export const BookAmaModal: React.FC<BookAmaModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  siteConfig,
  selectedServiceTitle,
  selectedPriceUsdt
}) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [projectName, setProjectName] = useState('');
  const [category, setCategory] = useState('AI & Web3');
  const [serviceType, setServiceType] = useState('AMA Services');
  const [packageName, setPackageName] = useState(selectedServiceTitle || 'Telegram Voice AMA ($899)');
  const [priceUsdt, setPriceUsdt] = useState(selectedPriceUsdt || 899);
  const [paymentChain, setPaymentChain] = useState<'TRC20' | 'BEP20' | 'ERC20' | 'SOL'>((siteConfig?.paymentNetwork as any) || 'TRC20');
  const [txHash, setTxHash] = useState('');
  const [notes, setNotes] = useState('');
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submittedBooking, setSubmittedBooking] = useState<AMABooking | null>(null);

  if (!isOpen) return null;

  // Deposit Addresses (Fallback to Admin SiteConfig or Default)
  const walletAddr = siteConfig?.usdtWalletAddress || "TY7xK9sL2mP4nQ8vR1tW3zX6yA5bC9dE0f";
  const qrCode = siteConfig?.qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${walletAddr}`;

  const handleCopyAddr = () => {
    navigator.clipboard.writeText(walletAddr);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handlePackageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setPackageName(val);
    if (val.includes('Text')) setPriceUsdt(499);
    else if (val.includes('Voice')) setPriceUsdt(899);
    else if (val.includes('X Spaces')) setPriceUsdt(1299);
    else if (val.includes('Binance')) setPriceUsdt(1499);
    else if (val.includes('Twitter')) setPriceUsdt(799);
    else if (val.includes('Trending')) setPriceUsdt(1800);
    else setPriceUsdt(650);
  };

  const handleCreateBooking = async () => {
    if (!projectName) return;
    setLoading(true);

    const newBooking: AMABooking = {
      id: `booking-${Date.now()}`,
      userId: currentUser ? currentUser.uid : "guest-user",
      userEmail: currentUser ? currentUser.email : "guest@cryptomonsterclash.com",
      projectName,
      projectCategory: category,
      serviceType,
      packageName,
      priceUsdt,
      paymentChain,
      paymentStatus: txHash ? "verified" : "pending",
      bookingStatus: "Pending",
      txHash: txHash || "0x_simulated_tx_hash_" + Date.now(),
      scheduledDate: "2026-08-12",
      notes,
      createdAt: new Date().toISOString()
    };

    try {
      await addDoc(collection(db, "bookings"), newBooking);
    } catch (e) {
      console.warn("Firestore offline or permission error, proceeding with local confirmation", e);
    }

    setSubmittedBooking(newBooking);
    setStep(3);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl relative text-slate-100 my-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-500/20">
            <Calendar className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Book an AMA or Marketing Campaign</h3>
            <p className="text-xs text-slate-400">Lock in your slot on Crypto Monster Clash Telegram, X Spaces & Binance Square</p>
          </div>
        </div>

        {/* Steps Breadcrumb */}
        <div className="flex items-center justify-between mb-6 border-b border-slate-800 pb-3 text-xs font-bold">
          <div className={`flex items-center space-x-2 ${step >= 1 ? 'text-amber-400' : 'text-slate-600'}`}>
            <span className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-[10px]">1</span>
            <span>Project Details</span>
          </div>
          <div className={`flex items-center space-x-2 ${step >= 2 ? 'text-amber-400' : 'text-slate-600'}`}>
            <span className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-[10px]">2</span>
            <span>USDT Deposit</span>
          </div>
          <div className={`flex items-center space-x-2 ${step === 3 ? 'text-amber-400' : 'text-slate-600'}`}>
            <span className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-[10px]">3</span>
            <span>Confirmation</span>
          </div>
        </div>

        {/* STEP 1: PROJECT & PACKAGE SELECT */}
        {step === 1 && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Project Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monster AI Chain"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">
                  Sector / Category
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                >
                  <option value="AI & Autonomous Agents">AI & Autonomous Agents</option>
                  <option value="Gaming & Metaverse">Gaming & Metaverse</option>
                  <option value="Meme Utility">Meme Utility</option>
                  <option value="DeFi & Yield">DeFi & Yield</option>
                  <option value="RWA & RWAs">RWA Real World Assets</option>
                  <option value="L1 / L2 Infrastructure">L1 / L2 Infrastructure</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                Select Service Package *
              </label>
              <select
                value={packageName}
                onChange={handlePackageChange}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              >
                <option value="Telegram Text AMA ($499)">Telegram Text AMA – $499 USDT</option>
                <option value="Telegram Voice / Video AMA ($899)">Telegram Voice / Video AMA – $899 USDT</option>
                <option value="X (Twitter) Spaces AMA ($1,299)">X (Twitter) Spaces AMA – $1,299 USDT</option>
                <option value="Binance Square Live AMA ($1,499)">Binance Square Live AMA – $1,499 USDT</option>
                <option value="X Viral Marketing Campaign ($799)">X Viral Marketing Campaign – $799 USDT</option>
                <option value="CoinMarketCap & CoinGecko Trending ($1,800)">CoinMarketCap & CoinGecko Trending – $1,800 USDT</option>
                <option value="Telegram Community Growth 10k ($650)">Telegram Community Growth 10,000 Members – $650 USDT</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                Preferred Schedule Date & Notes
              </label>
              <textarea
                rows={2}
                placeholder="Preferred date, special guest names, custom reward pool instructions..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold">Total Price</span>
                <p className="text-xl font-black text-amber-400">${priceUsdt} USDT</p>
              </div>
              <button
                disabled={!projectName}
                onClick={() => setStep(2)}
                className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 flex items-center space-x-2 disabled:opacity-50"
              >
                <span>Proceed to Payment</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: PAYMENT DEPOSIT */}
        {step === 2 && (
          <div className="space-y-4">
            <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20">
              <div className="flex justify-between items-center mb-3">
                <span className="text-xs font-bold text-slate-300">Select Network</span>
                <span className="text-xs font-black text-amber-400">${priceUsdt} USDT</span>
              </div>
              
              <div className="grid grid-cols-4 gap-2 mb-4">
                {(['TRC20', 'BEP20', 'ERC20', 'SOL'] as const).map((chain) => (
                  <button
                    key={chain}
                    type="button"
                    onClick={() => setPaymentChain(chain)}
                    className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                      paymentChain === chain
                        ? 'bg-amber-500 text-slate-950 border-amber-400'
                        : 'bg-slate-900 border-slate-800 text-slate-300'
                    }`}
                  >
                    USDT-{chain}
                  </button>
                ))}
              </div>

              {/* Deposit Address Box with QR Code */}
              <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 flex flex-col md:flex-row items-center gap-4">
                {qrCode && (
                  <div className="p-2 bg-white rounded-xl shrink-0">
                    <img src={qrCode} alt="Payment QR Code" className="w-24 h-24 object-contain" />
                  </div>
                )}
                <div className="space-y-2 flex-1 w-full">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-400 uppercase font-bold">Admin Wallet Address ({paymentChain})</span>
                    <button
                      type="button"
                      onClick={handleCopyAddr}
                      className="text-[10px] text-amber-400 hover:underline flex items-center space-x-1 cursor-pointer"
                    >
                      {copiedAddress ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedAddress ? 'Copied Address!' : 'Copy Address'}</span>
                    </button>
                  </div>
                  <p className="font-mono text-xs font-bold text-[#00FF94] bg-black/50 p-2 rounded-lg break-all select-all border border-slate-800">
                    {walletAddr}
                  </p>
                  {siteConfig?.paymentNotes && (
                    <p className="text-[10px] text-slate-400 leading-tight">
                      ℹ️ {siteConfig.paymentNotes}
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-300 mb-1">
                Transaction Hash (TX Hash) / Payment Ref *
              </label>
              <input
                type="text"
                placeholder="e.g. 0x8a91f3..."
                value={txHash}
                onChange={(e) => setTxHash(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400 font-mono"
              />
              <p className="text-[10px] text-slate-500 mt-1">
                Enter your blockchain transaction hash after transferring USDT, or leave placeholder for instant verification review.
              </p>
            </div>

            <div className="flex space-x-2">
              <button
                onClick={() => setStep(1)}
                className="w-1/3 py-2.5 bg-slate-950 border border-slate-800 text-slate-400 font-bold text-xs rounded-xl"
              >
                Back
              </button>
              <button
                onClick={handleCreateBooking}
                disabled={loading}
                className="w-2/3 py-2.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg hover:brightness-110 flex items-center justify-center space-x-2"
              >
                {loading ? (
                  <span>Submitting Booking...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Submit Payment Verification</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: CONFIRMATION & INVOICE */}
        {step === 3 && submittedBooking && (
          <div className="text-center space-y-4 py-2">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-7 h-7" />
            </div>
            <h4 className="text-xl font-black text-white">Booking Order Submitted!</h4>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              Your order for <strong className="text-slate-200">{submittedBooking.packageName}</strong> has been received by Booking Manager <strong className="text-amber-400">@CalvinHarrison</strong>.
            </p>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-left text-xs space-y-2 max-w-md mx-auto">
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-slate-500">Booking ID:</span>
                <span className="font-mono font-bold text-amber-400">{submittedBooking.id}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-slate-500">Project:</span>
                <span className="font-bold text-slate-200">{submittedBooking.projectName}</span>
              </div>
              <div className="flex justify-between border-b border-slate-900 pb-1.5">
                <span className="text-slate-500">Amount Paid:</span>
                <span className="font-bold text-emerald-400">${submittedBooking.priceUsdt} USDT ({submittedBooking.paymentChain})</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">TX Hash:</span>
                <span className="font-mono text-[10px] text-slate-400 truncate max-w-[150px]">{submittedBooking.txHash}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="px-8 py-2.5 bg-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-lg"
            >
              Close & View My Bookings
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
