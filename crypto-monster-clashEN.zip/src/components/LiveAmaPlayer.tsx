import React, { useState } from 'react';
import { Mic, Volume2, Send, Heart, Users, MessageSquare, Flame, CheckCircle, Radio, Play, Pause, Sparkles } from 'lucide-react';
import { AMAItem, LiveChatMessage } from '../types';

interface LiveAmaPlayerProps {
  ama: AMAItem;
  onAskQuestion: (q: string) => void;
}

export const LiveAmaPlayer: React.FC<LiveAmaPlayerProps> = ({ ama, onAskQuestion }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [questionText, setQuestionText] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [likes, setLikes] = useState(1420);
  const [pollVotedOption, setPollVotedOption] = useState<number | null>(null);

  const [messages, setMessages] = useState<LiveChatMessage[]>([
    { id: '1', userId: 'u1', userName: 'CryptoWhale_99', text: '🔥 Bullish on MAIC AI agent smart contracts!', timestamp: '14:02' },
    { id: '2', userId: 'u2', userName: 'SatoshiDreamer', text: 'When is mainnet launch date confirmed?', timestamp: '14:03' },
    { id: '3', userId: 'u3', userName: 'Dr. Aris Thorne (Speaker)', text: 'Mainnet launches Q3! Tier 1 exchange confirmed.', timestamp: '14:04', isPinned: true },
    { id: '4', userId: 'u4', userName: 'AlphaHunter_X', text: 'Great AMA host! Sending $MAIC to moon 🚀', timestamp: '14:05' },
  ]);

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    const newMsg: LiveChatMessage = {
      id: Date.now().toString(),
      userId: 'user-me',
      userName: 'You',
      text: chatInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setMessages(prev => [...prev, newMsg]);
    setChatInput('');
  };

  const handleSendQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!questionText.trim()) return;
    onAskQuestion(questionText);
    setQuestionText('');
  };

  return (
    <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-slate-100">
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Info */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <img 
              src={ama.projectLogo} 
              alt={ama.projectName} 
              className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-500/40 shadow-lg" 
            />
            <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="bg-red-950 text-red-200 border border-red-500/40 text-[10px] font-black px-2 py-0.5 rounded-full uppercase flex items-center space-x-1">
                <Radio className="w-3 h-3 text-red-400 animate-pulse" />
                <span>{ama.platform}</span>
              </span>
              <span className="text-xs text-amber-400 font-extrabold">{ama.category}</span>
            </div>
            <h3 className="text-xl font-black text-white mt-1 leading-snug">{ama.title}</h3>
            <p className="text-xs text-slate-400">
              Host: <span className="text-slate-200 font-bold">{ama.hostName}</span> | Speakers: <span className="text-amber-300">{ama.guestSpeakers.join(', ')}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-xl text-xs font-bold text-slate-300 flex items-center space-x-1.5">
            <Users className="w-4 h-4 text-amber-400" />
            <span>{ama.viewsCount.toLocaleString()} Listening</span>
          </div>
          <button 
            onClick={() => setLikes(likes + 1)}
            className="bg-red-950/60 hover:bg-red-900/60 border border-red-500/40 px-3 py-1.5 rounded-xl text-xs font-bold text-red-300 flex items-center space-x-1.5 transition-all"
          >
            <Heart className="w-4 h-4 text-red-500 fill-red-500 animate-pulse" />
            <span>{likes}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Audio Visualizer Player + Live Chat */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Player Stage & Questions */}
        <div className="lg:col-span-2 space-y-4">
          {/* Audio Waveform Stage */}
          <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800 relative overflow-hidden flex flex-col items-center justify-center min-h-[220px]">
            <div className="flex items-center space-x-4 mb-6">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-14 h-14 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 flex items-center justify-center shadow-lg shadow-orange-500/30 hover:scale-105 transition-transform"
              >
                {isPlaying ? <Pause className="w-6 h-6 fill-slate-950" /> : <Play className="w-6 h-6 fill-slate-950 ml-0.5" />}
              </button>

              {/* Animated Waveform Bars */}
              <div className="flex items-center space-x-1 h-12">
                {[40, 75, 25, 90, 60, 100, 45, 80, 30, 95, 50, 70, 85, 40, 90].map((height, i) => (
                  <div
                    key={i}
                    style={{ height: isPlaying ? `${height}%` : '20%' }}
                    className="w-1.5 bg-gradient-to-t from-amber-500 to-orange-400 rounded-full transition-all duration-300"
                  />
                ))}
              </div>
            </div>

            <p className="text-xs text-amber-300/80 font-mono font-bold">
              {isPlaying ? '🔊 LIVE AUDIO BROADCASTING FROM STAGE' : '⏸ BROADCAST PAUSED'}
            </p>

            {/* Live Poll Widget */}
            <div className="w-full mt-4 p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs space-y-2">
              <div className="flex items-center justify-between text-slate-300 font-bold">
                <span>📊 Live AMA Sentiment Poll: Bullish on Mainnet Launch?</span>
                <span className="text-[10px] text-slate-500">2,410 Votes</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setPollVotedOption(1)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                    pollVotedOption === 1 ? 'bg-emerald-500 text-slate-950' : 'bg-slate-950 text-emerald-400 border border-emerald-500/30'
                  }`}
                >
                  🚀 Extremely Bullish (88%)
                </button>
                <button
                  onClick={() => setPollVotedOption(2)}
                  className={`py-1.5 rounded-lg text-xs font-bold transition-all ${
                    pollVotedOption === 2 ? 'bg-amber-500 text-slate-950' : 'bg-slate-950 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  👀 Watching Roadmap (12%)
                </button>
              </div>
            </div>
          </div>

          {/* Ask AMA Question Box */}
          <form onSubmit={handleSendQuestion} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
            <label className="block text-xs font-bold text-amber-400 flex items-center space-x-1">
              <MessageSquare className="w-4 h-4" />
              <span>Submit Question for Guest Speakers ($3,000 USDT Reward Pool)</span>
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Ask about tokenomics, roadmap, tier 1 listings..."
                value={questionText}
                onChange={(e) => setQuestionText(e.target.value)}
                className="flex-1 px-3.5 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 font-bold text-xs rounded-xl shadow-md hover:brightness-110 flex items-center space-x-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Col: Live Chat Feed */}
        <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 flex flex-col h-[380px]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <span className="text-xs font-bold text-slate-200 flex items-center space-x-1.5">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Live Stage Chat</span>
            </span>
            <span className="text-[10px] text-emerald-400 font-mono">● Active</span>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 text-xs">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`p-2 rounded-xl text-xs ${
                  msg.isPinned 
                    ? 'bg-amber-500/10 border border-amber-500/40 text-amber-200' 
                    : 'bg-slate-900 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] mb-0.5">
                  <span className={`font-bold ${msg.isPinned ? 'text-amber-400' : 'text-slate-400'}`}>
                    {msg.userName}
                  </span>
                  <span className="text-slate-500">{msg.timestamp}</span>
                </div>
                <p className="leading-snug">{msg.text}</p>
              </div>
            ))}
          </div>

          {/* Send Chat */}
          <form onSubmit={handleSendChat} className="mt-3 pt-2 border-t border-slate-800 flex space-x-1.5">
            <input
              type="text"
              placeholder="Chat with community..."
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-amber-400"
            />
            <button
              type="submit"
              className="p-2 bg-amber-500 text-slate-950 rounded-xl hover:bg-amber-400 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
