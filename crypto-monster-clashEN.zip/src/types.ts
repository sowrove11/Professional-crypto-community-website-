export interface SectionVisibilityConfig {
  liveAma?: boolean;
  upcomingAmas?: boolean;
  featuredAmas?: boolean;
  recaps?: boolean;
  amaRecaps?: boolean;
  featuredProjects?: boolean;
  trendingProjects?: boolean;
  liveCampaigns?: boolean;
  giveaways?: boolean;
  airdrops?: boolean;
  featuredCommunities?: boolean;
  communities?: boolean;
  leaderboard?: boolean;
  partners?: boolean;
  testimonials?: boolean;
  latestNews?: boolean;
  news?: boolean;
  announcements?: boolean;
  statistics?: boolean;
  sponsors?: boolean;
  customHtml?: boolean;
  customBlocks?: boolean;
}

export interface SiteConfig {
  announcementText: string;
  announcementPool: string;
  heroHeadline: string;
  heroHighlight: string;
  heroDescription: string;
  heroSubtitle?: string;
  heroCtaText?: string;
  heroCtaLink?: string;
  heroSecondaryCtaText?: string;
  heroBgUrl?: string;
  featuredProjectId?: string;
  promotionalBannerUrl?: string;
  nextAmaCountdownHours: number;
  nextAmaCountdownMinutes: number;
  telegramLink: string;
  twitterLink: string;
  bookingTelegram: string;
  supportEmail: string;

  // Payment System Configuration
  usdtWalletAddress?: string;
  paymentNetwork?: "TRC20" | "BEP20" | "ERC20" | "SOL";
  qrCodeUrl?: string;
  paymentNotes?: string;

  // Section Visibility Controls
  sectionVisibility?: SectionVisibilityConfig;
  customHtmlContent?: string;
}

export type AMAPlatform = 
  | "Telegram Text AMA" 
  | "Telegram Voice AMA" 
  | "Telegram Video AMA" 
  | "X Spaces AMA" 
  | "Binance Square AMA" 
  | "Discord AMA"
  | "YouTube Live AMA"
  | "Custom Live AMA"
  | "Multi-platform AMA"
  | "Community AMA Hosting";

export type AMAStatus = 
  | "draft" 
  | "pending_approval" 
  | "upcoming" 
  | "live" 
  | "paused" 
  | "ended" 
  | "cancelled" 
  | "archived";

export interface ExternalLinkItem {
  id: string;
  label: string;
  url: string;
  type: "Telegram" | "X" | "YouTube" | "Binance" | "Website" | "Discord" | "CoinMarketCap" | "CoinGecko" | "Contract" | "Whitepaper" | "GitHub" | "Custom";
}

export interface AMASpeaker {
  name: string;
  role?: string;
  photoUrl?: string;
  socialUrl?: string;
}

export interface AMAItem {
  id: string;
  title: string;
  projectName: string;
  projectLogo: string;
  bannerUrl?: string;
  category: string; // e.g. AI, Gaming, Meme, DeFi, RWA, etc.
  platform: AMAPlatform;
  status: AMAStatus;
  scheduledAt: string; // ISO string or readable date
  date?: string;
  startTime?: string;
  endTime?: string;
  timezone?: string;
  rewardPool: string;
  tokenReward?: string;
  usdtReward?: string;
  maxParticipants?: number;
  rules?: string;
  questionsList?: string[];
  description: string;
  guestSpeakers: string[];
  speakers?: AMASpeaker[];
  hostName: string;
  recordingUrl?: string;
  recapUrl?: string;
  recapText?: string;
  liveStreamUrl?: string;
  viewsCount: number;
  questionsCount: number;
  featured?: boolean;
  externalLinks?: ExternalLinkItem[];
  // Live Broadcast State
  liveControlState?: {
    listenerCount: number;
    isSlowMode: boolean;
    isMuted: boolean;
    pinnedMessage?: string;
    isEmergencyShutdown: boolean;
    announcement?: string;
    poll?: {
      question: string;
      options: string[];
      votes: number[];
    };
  };
}

export interface ServiceItem {
  id: string;
  title: string;
  category: "AMA Services" | "Marketing Services" | "Community Growth" | "Promotions";
  description: string;
  priceUsdt: number;
  features: string[];
  iconName: string;
  popular?: boolean;
}

export interface ProjectItem {
  id: string;
  name: string;
  ticker: string;
  logo: string;
  category: "AI" | "Gaming" | "Meme" | "DeFi" | "NFT" | "RWA" | "Infrastructure" | "Exchange";
  description: string;
  websiteUrl: string;
  telegramUrl: string;
  twitterUrl: string;
  marketCap?: string;
  isFeatured?: boolean;
  isTrending?: boolean;
  isVerified?: boolean;
  votesCount: number;
}

export interface CommunityItem {
  id: string;
  name: string;
  platform: "Telegram" | "X" | "Discord";
  logo: string;
  membersCount: number;
  category: string;
  link: string;
  isVerified?: boolean;
  isTrending?: boolean;
}

export interface GiveawayTask {
  id: string;
  title: string;
  type: "telegram" | "twitter" | "discord" | "wallet" | "visit";
  link?: string;
  completed?: boolean;
}

export interface GiveawayItem {
  id: string;
  title: string;
  projectName: string;
  projectLogo: string;
  prizePool: string;
  winnersCount: number;
  status: "live" | "upcoming" | "ended";
  endsAt: string;
  tasks: GiveawayTask[];
  participantsCount: number;
  winners?: string[];
}

export interface AirdropItem {
  id: string;
  title: string;
  projectName: string;
  projectLogo: string;
  estimatedValue: string;
  status: "live" | "upcoming" | "ended";
  endsAt: string;
  requirements: string[];
  claimUrl?: string;
  participantsCount: number;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  avatar: string;
  scoreOrXp: number;
  badges: string[];
  change: "up" | "down" | "same";
}

export interface AMABooking {
  id: string;
  userId: string;
  userEmail: string;
  projectName: string;
  projectCategory: string;
  serviceType: string;
  packageName: string;
  priceUsdt: number;
  paymentChain: "TRC20" | "BEP20" | "ERC20";
  paymentStatus: "pending" | "verified" | "rejected";
  bookingStatus: "Pending" | "Approved" | "Rejected" | "Completed";
  txHash?: string;
  scheduledDate?: string;
  notes?: string;
  createdAt: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  walletAddress?: string;
  role: "user" | "admin";
  xp: number;
  level: number;
  referralCode: string;
  referralCount: number;
  earnedUsdt: number;
  completedTasks: string[];
}

export interface NewsArticle {
  id: string;
  title: string;
  category: "Latest News" | "AMA Recaps" | "Announcements" | "Partnerships" | "Exchange Listings";
  summary: string;
  content: string;
  imageUrl: string;
  author: string;
  date: string;
  readTime: string;
}

export interface PartnerItem {
  id: string;
  name: string;
  category: "Media Partners" | "Community Partners" | "KOL Partners" | "Exchange Partners" | "Sponsors";
  logo: string;
  website: string;
}

export interface LiveChatMessage {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  text: string;
  timestamp: string;
  isPinned?: boolean;
}
