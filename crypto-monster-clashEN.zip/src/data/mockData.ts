import { AMAItem, ServiceItem, ProjectItem, CommunityItem, GiveawayItem, AirdropItem, LeaderboardEntry, NewsArticle, PartnerItem, SiteConfig } from "../types";

export const INITIAL_SITE_CONFIG: SiteConfig = {
  announcementText: "Monster AI Chain Voice AMA – $3,000 USDT Reward Pool Open!",
  announcementPool: "$3,000 USDT Pool",
  heroHeadline: "Amplify Your Web3 Project With",
  heroHighlight: "Monster Reach",
  heroSubtitle: "The Premier Web3 Launchpad & High-Impact AMA Stage",
  heroDescription: "Host high-impact Telegram Voice, X Spaces & Binance Square AMAs. Reach 500,000+ active crypto investors, top KOL retweets & AI-driven recap tools.",
  heroCtaText: "Book AMA Package",
  heroCtaLink: "services",
  heroSecondaryCtaText: "Explore AI Tools",
  heroBgUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=1600&auto=format&fit=crop&q=80",
  featuredProjectId: "proj-1",
  promotionalBannerUrl: "",
  nextAmaCountdownHours: 14,
  nextAmaCountdownMinutes: 28,
  telegramLink: "https://t.me/CryptoMonsterClashGlobal",
  twitterLink: "https://x.com/MonsterClashX",
  bookingTelegram: "@CalvinHarrison",
  supportEmail: "cryptomonster231@gmail.com",

  // Payment System Defaults
  usdtWalletAddress: "TY7xK9sL2mP4nQ8vR1tW3zX6yA5bC9dE0f",
  paymentNetwork: "TRC20",
  qrCodeUrl: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=TY7xK9sL2mP4nQ8vR1tW3zX6yA5bC9dE0f",
  paymentNotes: "Send exact USDT amount to the wallet address below. Include your Booking ID in transaction memo or send screenshot to @CalvinHarrison on Telegram.",

  // Section Visibility Defaults
  sectionVisibility: {
    liveAma: true,
    upcomingAmas: true,
    featuredAmas: true,
    recaps: true,
    featuredProjects: true,
    trendingProjects: true,
    giveaways: true,
    airdrops: true,
    communities: true,
    leaderboard: true,
    partners: true,
    testimonials: true,
    news: true,
    announcements: true,
    statistics: true,
    sponsors: true,
    customHtml: true,
  },
  customHtmlContent: "<div class='p-4 bg-gradient-to-r from-[#00FF94]/10 via-amber-500/10 to-transparent border border-[#00FF94]/30 rounded-2xl text-center'><p class='text-xs font-mono font-bold text-[#00FF94] uppercase tracking-wider'>⚡ Hot Announcement: Tier-1 CEX Fast-Track Submissions Now Open for Q3 Project Batch!</p></div>"
};

export const INITIAL_AMAS: AMAItem[] = [
  {
    id: "ama-1",
    title: "Monster Clash X AI Agent Protocols: Next-Gen Autonomous Gaming Economy",
    projectName: "Monster AI Chain",
    projectLogo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=150&auto=format&fit=crop&q=80",
    category: "AI",
    platform: "Telegram Voice AMA",
    status: "live",
    scheduledAt: "2026-08-08T02:00:00Z",
    rewardPool: "$3,000 USDT + 50,000 $MAIC",
    description: "Deep dive into autonomous AI NPC agents, decentralized compute clusters, and the upcoming mainnet token launch.",
    guestSpeakers: ["Dr. Aris Thorne (Founder)", "Elena Vance (Head of AI)"],
    hostName: "Calvin Harrison (@CalvinHarrison)",
    liveStreamUrl: "https://t.me/CryptoMonsterClashGlobal",
    viewsCount: 14250,
    questionsCount: 382,
    featured: true,
  },
  {
    id: "ama-2",
    title: "DeFi 3.0 Real World Assets (RWA) Yield Protocols",
    projectName: "Apex Yield RWA",
    projectLogo: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=150&auto=format&fit=crop&q=80",
    category: "RWA",
    platform: "X Spaces AMA",
    status: "upcoming",
    scheduledAt: "2026-08-09T16:00:00Z",
    rewardPool: "$5,000 USDT Airdrop",
    description: "Learn how Apex Yield tokenizes institutional real estate and US Treasuries on-chain with 14% APY.",
    guestSpeakers: ["Marcus Sterling (CEO)", "Sarah Lin (Chief Risk Officer)"],
    hostName: "Zakaria Habib (Binance Square)",
    viewsCount: 8900,
    questionsCount: 215,
    featured: true,
  },
  {
    id: "ama-3",
    title: "Meme Coin Utility Revolution: Gamified Staking & Battle Arena",
    projectName: "Doge Monster Token",
    projectLogo: "https://images.unsplash.com/photo-1622979135225-d2ba269bc1bd?w=150&auto=format&fit=crop&q=80",
    category: "Meme",
    platform: "Telegram Text AMA",
    status: "upcoming",
    scheduledAt: "2026-08-11T18:00:00Z",
    rewardPool: "$2,500 $DOGEMN",
    description: "The viral meme community presenting its cross-chain Telegram tap-to-earn game and NFT marketplace.",
    guestSpeakers: ["GigaChad Dev", "CryptoCat (Community Lead)"],
    hostName: "Calvin Harrison",
    viewsCount: 12100,
    questionsCount: 450,
    featured: false,
  },
  {
    id: "ama-4",
    title: "Zero-Knowledge Infrastructure & Cross-Chain Privacy Scaling",
    projectName: "ZK-Clash Protocol",
    projectLogo: "https://images.unsplash.com/photo-1639762681057-408e52192e55?w=150&auto=format&fit=crop&q=80",
    category: "Infrastructure",
    platform: "Binance Square AMA",
    status: "ended",
    scheduledAt: "2026-08-05T14:00:00Z",
    rewardPool: "$4,000 USDT",
    description: "Full recap on ZK-Rollup speed benchmarks, developer grants, and Tier-1 exchange listing announcements.",
    guestSpeakers: ["Alexey Petrov (Core Dev)"],
    hostName: "Zakaria Habib",
    recordingUrl: "https://binance.com/en/square/profile/zakariahabib",
    recapUrl: "#recap-ama-4",
    recapText: "Key Takeaways: 1. ZK-Clash achieved 100,000 TPS on testnet. 2. $2M Developer Eco-Fund opened. 3. Listing confirmed on Top 3 CEX in Q3.",
    viewsCount: 28400,
    questionsCount: 890,
    featured: true,
  }
];

export const INITIAL_SERVICES: ServiceItem[] = [
  // AMA Services
  {
    id: "srv-1",
    title: "Telegram Text AMA",
    category: "AMA Services",
    description: "Interactive 60-min text-based session in Crypto Monster Clash Telegram (150K+ Active Web3 members) with custom graphics, live host, and quiz rewards.",
    priceUsdt: 499,
    features: [
      "Custom Graphic Banner & Promo Posters",
      "Announcement pinned across 5 Partner Channels",
      "$200 Giveaway Reward Pool Management",
      "Complete AI Summary & Recap Published",
      "Transcripts & Q&A archive"
    ],
    iconName: "MessageSquare",
    popular: true,
  },
  {
    id: "srv-2",
    title: "Telegram Voice / Video AMA",
    category: "AMA Services",
    description: "High-energy live audio/video streaming in main Telegram stage with professional host, real-time listener engagement, and recording distribution.",
    priceUsdt: 899,
    features: [
      "Professional Web3 Host & Speaker Moderation",
      "Live Voice Recording & YouTube upload",
      "Cross-promoted on X / Twitter & Binance Square",
      "$300 Giveaway Distribution",
      "Detailed Analytics & Audience Engagement Report"
    ],
    iconName: "Mic",
    popular: true,
  },
  {
    id: "srv-3",
    title: "X (Twitter) Spaces AMA",
    category: "AMA Services",
    description: "Massive reach on X Spaces hosted on official @MonsterClashX profile (200K+ followers) with top crypto KOL retweets and space recording.",
    priceUsdt: 1299,
    features: [
      "Hosted on @MonsterClashX main account",
      "5+ Crypto Influencer co-hosts & retweets",
      "Dedicated pre-AMA campaign & Twitter threads",
      "Post-AMA recap article & news feature",
      "Guaranteed 5,000+ listener reach"
    ],
    iconName: "Radio",
    popular: true,
  },
  {
    id: "srv-4",
    title: "Binance Square Live AMA",
    category: "AMA Services",
    description: "Official Binance Square stream and article release reaching millions of Binance ecosystem traders.",
    priceUsdt: 1499,
    features: [
      "Published on Verified Binance Square Creator profile",
      "Direct exposure to Binance active traders",
      "SEO Indexing on Google & CoinMarketCap",
      "Full transcript + custom infographic"
    ],
    iconName: "Globe",
  },
  // Marketing Services
  {
    id: "srv-5",
    title: "X (Twitter) Viral Marketing Campaign",
    category: "Marketing Services",
    description: "Targeted influencer threads, trending hashtags, pinned posts, and engagement push across 50+ crypto micro-KOLs.",
    priceUsdt: 799,
    features: [
      "3x In-depth Twitter Threads",
      "50+ Crypto Influencer Retweets & Comments",
      "Trending Campaign Push",
      "Real-time analytics dashboard"
    ],
    iconName: "Share2",
    popular: true,
  },
  {
    id: "srv-6",
    title: "CoinMarketCap & CoinGecko Trending Promotion",
    category: "Marketing Services",
    description: "Boost your token visibility to top spot on CoinMarketCap & CoinGecko trending lists.",
    priceUsdt: 1800,
    features: [
      "Guaranteed Top 10 CMC/CG Trending Position",
      "Fast-track listing assistance",
      "DexScreener & DEXTools trending boost"
    ],
    iconName: "TrendingUp",
  },
  {
    id: "srv-7",
    title: "Press Release Distribution (50+ Media Outlets)",
    category: "Marketing Services",
    description: "Publish your press releases on Cointelegraph, CoinDesk, Yahoo Finance, CryptoSlate, and MarketWatch.",
    priceUsdt: 1200,
    features: [
      "Guaranteed publication on 50+ crypto news sites",
      "Google News Indexing",
      "Dofollow backlinks for SEO ranking"
    ],
    iconName: "Newspaper",
  },
  // Community Growth
  {
    id: "srv-8",
    title: "Telegram Channel & Group Growth Package",
    category: "Community Growth",
    description: "Organic Web3 user acquisition bringing 10,000+ real active crypto investors to your Telegram group.",
    priceUsdt: 650,
    features: [
      "10,000 Real Verified Crypto Members",
      "24/7 Anti-Spam & Bot Moderation Setup",
      "Shilling & Chat Activity Stimulation"
    ],
    iconName: "Users",
  },
  {
    id: "srv-9",
    title: "Discord Community & Ambassador Campaign",
    category: "Community Growth",
    description: "Setup custom Discord server, custom role quest bot, and recruit 20 active Web3 regional ambassadors.",
    priceUsdt: 850,
    features: [
      "Discord Server Optimization & Role Automation",
      "20 Handpicked Regional Crypto Ambassadors",
      "Quest & Task XP Engine"
    ],
    iconName: "ShieldCheck",
  }
];

export const INITIAL_PROJECTS: ProjectItem[] = [
  {
    id: "proj-1",
    name: "Monster AI Chain",
    ticker: "MAIC",
    logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
    category: "AI",
    description: "Decentralized L1 blockchain optimized for sub-millisecond AI agent smart contract execution.",
    websiteUrl: "https://monsterclash.io",
    telegramUrl: "https://t.me/CryptoMonsterClashGlobal",
    twitterUrl: "https://x.com/MonsterClashX",
    marketCap: "$42.5M",
    isFeatured: true,
    isTrending: true,
    isVerified: true,
    votesCount: 3420,
  },
  {
    id: "proj-2",
    name: "Apex Yield RWA",
    ticker: "AYRWA",
    logo: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=120&auto=format&fit=crop&q=80",
    category: "RWA",
    description: "Tokenizing prime real estate and commercial debt for transparent double-digit APY yields.",
    websiteUrl: "https://apexyield.io",
    telegramUrl: "https://t.me/CryptoMonsterClashGlobal",
    twitterUrl: "https://x.com/MonsterClashX",
    marketCap: "$18.2M",
    isFeatured: true,
    isTrending: false,
    isVerified: true,
    votesCount: 2190,
  },
  {
    id: "proj-3",
    name: "Doge Monster",
    ticker: "DOGEMN",
    logo: "https://images.unsplash.com/photo-1622979135225-d2ba269bc1bd?w=120&auto=format&fit=crop&q=80",
    category: "Meme",
    description: "Community-driven meme coin featuring Telegram battle arenas and deflationary burn mechanics.",
    websiteUrl: "https://dogemonster.xyz",
    telegramUrl: "https://t.me/CryptoMonsterClashGlobal",
    twitterUrl: "https://x.com/MonsterClashX",
    marketCap: "$8.9M",
    isFeatured: false,
    isTrending: true,
    isVerified: false,
    votesCount: 5120,
  },
  {
    id: "proj-4",
    name: "HyperDex V4",
    ticker: "HYPER",
    logo: "https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=120&auto=format&fit=crop&q=80",
    category: "DeFi",
    description: "Intent-based cross-chain liquidity aggregator with zero slippage order routing.",
    websiteUrl: "https://hyperdex.fi",
    telegramUrl: "https://t.me/CryptoMonsterClashGlobal",
    twitterUrl: "https://x.com/MonsterClashX",
    marketCap: "$65.0M",
    isFeatured: true,
    isTrending: true,
    isVerified: true,
    votesCount: 1840,
  }
];

export const INITIAL_COMMUNITIES: CommunityItem[] = [
  {
    id: "comm-1",
    name: "Crypto Monster Clash Global",
    platform: "Telegram",
    logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
    membersCount: 154200,
    category: "Main Crypto Hub",
    link: "https://t.me/CryptoMonsterClashGlobal",
    isVerified: true,
    isTrending: true,
  },
  {
    id: "comm-2",
    name: "Crypto Monster Announcements",
    platform: "Telegram",
    logo: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=120&auto=format&fit=crop&q=80",
    membersCount: 98500,
    category: "News & Airdrops",
    link: "https://t.me/CryptoMonsterClashAnn",
    isVerified: true,
    isTrending: true,
  },
  {
    id: "comm-3",
    name: "@MonsterClashX Official",
    platform: "X",
    logo: "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=120&auto=format&fit=crop&q=80",
    membersCount: 210000,
    category: "X Spaces & AMAs",
    link: "https://x.com/MonsterClashX",
    isVerified: true,
    isTrending: true,
  },
  {
    id: "comm-4",
    name: "Binance Square Creator Hub",
    platform: "X",
    logo: "https://images.unsplash.com/photo-1622979135225-d2ba269bc1bd?w=120&auto=format&fit=crop&q=80",
    membersCount: 85000,
    category: "Binance Traders",
    link: "https://www.binance.com/en/square/profile/zakariahabib",
    isVerified: true,
    isTrending: false,
  }
];

export const INITIAL_GIVEAWAYS: GiveawayItem[] = [
  {
    id: "gw-1",
    title: "$5,000 USDT Monster AI Mainnet Celebration Giveaway",
    projectName: "Monster AI Chain",
    projectLogo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
    prizePool: "$5,000 USDT",
    winnersCount: 50,
    status: "live",
    endsAt: "2026-08-15T23:59:59Z",
    participantsCount: 8420,
    tasks: [
      { id: "t1", title: "Join Telegram Global Community", type: "telegram", link: "https://t.me/CryptoMonsterClashGlobal" },
      { id: "t2", title: "Follow @MonsterClashX on X", type: "twitter", link: "https://x.com/MonsterClashX" },
      { id: "t3", title: "Retweet Pinned AMA Post", type: "twitter", link: "https://x.com/MonsterClashX" },
      { id: "t4", title: "Submit EVM Wallet Address", type: "wallet" }
    ],
    winners: ["0x71C...49A", "0x39B...81F", "0xF12...33C"]
  },
  {
    id: "gw-2",
    title: "Apex Yield $2,500 RWA Tokens Airdrop",
    projectName: "Apex Yield RWA",
    projectLogo: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=120&auto=format&fit=crop&q=80",
    prizePool: "$2,500 $AYRWA",
    winnersCount: 100,
    status: "live",
    endsAt: "2026-08-20T23:59:59Z",
    participantsCount: 4210,
    tasks: [
      { id: "t1", title: "Join Announcement Channel", type: "telegram", link: "https://t.me/CryptoMonsterClashAnn" },
      { id: "t2", title: "Visit Apex Yield Website", type: "visit", link: "https://apexyield.io" },
      { id: "t3", title: "Submit Solana Wallet Address", type: "wallet" }
    ]
  }
];

export const INITIAL_AIRDROPS: AirdropItem[] = [
  {
    id: "air-1",
    title: "Monster Clash Pioneer Badge & 100 $MAIC Tokens",
    projectName: "Crypto Monster Clash",
    projectLogo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80",
    estimatedValue: "$150 per wallet",
    status: "live",
    endsAt: "2026-08-31T23:59:59Z",
    requirements: [
      "Connect Wallet",
      "Complete at least 3 AMA Quests",
      "Refer 2 friends to Crypto Monster Clash"
    ],
    claimUrl: "#claim-airdrop-1",
    participantsCount: 12450,
  }
];

export const INITIAL_LEADERBOARD: LeaderboardEntry[] = [
  { rank: 1, name: "CryptoWhale_99", avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80", scoreOrXp: 15400, badges: ["AMA Legend", "Top Referrer", "Whale"], change: "same" },
  { rank: 2, name: "SatoshiDreamer", avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&auto=format&fit=crop&q=80", scoreOrXp: 12850, badges: ["Alpha Hunter", "Top Quester"], change: "up" },
  { rank: 3, name: "Web3_GigaDev", avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&auto=format&fit=crop&q=80", scoreOrXp: 11200, badges: ["Speaker", "VIP"], change: "down" },
  { rank: 4, name: "CryptoNinjaz", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80", scoreOrXp: 9800, badges: ["Early Adopter"], change: "up" },
  { rank: 5, name: "DeFi_Queen", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80", scoreOrXp: 8950, badges: ["Community Lead"], change: "same" }
];

export const INITIAL_NEWS: NewsArticle[] = [
  {
    id: "news-1",
    title: "Crypto Monster Clash Reaches 500,000+ Global Web3 Community Reach Across Telegram & X",
    category: "Announcements",
    summary: "Crypto Monster Clash celebrates hosting over 350+ successful AMAs and launching new AI-driven tools for projects.",
    content: "Crypto Monster Clash has solidified its position as the premier Web3 AMA hosting and marketing platform. With over 500,000 active followers across Telegram, X Spaces, and Binance Square, the platform provides unmatched exposure for top crypto projects...",
    imageUrl: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=600&auto=format&fit=crop&q=80",
    author: "Calvin Harrison",
    date: "2026-08-06",
    readTime: "3 min read"
  },
  {
    id: "news-2",
    title: "Monster AI Chain Mainnet AMA Recap: $3M Security Fund & Tier 1 CEX Listings Confirmed",
    category: "AMA Recaps",
    summary: "Full summary of the Monster AI Chain AMA including core technology highlights and future ecosystem grants.",
    content: "In an explosive 90-minute live Telegram Voice AMA, the core founders of Monster AI Chain answered over 50 community questions regarding AI smart contract architecture...",
    imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
    author: "Zakaria Habib",
    date: "2026-08-05",
    readTime: "5 min read"
  }
];

export const INITIAL_PARTNERS: PartnerItem[] = [
  { id: "p-1", name: "Binance Square", category: "Exchange Partners", logo: "https://images.unsplash.com/photo-1622979135225-d2ba269bc1bd?w=120&auto=format&fit=crop&q=80", website: "https://binance.com" },
  { id: "p-2", name: "CoinMarketCap", category: "Media Partners", logo: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=120&auto=format&fit=crop&q=80", website: "https://coinmarketcap.com" },
  { id: "p-3", name: "CoinGecko", category: "Media Partners", logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=120&auto=format&fit=crop&q=80", website: "https://coingecko.com" },
  { id: "p-4", name: "Crypto Monster Global", category: "Community Partners", logo: "https://images.unsplash.com/photo-1642543492481-44e81e3914a7?w=120&auto=format&fit=crop&q=80", website: "https://t.me/CryptoMonsterClashGlobal" }
];
