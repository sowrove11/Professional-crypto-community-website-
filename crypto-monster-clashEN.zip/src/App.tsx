import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from './lib/firebase';
import { 
  UserProfile, 
  AMAItem, 
  ServiceItem, 
  GiveawayItem, 
  ProjectItem, 
  CommunityItem, 
  SiteConfig 
} from './types';
import { 
  INITIAL_SITE_CONFIG,
  INITIAL_AMAS, 
  INITIAL_SERVICES, 
  INITIAL_PROJECTS, 
  INITIAL_COMMUNITIES, 
  INITIAL_GIVEAWAYS, 
  INITIAL_LEADERBOARD, 
  INITIAL_NEWS 
} from './data/mockData';

// Components
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { AiToolsModal } from './components/AiToolsModal';
import { BookAmaModal } from './components/BookAmaModal';
import { AdminAuthModal } from './components/AdminAuthModal';
import { MobileBottomNav } from './components/MobileBottomNav';

// Views
import { HomeView } from './views/HomeView';
import { AmaCenterView } from './views/AmaCenterView';
import { ServicesView } from './views/ServicesView';
import { ProjectsView } from './views/ProjectsView';
import { CommunitiesView } from './views/CommunitiesView';
import { GiveawaysView } from './views/GiveawaysView';
import { LeaderboardView } from './views/LeaderboardView';
import { UserDashboardView } from './views/UserDashboardView';
import { AdminPanelView } from './views/AdminPanelView';
import { ContactView } from './views/ContactView';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Admin Unlock State
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(() => {
    return localStorage.getItem('cmc_admin_unlocked') === 'true';
  });
  const [adminAuthModalOpen, setAdminAuthModalOpen] = useState<boolean>(false);

  // Modals State
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [aiToolsModalOpen, setAiToolsModalOpen] = useState<boolean>(false);
  const [bookAmaModalOpen, setBookAmaModalOpen] = useState<boolean>(false);

  // Editable Site Datasets State with LocalStorage Persistence
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
    const saved = localStorage.getItem('cmc_site_config');
    return saved ? JSON.parse(saved) : INITIAL_SITE_CONFIG;
  });

  const [amas, setAmas] = useState<AMAItem[]>(() => {
    const saved = localStorage.getItem('cmc_amas');
    return saved ? JSON.parse(saved) : INITIAL_AMAS;
  });

  const [services, setServices] = useState<ServiceItem[]>(() => {
    const saved = localStorage.getItem('cmc_services');
    return saved ? JSON.parse(saved) : INITIAL_SERVICES;
  });

  const [giveaways, setGiveaways] = useState<GiveawayItem[]>(() => {
    const saved = localStorage.getItem('cmc_giveaways');
    return saved ? JSON.parse(saved) : INITIAL_GIVEAWAYS;
  });

  const [projects, setProjects] = useState<ProjectItem[]>(() => {
    const saved = localStorage.getItem('cmc_projects');
    return saved ? JSON.parse(saved) : INITIAL_PROJECTS;
  });

  const [communities, setCommunities] = useState<CommunityItem[]>(() => {
    const saved = localStorage.getItem('cmc_communities');
    return saved ? JSON.parse(saved) : INITIAL_COMMUNITIES;
  });

  // Save to LocalStorage whenever state changes
  useEffect(() => {
    localStorage.setItem('cmc_site_config', JSON.stringify(siteConfig));
  }, [siteConfig]);

  useEffect(() => {
    localStorage.setItem('cmc_amas', JSON.stringify(amas));
  }, [amas]);

  useEffect(() => {
    localStorage.setItem('cmc_services', JSON.stringify(services));
  }, [services]);

  useEffect(() => {
    localStorage.setItem('cmc_giveaways', JSON.stringify(giveaways));
  }, [giveaways]);

  useEffect(() => {
    localStorage.setItem('cmc_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('cmc_communities', JSON.stringify(communities));
  }, [communities]);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userRef = doc(db, "users", firebaseUser.uid);
          const snap = await getDoc(userRef);
          if (snap.exists()) {
            setCurrentUser(snap.data() as UserProfile);
          } else {
            setCurrentUser({
              uid: firebaseUser.uid,
              email: firebaseUser.email || "",
              displayName: firebaseUser.displayName || "Monster Member",
              role: firebaseUser.email?.includes('admin') ? 'admin' : 'user',
              xp: 200,
              level: 1,
              referralCode: `CMC-${firebaseUser.uid.slice(0, 6).toUpperCase()}`,
              referralCount: 0,
              earnedUsdt: 0,
              completedTasks: []
            });
          }
        } catch (e) {
          console.warn("Firestore user fetch offline, using local fallback", e);
          setCurrentUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email || "user@cryptomonsterclash.com",
            displayName: firebaseUser.displayName || "Monster User",
            role: "user",
            xp: 200,
            level: 1,
            referralCode: "CMC-MEMBER",
            referralCount: 0,
            earnedUsdt: 0,
            completedTasks: []
          });
        }
      } else {
        setCurrentUser(null);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error(e);
    }
    setCurrentUser(null);
  };

  const handleUnlockAdmin = () => {
    setIsAdminUnlocked(true);
    localStorage.setItem('cmc_admin_unlocked', 'true');
    setAdminAuthModalOpen(false);
    setActiveTab('admin');
  };

  // State handlers for Admin mutations
  const handleUpdateSiteConfig = (newConfig: SiteConfig) => {
    setSiteConfig(newConfig);
  };

  const handleAddAma = (newAma: AMAItem) => {
    setAmas(prev => [newAma, ...prev]);
  };

  const handleUpdateAma = (updatedAma: AMAItem) => {
    setAmas(prev => prev.map(a => a.id === updatedAma.id ? updatedAma : a));
  };

  const handleDeleteAma = (id: string) => {
    setAmas(prev => prev.filter(a => a.id !== id));
  };

  const handleAddService = (newSrv: ServiceItem) => {
    setServices(prev => [newSrv, ...prev]);
  };

  const handleUpdateService = (updatedSrv: ServiceItem) => {
    setServices(prev => prev.map(s => s.id === updatedSrv.id ? updatedSrv : s));
  };

  const handleDeleteService = (id: string) => {
    setServices(prev => prev.filter(s => s.id !== id));
  };

  const handleAddGiveaway = (newGw: GiveawayItem) => {
    setGiveaways(prev => [newGw, ...prev]);
  };

  const handleDeleteGiveaway = (id: string) => {
    setGiveaways(prev => prev.filter(g => g.id !== id));
  };

  const handleAddProject = (newProj: ProjectItem) => {
    setProjects(prev => [newProj, ...prev]);
  };

  const handleDeleteProject = (id: string) => {
    setProjects(prev => prev.filter(p => p.id !== id));
  };

  const handleAddCommunity = (newComm: CommunityItem) => {
    setCommunities(prev => [newComm, ...prev]);
  };

  const handleDeleteCommunity = (id: string) => {
    setCommunities(prev => prev.filter(c => c.id !== id));
  };

  return (
    <div className="min-h-screen font-sans flex flex-col bg-[#0A0A0B] text-white selection:bg-[#00FF94] selection:text-black transition-colors">
      {/* Navbar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        siteConfig={siteConfig}
        isAdminUnlocked={isAdminUnlocked}
        onOpenAdminAuth={() => setAdminAuthModalOpen(true)}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenAiTools={() => setAiToolsModalOpen(true)}
        onOpenBookModal={() => setBookAmaModalOpen(true)}
        onLogout={handleLogout}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main View Container */}
      <main className="flex-1 container mx-auto px-4 pt-6 pb-24 sm:pb-8">
        {activeTab === 'home' && (
          <HomeView
            siteConfig={siteConfig}
            amas={amas}
            services={services}
            projects={projects}
            communities={communities}
            giveaways={giveaways}
            leaderboard={INITIAL_LEADERBOARD}
            news={INITIAL_NEWS}
            setActiveTab={setActiveTab}
            onOpenBookModal={() => setBookAmaModalOpen(true)}
            onOpenAiTools={() => setAiToolsModalOpen(true)}
          />
        )}

        {activeTab === 'amas' && (
          <AmaCenterView
            amas={amas}
            onOpenBookModal={() => setBookAmaModalOpen(true)}
            onOpenAiTools={() => setAiToolsModalOpen(true)}
          />
        )}

        {activeTab === 'services' && (
          <ServicesView
            services={services}
            onOpenBookModal={() => setBookAmaModalOpen(true)}
          />
        )}

        {activeTab === 'projects' && (
          <ProjectsView projects={projects} />
        )}

        {activeTab === 'communities' && (
          <CommunitiesView communities={communities} />
        )}

        {activeTab === 'giveaways' && (
          <GiveawaysView
            giveaways={giveaways}
            currentUser={currentUser}
            onOpenAuth={() => setAuthModalOpen(true)}
          />
        )}

        {activeTab === 'leaderboard' && (
          <LeaderboardView leaderboard={INITIAL_LEADERBOARD} />
        )}

        {activeTab === 'news' && (
          <div className="space-y-6 pb-12">
            <h1 className="text-3xl font-black text-white">Latest Web3 & AMA News</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {INITIAL_NEWS.map((article) => (
                <div key={article.id} className="bg-[#141416] border border-white/10 rounded-3xl p-6 space-y-3">
                  <img src={article.imageUrl} alt={article.title} className="w-full h-48 rounded-2xl object-cover" />
                  <span className="text-[10px] font-mono font-extrabold text-[#00FF94] uppercase bg-[#00FF94]/10 px-2.5 py-1 rounded">
                    {article.category}
                  </span>
                  <h3 className="font-extrabold text-white text-lg">{article.title}</h3>
                  <p className="text-xs text-gray-300">{article.summary}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'contact' && (
          <ContactView onOpenBookModal={() => setBookAmaModalOpen(true)} />
        )}

        {activeTab === 'dashboard' && currentUser && (
          <UserDashboardView
            currentUser={currentUser}
            onLogout={handleLogout}
            onOpenBookModal={() => setBookAmaModalOpen(true)}
          />
        )}

        {activeTab === 'admin' && (
          isAdminUnlocked || currentUser?.role === 'admin' ? (
            <AdminPanelView
              siteConfig={siteConfig}
              onUpdateSiteConfig={handleUpdateSiteConfig}
              amas={amas}
              onAddAma={handleAddAma}
              onUpdateAma={handleUpdateAma}
              onDeleteAma={handleDeleteAma}
              services={services}
              onAddService={handleAddService}
              onUpdateService={handleUpdateService}
              onDeleteService={handleDeleteService}
              giveaways={giveaways}
              onAddGiveaway={handleAddGiveaway}
              onDeleteGiveaway={handleDeleteGiveaway}
              projects={projects}
              onAddProject={handleAddProject}
              onDeleteProject={handleDeleteProject}
              communities={communities}
              onAddCommunity={handleAddCommunity}
              onDeleteCommunity={handleDeleteCommunity}
            />
          ) : (
            <div className="bg-[#141416] border border-[#00FF94]/30 rounded-3xl p-12 text-center max-w-lg mx-auto my-12 space-y-4">
              <div className="w-16 h-16 bg-[#00FF94]/10 text-[#00FF94] border border-[#00FF94]/30 rounded-2xl flex items-center justify-center mx-auto">
                <span className="text-2xl font-black">🔒</span>
              </div>
              <h2 className="text-2xl font-black text-white">Admin Access Protected</h2>
              <p className="text-xs text-gray-400 font-mono">You need master admin authorization to view this panel.</p>
              <button
                onClick={() => setAdminAuthModalOpen(true)}
                className="px-6 py-3 bg-[#00FF94] text-black font-extrabold text-xs rounded-xl hover:bg-[#00e082] transition-colors"
              >
                Enter Admin PIN / Passcode
              </button>
            </div>
          )
        )}
      </main>

      {/* Footer */}
      <Footer
        setActiveTab={setActiveTab}
        onOpenBookModal={() => setBookAmaModalOpen(true)}
      />

      {/* Modals */}
      <AdminAuthModal
        isOpen={adminAuthModalOpen}
        onClose={() => setAdminAuthModalOpen(false)}
        onSuccess={handleUnlockAdmin}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={(profile) => setCurrentUser(profile)}
      />

      <AiToolsModal
        isOpen={aiToolsModalOpen}
        onClose={() => setAiToolsModalOpen(false)}
      />

      <BookAmaModal
        isOpen={bookAmaModalOpen}
        onClose={() => setBookAmaModalOpen(false)}
        currentUser={currentUser}
        siteConfig={siteConfig}
      />

      {/* Mobile App Mode Bottom Dock */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUser={currentUser}
        isAdminUnlocked={isAdminUnlocked}
        onOpenAdminAuth={() => setAdminAuthModalOpen(true)}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenAiTools={() => setAiToolsModalOpen(true)}
        onOpenBookModal={() => setBookAmaModalOpen(true)}
      />
    </div>
  );
}
